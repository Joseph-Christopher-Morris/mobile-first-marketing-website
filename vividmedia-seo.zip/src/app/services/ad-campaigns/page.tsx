import { Metadata } from 'next';
import { buildMetadata } from '@/lib/seo';
import AdCampaignsClient from './AdCampaignsClient';

export const metadata: Metadata = buildMetadata({
  intent: "Google Ads Management",
  description: "Stop paying for clicks that don't convert. Targeted ad campaigns for Cheshire businesses.",
  canonicalPath: "/services/ad-campaigns/",
  ogImage: "/images/services/WhatsApp Image 2025-11-11 at 9.27.14 AM.webp",
});

export default function AdCampaignsPage() {
  return <AdCampaignsClient />;
}
