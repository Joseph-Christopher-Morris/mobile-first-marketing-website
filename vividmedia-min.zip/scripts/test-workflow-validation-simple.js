#!/usr/bin/env node

/**
 * Simple GitHub Actions Workflow Validation Tests
 * 
 * Validates the quality-check.yml workflow configuration
 * using simple string matching instead of full YAML parsing.
 * 
 * Requirements: 5.1, 5.2, 5.3
 */

const fs = require('fs');

class SimpleWorkflowValidationTests {
  constructor() {
    this.workflowPath = '.github/workflows/quality-check.yml';
    this.results = {
      tests: [],
      passed: 0,
      failed: 0,
      warnings: []
    };
  }

  /**
   * Run all workflow validation tests
   */
  runTests() {
    console.log('🔍 Running Simple GitHub Actions Workflow Validation Tests');
    console.log('=' .repeat(55));

    try {
      // Load workflow content
      const workflowContent = this.loadWorkflowContent();
      
      // Run validation tests
      this.validateBasicStructure(workflowContent);
      this.validateNodeJsConfiguration(workflowContent);
      this.validateRequiredSteps(workflowContent);
      this.validateEnvironmentConfiguration(workflowContent);
      this.validateCacheConfiguration(workflowContent);
      this.validateTriggerConfiguration(workflowContent);
      
      // Generate report
      this.generateReport();
      
    } catch (error) {
      console.error('❌ Workflow validation failed:', error.message);
      process.exit(1);
    }
  }

  /**
   * Load and validate workflow file exists
   */
  loadWorkflowContent() {
    this.test('Workflow file exists', () => {
      if (!fs.existsSync(this.workflowPath)) {
        throw new Error(`Workflow file not found: ${this.workflowPath}`);
      }
    });

    let content;
    this.test('Workflow file is readable', () => {
      content = fs.readFileSync(this.workflowPath, 'utf8');
      
      if (!content || content.trim().length === 0) {
        throw new Error('Workflow file is empty');
      }
    });

    return content;
  }

  /**
   * Validate basic workflow structure
   */
  validateBasicStructure(content) {
    this.test('Workflow has name', () => {
      if (!content.includes('name:')) {
        throw new Error('Workflow should have a name');
      }
    });

    this.test('Workflow has triggers', () => {
      if (!content.includes('on:')) {
        throw new Error('Workflow should have triggers defined');
      }
    });

    this.test('Workflow has jobs', () => {
      if (!content.includes('jobs:')) {
        throw new Error('Workflow should have jobs defined');
      }
    });

    this.test('Quality check job exists', () => {
      if (!content.includes('quality-check:')) {
        throw new Error('Workflow should have a quality-check job');
      }
    });

    this.test('Job runs on ubuntu-latest', () => {
      if (!content.includes('runs-on: ubuntu-latest')) {
        throw new Error('Job should run on ubuntu-latest');
      }
    });
  }

  /**
   * Validate Node.js configuration
   */
  validateNodeJsConfiguration(content) {
    this.test('Setup Node.js step exists', () => {
      if (!content.includes('Setup Node.js') && !content.includes('setup-node')) {
        throw new Error('Setup Node.js step not found');
      }
    });

    this.test('Uses official setup-node action', () => {
      if (!content.includes('actions/setup-node@')) {
        throw new Error('Should use official actions/setup-node action');
      }
    });

    this.test('Node.js version is 22.19.0', () => {
      if (!content.includes('22.19.0')) {
        throw new Error('Node.js version should be 22.19.0');
      }
    });

    this.test('Node version is properly configured', () => {
      if (!content.includes('node-version:')) {
        throw new Error('Node version should be configured in workflow');
      }
    });
  }

  /**
   * Validate required workflow steps
   */
  validateRequiredSteps(content) {
    const requiredSteps = [
      { name: 'Checkout repository', pattern: 'actions/checkout@' },
      { name: 'Setup Node.js', pattern: 'actions/setup-node@' },
      { name: 'Install dependencies', pattern: 'npm ci' },
      { name: 'Build project', pattern: 'npm run build' }
    ];

    requiredSteps.forEach(({ name, pattern }) => {
      this.test(`Required step: ${name}`, () => {
        if (!content.includes(pattern)) {
          throw new Error(`Required step pattern not found: ${pattern}`);
        }
      });
    });

    // Check for lockfile verification
    this.test('Lockfile consistency check exists', () => {
      if (!content.includes('git diff') || !content.includes('package-lock.json')) {
        throw new Error('Lockfile consistency check not found');
      }
    });

    // Check for conditional execution patterns
    this.test('Conditional execution patterns exist', () => {
      if (!content.includes('--if-present') && !content.includes('continue-on-error')) {
        this.addWarning('Consider adding conditional execution for optional steps');
      }
    });
  }

  /**
   * Validate environment configuration
   */
  validateEnvironmentConfiguration(content) {
    this.test('Environment variables section exists', () => {
      if (!content.includes('env:')) {
        throw new Error('Environment variables should be configured');
      }
    });

    this.test('CI environment variable is set', () => {
      if (!content.includes('CI: true') && !content.includes('CI: "true"')) {
        throw new Error('CI environment variable should be set to true');
      }
    });

    this.test('Next.js telemetry is disabled', () => {
      if (!content.includes('NEXT_TELEMETRY_DISABLED')) {
        throw new Error('NEXT_TELEMETRY_DISABLED should be set');
      }
    });

    this.test('Production environment is configured', () => {
      if (!content.includes('NODE_ENV: production')) {
        this.addWarning('Consider setting NODE_ENV to production for builds');
      }
    });
  }

  /**
   * Validate cache configuration
   */
  validateCacheConfiguration(content) {
    this.test('npm cache is configured', () => {
      if (!content.includes("cache: 'npm'") && !content.includes('cache: npm')) {
        throw new Error('npm cache should be configured');
      }
    });

    this.test('Cache dependency path is specified', () => {
      if (content.includes('cache-dependency-path')) {
        if (!content.includes('package-lock.json')) {
          this.addWarning('Cache dependency path should point to package-lock.json');
        }
      } else {
        this.addWarning('Consider specifying cache-dependency-path for better caching');
      }
    });
  }

  /**
   * Validate trigger configuration
   */
  validateTriggerConfiguration(content) {
    this.test('Push trigger is configured', () => {
      if (!content.includes('push:')) {
        throw new Error('Workflow should have push trigger');
      }
    });

    this.test('Pull request trigger is configured', () => {
      if (!content.includes('pull_request:')) {
        this.addWarning('Consider adding pull_request trigger for better CI coverage');
      }
    });

    this.test('Branch restrictions exist', () => {
      if (!content.includes('branches:')) {
        this.addWarning('Consider restricting triggers to specific branches');
      }
    });

    this.test('Main branch is targeted', () => {
      if (!content.includes('main') && !content.includes('master')) {
        this.addWarning('Consider targeting main/master branch in triggers');
      }
    });
  }

  /**
   * Run individual test
   */
  test(testName, testFunction) {
    try {
      testFunction();
      console.log(`  ✅ ${testName}`);
      this.results.tests.push({ name: testName, status: 'passed' });
      this.results.passed++;
    } catch (error) {
      console.log(`  ❌ ${testName}: ${error.message}`);
      this.results.tests.push({ name: testName, status: 'failed', error: error.message });
      this.results.failed++;
    }
  }

  /**
   * Add warning
   */
  addWarning(message) {
    console.log(`  ⚠️  Warning: ${message}`);
    this.results.warnings.push(message);
  }

  /**
   * Generate test report
   */
  generateReport() {
    console.log('\n' + '='.repeat(55));
    console.log('📊 Simple Workflow Validation Results');
    console.log('='.repeat(55));
    
    console.log(`\nTests: ${this.results.passed + this.results.failed}`);
    console.log(`Passed: ${this.results.passed}`);
    console.log(`Failed: ${this.results.failed}`);
    console.log(`Warnings: ${this.results.warnings.length}`);

    if (this.results.warnings.length > 0) {
      console.log('\n⚠️  Warnings:');
      this.results.warnings.forEach(warning => {
        console.log(`  - ${warning}`);
      });
    }

    // Save detailed report
    const reportPath = `simple-workflow-validation-report-${Date.now()}.json`;
    fs.writeFileSync(reportPath, JSON.stringify(this.results, null, 2));
    console.log(`\n📄 Detailed report saved: ${reportPath}`);

    if (this.results.failed > 0) {
      console.log('\n❌ Workflow validation failed. Please fix the issues above.');
      process.exit(1);
    } else {
      console.log('\n✅ Workflow validation passed!');
    }
  }
}

// Run tests if called directly
if (require.main === module) {
  const validator = new SimpleWorkflowValidationTests();
  validator.runTests();
}

module.exports = SimpleWorkflowValidationTests;