# Real-time URL Functionality Validation Script
# Requirements: 1.4, 2.4

$CLOUDFRONT_DOMAIN = "d15sc9fc739ev2.cloudfront.net"
$BASE_URL = "https://$CLOUDFRONT_DOMAIN"

# Test URLs
$testUrls = @(
    @{ url = "/"; name = "Root URL"; requirement = "1.4" },
    @{ url = "/privacy-policy/"; name = "Privacy Policy directory"; requirement = "2.4" },
    @{ url = "/about/"; name = "About directory"; requirement = "2.4" },
    @{ url = "/contact/"; name = "Contact directory"; requirement = "2.4" },
    @{ url = "/services/"; name = "Services directory"; requirement = "2.4" },
    @{ url = "/blog/"; name = "Blog directory"; requirement = "2.4" },
    @{ url = "/privacy-policy"; name = "Privacy Policy extensionless"; requirement = "2.4" },
    @{ url = "/about"; name = "About extensionless"; requirement = "2.4" },
    @{ url = "/contact"; name = "Contact extensionless"; requirement = "2.4" },
    @{ url = "/services"; name = "Services extensionless"; requirement = "2.4" },
    @{ url = "/blog"; name = "Blog extensionless"; requirement = "2.4" },
    @{ url = "/privacy-policy/index.html"; name = "Explicit file path"; requirement = "1.4" }
)

Write-Host "Starting Real-time URL Functionality Validation" -ForegroundColor Green
Write-Host "Testing domain: $BASE_URL" -ForegroundColor Cyan
Write-Host "Test started: $(Get-Date)" -ForegroundColor Cyan
Write-Host ""

$passedTests = 0
$totalTests = $testUrls.Count
$results = @()

foreach ($test in $testUrls) {
    $fullUrl = "$BASE_URL$($test.url)"
    Write-Host "Testing: $($test.name) - $fullUrl" -ForegroundColor Yellow
    
    try {
        $response = Invoke-WebRequest -Uri $fullUrl -Method GET -TimeoutSec 10 -ErrorAction Stop
        
        $testResult = @{
            name = $test.name
            url = $test.url
            fullUrl = $fullUrl
            requirement = $test.requirement
            statusCode = $response.StatusCode
            contentType = $response.Headers['Content-Type']
            passed = $false
            details = @()
        }
        
        # Check if response is successful and contains HTML
        if ($response.StatusCode -eq 200) {
            $testResult.details += "Status: 200 OK"
            
            if ($response.Content -like "*<html*") {
                $testResult.details += "Contains HTML content"
                $testResult.passed = $true
                Write-Host "  PASSED" -ForegroundColor Green
                $passedTests++
            } else {
                $testResult.details += "Missing HTML content"
                Write-Host "  FAILED - No HTML content" -ForegroundColor Red
            }
        } else {
            $testResult.details += "Status: $($response.StatusCode)"
            Write-Host "  FAILED - Status: $($response.StatusCode)" -ForegroundColor Red
        }
        
        # Check CloudFront headers
        if ($response.Headers['X-Cache']) {
            $testResult.details += "CloudFront Cache: $($response.Headers['X-Cache'])"
        }
        
        $results += $testResult
        
    } catch {
        Write-Host "  FAILED - Error: $($_.Exception.Message)" -ForegroundColor Red
        $results += @{
            name = $test.name
            url = $test.url
            fullUrl = $fullUrl
            requirement = $test.requirement
            passed = $false
            error = $_.Exception.Message
        }
    }
    
    Start-Sleep -Milliseconds 500
}

# Summary
Write-Host ""
Write-Host "VALIDATION SUMMARY" -ForegroundColor Cyan
Write-Host "Total Tests: $totalTests"
Write-Host "Passed: $passedTests" -ForegroundColor Green
Write-Host "Failed: $($totalTests - $passedTests)" -ForegroundColor Red
Write-Host "Success Rate: $(($passedTests / $totalTests * 100).ToString('F1'))%"

if ($passedTests -eq $totalTests) {
    Write-Host ""
    Write-Host "ALL TESTS PASSED! Pretty URLs are working correctly." -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "SOME TESTS FAILED. Please review the errors above." -ForegroundColor Yellow
}

# Detailed results
Write-Host ""
Write-Host "DETAILED RESULTS:" -ForegroundColor Cyan
for ($i = 0; $i -lt $results.Count; $i++) {
    $result = $results[$i]
    Write-Host ""
    Write-Host "$($i + 1). $($result.name)"
    Write-Host "   URL: $($result.fullUrl)"
    Write-Host "   Status: $(if ($result.passed) { 'PASSED' } else { 'FAILED' })"
    Write-Host "   Requirement: $($result.requirement)"
    
    if ($result.details) {
        foreach ($detail in $result.details) {
            Write-Host "   - $detail"
        }
    }
    
    if ($result.error) {
        Write-Host "   Error: $($result.error)" -ForegroundColor Red
    }
}

# Generate report
$report = @{
    timestamp = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss.fffZ')
    domain = $BASE_URL
    summary = @{
        totalTests = $totalTests
        passedTests = $passedTests
        failedTests = $totalTests - $passedTests
        successRate = "$(($passedTests / $totalTests * 100).ToString('F1'))%"
    }
    results = $results
}

$reportFilename = "pretty-urls-validation-report-$(Get-Date -Format 'yyyyMMddHHmmss').json"
$report | ConvertTo-Json -Depth 10 | Out-File -FilePath $reportFilename -Encoding UTF8
Write-Host ""
Write-Host "Report saved to: $reportFilename" -ForegroundColor Cyan

if ($passedTests -eq $totalTests) {
    exit 0
} else {
    exit 1
}