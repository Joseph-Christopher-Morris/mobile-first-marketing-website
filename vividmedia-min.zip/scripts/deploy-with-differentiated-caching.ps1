# PowerShell Script for Differentiated S3 Caching Deployment
# 
# Implements the vivid-auto-scram-rebuild caching strategy:
# - HTML files: Cache-Control: public, max-age=600
# - Static assets: Cache-Control: public, max-age=31536000, immutable
#
# Requirements addressed:
# - 8.1: Set up HTML files with Cache-Control: public, max-age=600
# - 8.2: Configure static assets with Cache-Control: public, max-age=31536000, immutable
# - 8.4: Implement differentiated upload strategy for HTML vs assets

param(
    [string]$BucketName = $env:S3_BUCKET_NAME,
    [string]$Region = $env:AWS_REGION,
    [string]$BuildDir = "out"
)

# Configuration
if (-not $BucketName) {
    $BucketName = "mobile-marketing-site-prod-1759705011281-tyzuo9"
}

if (-not $Region) {
    $Region = "us-east-1"
}

Write-Host "🚀 Starting differentiated caching deployment..." -ForegroundColor Green
Write-Host "   Bucket: $BucketName" -ForegroundColor Cyan
Write-Host "   Region: $Region" -ForegroundColor Cyan
Write-Host "   Build Directory: $BuildDir" -ForegroundColor Cyan
Write-Host ""

# Check if build directory exists
if (-not (Test-Path $BuildDir)) {
    Write-Host "🔨 Build directory not found, running build..." -ForegroundColor Yellow
    try {
        npm run build
        Write-Host "✅ Build completed" -ForegroundColor Green
    }
    catch {
        Write-Host "❌ Build failed: $_" -ForegroundColor Red
        exit 1
    }
}
else {
    Write-Host "✅ Build directory found" -ForegroundColor Green
}

# Step 1: Upload HTML files with short cache (600 seconds = 10 minutes)
Write-Host "📄 Uploading HTML files with short cache (600s)..." -ForegroundColor Blue

try {
    aws s3 sync $BuildDir s3://$BucketName `
        --region $Region `
        --exclude "*" `
        --include "*.html" `
        --cache-control "public, max-age=600" `
        --delete `
        --exact-timestamps
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ HTML files uploaded successfully" -ForegroundColor Green
    }
    else {
        throw "AWS CLI returned exit code $LASTEXITCODE"
    }
}
catch {
    Write-Host "❌ HTML file upload failed: $_" -ForegroundColor Red
    exit 1
}

# Step 2: Upload static assets with long cache (31536000 seconds = 1 year, immutable)
Write-Host "🎨 Uploading static assets with long cache (31536000s, immutable)..." -ForegroundColor Blue

try {
    aws s3 sync $BuildDir s3://$BucketName `
        --region $Region `
        --exclude "*.html" `
        --cache-control "public, max-age=31536000, immutable" `
        --delete `
        --exact-timestamps
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ Static assets uploaded successfully" -ForegroundColor Green
    }
    else {
        throw "AWS CLI returned exit code $LASTEXITCODE"
    }
}
catch {
    Write-Host "❌ Static asset upload failed: $_" -ForegroundColor Red
    exit 1
}

# Step 3: Verify upload
Write-Host "🔍 Verifying upload..." -ForegroundColor Blue

try {
    $objectCount = aws s3 ls s3://$BucketName --recursive --summarize | Select-String "Total Objects:" | ForEach-Object { ($_ -split ":")[1].Trim() }
    $totalSize = aws s3 ls s3://$BucketName --recursive --summarize | Select-String "Total Size:" | ForEach-Object { ($_ -split ":")[1].Trim() }
    
    Write-Host "✅ Upload verification completed" -ForegroundColor Green
    Write-Host "   Total Objects: $objectCount" -ForegroundColor Cyan
    Write-Host "   Total Size: $totalSize" -ForegroundColor Cyan
}
catch {
    Write-Host "⚠️  Upload verification failed: $_" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "📊 Differentiated Caching Summary:" -ForegroundColor Green
Write-Host "   HTML Files: Cache-Control: public, max-age=600 (10 minutes)" -ForegroundColor Cyan
Write-Host "   Static Assets: Cache-Control: public, max-age=31536000, immutable (1 year)" -ForegroundColor Cyan
Write-Host ""
Write-Host "✅ Differentiated caching deployment completed successfully!" -ForegroundColor Green
Write-Host "   HTML files will be cached for 10 minutes" -ForegroundColor Cyan
Write-Host "   Static assets will be cached for 1 year with immutable flag" -ForegroundColor Cyan