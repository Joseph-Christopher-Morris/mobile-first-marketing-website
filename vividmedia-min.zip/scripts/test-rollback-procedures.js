#!/usr/bin/env node

/**
 * Test Rollback Procedures
 * 
 * This script tests the S3 versioning rollback procedures using a sandbox test file.
 * It validates that rollback maintains proper cache headers and follows documented procedures.
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// Configuration
const CONFIG = {
  bucket: 'mobile-marketing-site-prod-1759705011281-tyzuo9',
  distributionId: 'E2IBMHQ3GCW6ZK',
  region: 'us-east-1',
  testFile: 'test/rollback-test.html',
  testContent: {
    version1: `<!DOCTYPE html>
<html>
<head><title>Rollback Test v1</title></head>
<body><h1>Test Version 1 - Original</h1><p>Timestamp: ${new Date().toISOString()}</p></body>
</html>`,
    version2: `<!DOCTYPE html>
<html>
<head><title>Rollback Test v2</title></head>
<body><h1>Test Version 2 - Updated</h1><p>Timestamp: ${new Date().toISOString()}</p></body>
</html>`
  }
};

class RollbackTester {
  constructor() {
    this.testResults = [];
    this.versionIds = [];
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const logMessage = `[${timestamp}] ${type.toUpperCase()}: ${message}`;
    console.log(logMessage);
    
    this.testResults.push({
      timestamp,
      type,
      message
    });
  }

  async runCommand(command, description) {
    this.log(`Executing: ${description}`);
    this.log(`Command: ${command}`, 'debug');
    
    try {
      const result = execSync(command, { 
        encoding: 'utf8',
        stdio: ['pipe', 'pipe', 'pipe']
      });
      this.log(`✅ Success: ${description}`);
      return result.trim();
    } catch (error) {
      this.log(`❌ Failed: ${description} - ${error.message}`, 'error');
      throw error;
    }
  }

  async checkAWSCredentials() {
    this.log('🔐 Checking AWS credentials...');
    
    try {
      const identity = await this.runCommand(
        'aws sts get-caller-identity --output json',
        'Get AWS caller identity'
      );
      
      const identityData = JSON.parse(identity);
      this.log(`AWS User: ${identityData.Arn || identityData.UserId}`);
      
      // Check S3 bucket access
      await this.runCommand(
        `aws s3api head-bucket --bucket ${CONFIG.bucket} --region ${CONFIG.region}`,
        'Verify S3 bucket access'
      );
      
      // Check CloudFront distribution access
      await this.runCommand(
        `aws cloudfront get-distribution --id ${CONFIG.distributionId} --region ${CONFIG.region} --output json`,
        'Verify CloudFront distribution access'
      );
      
      this.log('✅ AWS credentials and permissions verified');
      return true;
    } catch (error) {
      this.log('❌ AWS credentials check failed', 'error');
      return false;
    }
  }

  async createTestFile(content, version) {
    this.log(`📝 Creating test file version ${version}...`);
    
    // Create temporary local file
    const tempFile = path.join(__dirname, `temp-test-v${version}.html`);
    fs.writeFileSync(tempFile, content);
    
    try {
      // Upload to S3 with proper cache headers
      const uploadResult = await this.runCommand(
        `aws s3api put-object ` +
        `--bucket ${CONFIG.bucket} ` +
        `--key ${CONFIG.testFile} ` +
        `--body "${tempFile}" ` +
        `--cache-control "public, max-age=600" ` +
        `--content-type "text/html; charset=utf-8" ` +
        `--region ${CONFIG.region} ` +
        `--output json`,
        `Upload test file version ${version}`
      );
      
      const uploadData = JSON.parse(uploadResult);
      const versionId = uploadData.VersionId;
      
      if (versionId) {
        this.versionIds.push(versionId);
        this.log(`📋 Version ${version} created with ID: ${versionId}`);
      }
      
      // Clean up temp file
      fs.unlinkSync(tempFile);
      
      return versionId;
    } catch (error) {
      // Clean up temp file on error
      if (fs.existsSync(tempFile)) {
        fs.unlinkSync(tempFile);
      }
      throw error;
    }
  }

  async listObjectVersions() {
    this.log('📋 Listing object versions...');
    
    const versionsResult = await this.runCommand(
      `aws s3api list-object-versions ` +
      `--bucket ${CONFIG.bucket} ` +
      `--prefix ${CONFIG.testFile} ` +
      `--region ${CONFIG.region} ` +
      `--query 'Versions[*].[Key,VersionId,LastModified,IsLatest]' ` +
      `--output table`,
      'List object versions'
    );
    
    this.log('Available versions:');
    console.log(versionsResult);
    
    // Also get JSON format for processing
    const versionsJson = await this.runCommand(
      `aws s3api list-object-versions ` +
      `--bucket ${CONFIG.bucket} ` +
      `--prefix ${CONFIG.testFile} ` +
      `--region ${CONFIG.region} ` +
      `--query 'Versions[*].[VersionId,LastModified,IsLatest]' ` +
      `--output json`,
      'List object versions (JSON)'
    );
    
    return JSON.parse(versionsJson);
  }

  async testRollbackProcedure(targetVersionId) {
    this.log(`🔄 Testing rollback to version: ${targetVersionId}`);
    
    // Step 1: Document current state
    this.log('📋 Step 1: Documenting current state...');
    const currentVersions = await this.runCommand(
      `aws s3api list-object-versions ` +
      `--bucket ${CONFIG.bucket} ` +
      `--prefix ${CONFIG.testFile} ` +
      `--region ${CONFIG.region} ` +
      `--query 'Versions[?IsLatest==\`true\`].[Key,VersionId]' ` +
      `--output json`,
      'Document current versions'
    );
    
    const currentData = JSON.parse(currentVersions);
    this.log(`Current version: ${JSON.stringify(currentData)}`);
    
    // Step 2: Perform rollback using copy-object with metadata-directive REPLACE
    this.log('🔄 Step 2: Performing rollback...');
    const rollbackResult = await this.runCommand(
      `aws s3api copy-object ` +
      `--bucket ${CONFIG.bucket} ` +
      `--copy-source "${CONFIG.bucket}/${CONFIG.testFile}?versionId=${targetVersionId}" ` +
      `--key ${CONFIG.testFile} ` +
      `--metadata-directive REPLACE ` +
      `--cache-control "public, max-age=600" ` +
      `--content-type "text/html; charset=utf-8" ` +
      `--region ${CONFIG.region} ` +
      `--output json`,
      'Execute rollback with proper cache headers'
    );
    
    const rollbackData = JSON.parse(rollbackResult);
    this.log(`✅ Rollback completed. New version ID: ${rollbackData.VersionId}`);
    
    // Step 3: Verify cache headers are maintained
    this.log('🔍 Step 3: Verifying cache headers...');
    const headResult = await this.runCommand(
      `aws s3api head-object ` +
      `--bucket ${CONFIG.bucket} ` +
      `--key ${CONFIG.testFile} ` +
      `--region ${CONFIG.region} ` +
      `--output json`,
      'Check object metadata and cache headers'
    );
    
    const headData = JSON.parse(headResult);
    this.log(`Cache-Control: ${headData.CacheControl}`);
    this.log(`Content-Type: ${headData.ContentType}`);
    
    // Validate cache headers
    if (headData.CacheControl === 'public, max-age=600') {
      this.log('✅ Cache-Control header correctly preserved');
    } else {
      this.log(`❌ Cache-Control header incorrect: ${headData.CacheControl}`, 'error');
    }
    
    if (headData.ContentType === 'text/html; charset=utf-8') {
      this.log('✅ Content-Type header correctly preserved');
    } else {
      this.log(`❌ Content-Type header incorrect: ${headData.ContentType}`, 'error');
    }
    
    return rollbackData.VersionId;
  }

  async testCloudFrontInvalidation() {
    this.log('🔄 Testing CloudFront invalidation...');
    
    // Create invalidation for test path
    const invalidationResult = await this.runCommand(
      `aws cloudfront create-invalidation ` +
      `--distribution-id ${CONFIG.distributionId} ` +
      `--paths "/${CONFIG.testFile}" ` +
      `--region ${CONFIG.region} ` +
      `--output json`,
      'Create CloudFront invalidation for test file'
    );
    
    const invalidationData = JSON.parse(invalidationResult);
    const invalidationId = invalidationData.Invalidation.Id;
    
    this.log(`✅ Invalidation created with ID: ${invalidationId}`);
    
    // Check invalidation status
    const statusResult = await this.runCommand(
      `aws cloudfront get-invalidation ` +
      `--distribution-id ${CONFIG.distributionId} ` +
      `--id ${invalidationId} ` +
      `--region ${CONFIG.region} ` +
      `--query 'Invalidation.Status' ` +
      `--output text`,
      'Check invalidation status'
    );
    
    this.log(`Invalidation status: ${statusResult}`);
    
    return invalidationId;
  }

  async verifyRollbackContent(expectedVersion) {
    this.log(`🔍 Verifying rollback content matches version ${expectedVersion}...`);
    
    try {
      // Download the current file content
      const downloadResult = await this.runCommand(
        `aws s3api get-object ` +
        `--bucket ${CONFIG.bucket} ` +
        `--key ${CONFIG.testFile} ` +
        `--region ${CONFIG.region} ` +
        `temp-downloaded.html`,
        'Download current file content'
      );
      
      // Read the downloaded content
      const downloadedContent = fs.readFileSync('temp-downloaded.html', 'utf8');
      const expectedContent = CONFIG.testContent[`version${expectedVersion}`];
      
      // Clean up temp file
      fs.unlinkSync('temp-downloaded.html');
      
      // Compare content (basic check for version identifier)
      if (downloadedContent.includes(`Test Version ${expectedVersion}`)) {
        this.log(`✅ Content verification passed - matches version ${expectedVersion}`);
        return true;
      } else {
        this.log(`❌ Content verification failed - does not match version ${expectedVersion}`, 'error');
        this.log(`Expected to contain: Test Version ${expectedVersion}`, 'debug');
        this.log(`Actual content preview: ${downloadedContent.substring(0, 200)}...`, 'debug');
        return false;
      }
    } catch (error) {
      this.log(`❌ Content verification failed: ${error.message}`, 'error');
      return false;
    }
  }

  async cleanupTestFiles() {
    this.log('🧹 Cleaning up test files...');
    
    try {
      // Delete the test object (this will create a delete marker, not actually delete versions)
      await this.runCommand(
        `aws s3api delete-object ` +
        `--bucket ${CONFIG.bucket} ` +
        `--key ${CONFIG.testFile} ` +
        `--region ${CONFIG.region}`,
        'Delete test object'
      );
      
      this.log('✅ Test cleanup completed');
    } catch (error) {
      this.log(`⚠️ Cleanup warning: ${error.message}`, 'warn');
    }
  }

  generateReport() {
    const timestamp = new Date().toISOString();
    const reportPath = `rollback-test-report-${timestamp.replace(/[:.]/g, '-')}.json`;
    
    const report = {
      timestamp,
      testConfiguration: CONFIG,
      versionIds: this.versionIds,
      testResults: this.testResults,
      summary: {
        totalTests: this.testResults.filter(r => r.type === 'info' && r.message.includes('✅')).length,
        failures: this.testResults.filter(r => r.type === 'error').length,
        warnings: this.testResults.filter(r => r.type === 'warn').length
      }
    };
    
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    this.log(`📊 Test report saved to: ${reportPath}`);
    
    return report;
  }

  async runFullTest() {
    this.log('🚀 Starting rollback procedures test...');
    
    try {
      // Step 1: Check AWS credentials
      const credentialsOk = await this.checkAWSCredentials();
      if (!credentialsOk) {
        throw new Error('AWS credentials check failed');
      }
      
      // Step 2: Create test file version 1
      const version1Id = await this.createTestFile(CONFIG.testContent.version1, 1);
      
      // Wait a moment to ensure different timestamps
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Step 3: Create test file version 2 (this becomes the current version)
      const version2Id = await this.createTestFile(CONFIG.testContent.version2, 2);
      
      // Step 4: List all versions
      const versions = await this.listObjectVersions();
      
      // Step 5: Test rollback to version 1
      const rolledBackVersionId = await this.testRollbackProcedure(version1Id);
      
      // Step 6: Verify content matches version 1
      const contentVerified = await this.verifyRollbackContent(1);
      
      // Step 7: Test CloudFront invalidation
      const invalidationId = await this.testCloudFrontInvalidation();
      
      // Step 8: Test rollback back to version 2 (test reverse rollback)
      this.log('🔄 Testing reverse rollback...');
      await this.testRollbackProcedure(version2Id);
      await this.verifyRollbackContent(2);
      
      // Step 9: Cleanup
      await this.cleanupTestFiles();
      
      this.log('🎉 All rollback tests completed successfully!');
      
      // Generate and return report
      return this.generateReport();
      
    } catch (error) {
      this.log(`💥 Test failed: ${error.message}`, 'error');
      
      // Attempt cleanup even on failure
      try {
        await this.cleanupTestFiles();
      } catch (cleanupError) {
        this.log(`Cleanup failed: ${cleanupError.message}`, 'warn');
      }
      
      // Generate report even on failure
      const report = this.generateReport();
      throw error;
    }
  }
}

// Main execution
async function main() {
  const tester = new RollbackTester();
  
  try {
    const report = await tester.runFullTest();
    
    console.log('\n📊 TEST SUMMARY:');
    console.log(`✅ Successful operations: ${report.summary.totalTests}`);
    console.log(`❌ Failures: ${report.summary.failures}`);
    console.log(`⚠️ Warnings: ${report.summary.warnings}`);
    
    if (report.summary.failures === 0) {
      console.log('\n🎉 All rollback procedures validated successfully!');
      process.exit(0);
    } else {
      console.log('\n💥 Some tests failed. Check the report for details.');
      process.exit(1);
    }
    
  } catch (error) {
    console.error('\n💥 Test execution failed:', error.message);
    process.exit(1);
  }
}

// Run if called directly
if (require.main === module) {
  main();
}

module.exports = { RollbackTester, CONFIG };