# Photography Page Deployment Script
# Quick deployment script for photography page updates

Write-Host "🎯 Photography Page Deployment Script" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan

# Set environment variables
Write-Host "🔧 Setting environment variables..." -ForegroundColor Yellow
$env:S3_BUCKET_NAME = "mobile-marketing-site-prod-1759705011281-tyzuo9"
$env:CLOUDFRONT_DISTRIBUTION_ID = "E2IBMHQ3GCW6ZK"
$env:AWS_REGION = "us-east-1"

Write-Host "✅ Environment configured:" -ForegroundColor Green
Write-Host "   S3 Bucket: $env:S3_BUCKET_NAME" -ForegroundColor Gray
Write-Host "   CloudFront: $env:CLOUDFRONT_DISTRIBUTION_ID" -ForegroundColor Gray
Write-Host "   Region: $env:AWS_REGION" -ForegroundColor Gray

# Verify photography page source
Write-Host "`n🔍 Verifying photography page source..." -ForegroundColor Yellow
$photographyPagePath = "src/app/services/photography/page.tsx"

if (Test-Path $photographyPagePath) {
    $content = Get-Content $photographyPagePath -Raw
    
    # Check for legacy content that should NOT be present
    $hasLegacyGrid = $content -match "grid-cols-1 md:grid-cols-3.*3\+.*Major Publications"
    $hasOldStats = ($content -match "3\+") -and ($content -match "50\+") -and ($content -match "100\+")
    
    if ($hasLegacyGrid -or $hasOldStats) {
        Write-Host "❌ ERROR: Legacy statistics grid detected!" -ForegroundColor Red
        Write-Host "   Please remove the old statistics grid before deployment." -ForegroundColor Red
        Write-Host "   Looking for: 3+, 50+, 100+ statistics" -ForegroundColor Red
        exit 1
    }
    
    # Check for required content
    $hasNewStats = ($content -match "3,500\+") -and ($content -match "90\+")
    
    if ($hasNewStats) {
        Write-Host "✅ Photography page content verified" -ForegroundColor Green
        Write-Host "   ✓ Legacy statistics removed" -ForegroundColor Gray
        Write-Host "   ✓ Current statistics present (3,500+ and 90+)" -ForegroundColor Gray
    } else {
        Write-Host "⚠️  WARNING: Expected statistics not found" -ForegroundColor Yellow
        Write-Host "   Looking for: 3,500+ and 90+ statistics" -ForegroundColor Yellow
    }
} else {
    Write-Host "❌ ERROR: Photography page not found at $photographyPagePath" -ForegroundColor Red
    exit 1
}

# Run deployment
Write-Host "`n🚀 Starting deployment..." -ForegroundColor Yellow
try {
    node scripts/deploy.js
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "`n🎉 Deployment completed successfully!" -ForegroundColor Green
        Write-Host "`n📋 Post-deployment checklist:" -ForegroundColor Cyan
        Write-Host "   1. Wait 5-15 minutes for cache invalidation" -ForegroundColor Gray
        Write-Host "   2. Test: https://d15sc9fc739ev2.cloudfront.net/services/photography" -ForegroundColor Gray
        Write-Host "   3. Verify legacy statistics (3+, 50+, 100+) are removed" -ForegroundColor Gray
        Write-Host "   4. Confirm current statistics (3,500+, 90+) are present" -ForegroundColor Gray
    } else {
        Write-Host "`n❌ Deployment failed with exit code: $LASTEXITCODE" -ForegroundColor Red
    }
} catch {
    Write-Host "`n❌ Deployment error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n📚 For detailed instructions, see: docs/photography-page-deployment-runbook.md" -ForegroundColor Cyan