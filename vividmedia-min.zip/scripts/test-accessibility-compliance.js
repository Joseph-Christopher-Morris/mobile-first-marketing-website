#!/usr/bin/env node

/**
 * Accessibility Compliance Test Suite
 * Tests all updated pages for WCAG 2.1 Level AA compliance
 * 
 * Requirements tested:
 * - 13.1: Press logos have descriptive alt text
 * - 13.2: Pricing cards use semantic HTML
 * - 13.3: Pricing links have clear text
 * - 13.4: Keyboard navigation works
 * - 13.5: WCAG 2.1 Level AA standards
 */

const fs = require('fs');
const path = require('path');

// ANSI color codes
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

// Test results storage
const results = {
  passed: [],
  failed: [],
  warnings: [],
};

/**
 * Test 1: Press Logos Alt Text (Requirement 13.1)
 */
function testPressLogosAltText() {
  log('\n📋 Test 1: Press Logos Alt Text', 'cyan');
  
  const pressLogosPath = path.join(process.cwd(), 'src/components/PressLogos.tsx');
  const content = fs.readFileSync(pressLogosPath, 'utf8');
  
  const logos = [
    'BBC News',
    'Forbes',
    'Financial Times',
    'CNN',
    'AutoTrader',
    'Daily Mail',
    'Business Insider'
  ];
  
  let allPassed = true;
  
  logos.forEach(logo => {
    if (content.includes(`alt: "${logo}"`)) {
      log(`  ✓ ${logo} has descriptive alt text`, 'green');
      results.passed.push(`Press logo alt text: ${logo}`);
    } else {
      log(`  ✗ ${logo} missing descriptive alt text`, 'red');
      results.failed.push(`Press logo alt text: ${logo}`);
      allPassed = false;
    }
  });
  
  // Check for alt attribute in Image component
  if (content.includes('alt={`${logo.alt} logo`}')) {
    log('  ✓ Alt text properly formatted with "logo" suffix', 'green');
    results.passed.push('Press logos: Alt text formatting');
  } else {
    log('  ✗ Alt text not properly formatted', 'red');
    results.failed.push('Press logos: Alt text formatting');
    allPassed = false;
  }
  
  return allPassed;
}

/**
 * Test 2: Pricing Cards Semantic HTML (Requirement 13.2)
 */
function testPricingCardsSemanticHTML() {
  log('\n📋 Test 2: Pricing Cards Semantic HTML', 'cyan');
  
  const pagesToTest = [
    'src/app/page.tsx',
    'src/app/services/hosting/page.tsx',
    'src/app/services/photography/page.tsx',
    'src/app/services/ad-campaigns/page.tsx',
    'src/app/services/analytics/page.tsx'
  ];
  
  let allPassed = true;
  
  pagesToTest.forEach(pagePath => {
    const fullPath = path.join(process.cwd(), pagePath);
    if (!fs.existsSync(fullPath)) {
      log(`  ⚠ ${pagePath} not found`, 'yellow');
      results.warnings.push(`Pricing cards: ${pagePath} not found`);
      return;
    }
    
    const content = fs.readFileSync(fullPath, 'utf8');
    const pageName = path.basename(path.dirname(pagePath));
    
    // Check for semantic section tags
    if (content.includes('<section') && content.includes('pricing')) {
      log(`  ✓ ${pageName}: Uses semantic <section> tags`, 'green');
      results.passed.push(`${pageName}: Semantic section tags`);
    } else {
      log(`  ⚠ ${pageName}: May not use semantic section tags`, 'yellow');
      results.warnings.push(`${pageName}: Semantic section tags`);
    }
    
    // Check for proper heading hierarchy
    const h2Match = content.match(/<h2[^>]*>.*?pricing.*?<\/h2>/gi);
    if (h2Match && h2Match.length > 0) {
      log(`  ✓ ${pageName}: Uses proper heading hierarchy (h2)`, 'green');
      results.passed.push(`${pageName}: Heading hierarchy`);
    } else {
      log(`  ⚠ ${pageName}: May not have proper heading hierarchy`, 'yellow');
      results.warnings.push(`${pageName}: Heading hierarchy`);
    }
    
    // Check for descriptive text in pricing blocks
    if (content.includes('pricing') && (content.includes('<p') || content.includes('<strong'))) {
      log(`  ✓ ${pageName}: Uses semantic text elements`, 'green');
      results.passed.push(`${pageName}: Semantic text elements`);
    } else {
      log(`  ⚠ ${pageName}: May not use semantic text elements`, 'yellow');
      results.warnings.push(`${pageName}: Semantic text elements`);
    }
  });
  
  return allPassed;
}

/**
 * Test 3: Pricing Links Clear Text (Requirement 13.3)
 */
function testPricingLinksClearText() {
  log('\n📋 Test 3: Pricing Links Clear Text', 'cyan');
  
  const pagesToTest = [
    'src/app/services/hosting/page.tsx',
    'src/app/services/photography/page.tsx',
    'src/app/services/ad-campaigns/page.tsx',
    'src/app/services/analytics/page.tsx',
    'src/components/layout/Header.tsx',
    'src/components/layout/Footer.tsx'
  ];
  
  let allPassed = true;
  
  pagesToTest.forEach(pagePath => {
    const fullPath = path.join(process.cwd(), pagePath);
    if (!fs.existsSync(fullPath)) {
      log(`  ⚠ ${pagePath} not found`, 'yellow');
      results.warnings.push(`Pricing links: ${pagePath} not found`);
      return;
    }
    
    const content = fs.readFileSync(fullPath, 'utf8');
    const pageName = path.basename(pagePath, '.tsx');
    
    // Check for pricing page links
    const pricingLinkMatch = content.match(/href=["']\/pricing["']/g);
    if (pricingLinkMatch && pricingLinkMatch.length > 0) {
      log(`  ✓ ${pageName}: Contains pricing page links`, 'green');
      results.passed.push(`${pageName}: Pricing page links present`);
      
      // Check for descriptive link text
      const linkTextPatterns = [
        /pricing page/i,
        /view full pricing/i,
        /pricing/i,
        /View full pricing/,
        /pricing page/
      ];
      
      let hasDescriptiveText = false;
      linkTextPatterns.forEach(pattern => {
        if (pattern.test(content)) {
          hasDescriptiveText = true;
        }
      });
      
      if (hasDescriptiveText) {
        log(`  ✓ ${pageName}: Pricing links have descriptive text`, 'green');
        results.passed.push(`${pageName}: Descriptive link text`);
      } else {
        log(`  ⚠ ${pageName}: Pricing links may lack descriptive text`, 'yellow');
        results.warnings.push(`${pageName}: Descriptive link text`);
      }
    } else {
      log(`  ⚠ ${pageName}: No pricing links found`, 'yellow');
      results.warnings.push(`${pageName}: No pricing links`);
    }
  });
  
  return allPassed;
}

/**
 * Test 4: Keyboard Navigation (Requirement 13.4)
 */
function testKeyboardNavigation() {
  log('\n📋 Test 4: Keyboard Navigation Support', 'cyan');
  
  const componentsToTest = [
    'src/app/page.tsx',
    'src/components/layout/Header.tsx',
    'src/components/layout/Footer.tsx'
  ];
  
  let allPassed = true;
  
  componentsToTest.forEach(componentPath => {
    const fullPath = path.join(process.cwd(), componentPath);
    if (!fs.existsSync(fullPath)) {
      log(`  ⚠ ${componentPath} not found`, 'yellow');
      results.warnings.push(`Keyboard nav: ${componentPath} not found`);
      return;
    }
    
    const content = fs.readFileSync(fullPath, 'utf8');
    const componentName = path.basename(componentPath, '.tsx');
    
    // Check for proper Link components (Next.js handles keyboard nav)
    const linkCount = (content.match(/<Link/g) || []).length;
    if (linkCount > 0) {
      log(`  ✓ ${componentName}: Uses ${linkCount} accessible Link components`, 'green');
      results.passed.push(`${componentName}: Accessible Link components`);
    }
    
    // Check for button elements with proper attributes
    const buttonMatches = content.match(/<button[^>]*>/g) || [];
    buttonMatches.forEach((button, index) => {
      if (button.includes('aria-label') || button.includes('aria-expanded')) {
        log(`  ✓ ${componentName}: Button ${index + 1} has ARIA attributes`, 'green');
        results.passed.push(`${componentName}: Button ${index + 1} ARIA attributes`);
      }
    });
    
    // Check for focus styles
    if (content.includes('focus:') || content.includes('focus-visible:')) {
      log(`  ✓ ${componentName}: Includes focus styles`, 'green');
      results.passed.push(`${componentName}: Focus styles`);
    } else {
      log(`  ⚠ ${componentName}: May lack focus styles`, 'yellow');
      results.warnings.push(`${componentName}: Focus styles`);
    }
  });
  
  return allPassed;
}

/**
 * Test 5: WCAG 2.1 Level AA Compliance (Requirement 13.5)
 */
function testWCAGCompliance() {
  log('\n📋 Test 5: WCAG 2.1 Level AA Compliance', 'cyan');
  
  const checks = [
    {
      name: 'Color Contrast',
      test: () => {
        // Check for proper color usage in Tailwind classes
        const homePage = fs.readFileSync(path.join(process.cwd(), 'src/app/page.tsx'), 'utf8');
        const hasGoodContrast = 
          homePage.includes('text-gray-900') && 
          homePage.includes('bg-white') ||
          homePage.includes('text-white') && 
          homePage.includes('bg-brand-black');
        return hasGoodContrast;
      }
    },
    {
      name: 'Text Alternatives',
      test: () => {
        // Check that images have alt text
        const pressLogos = fs.readFileSync(path.join(process.cwd(), 'src/components/PressLogos.tsx'), 'utf8');
        return pressLogos.includes('alt=');
      }
    },
    {
      name: 'Keyboard Accessible',
      test: () => {
        // Check for interactive elements using proper components
        const header = fs.readFileSync(path.join(process.cwd(), 'src/components/layout/Header.tsx'), 'utf8');
        return header.includes('<Link') && header.includes('<button');
      }
    },
    {
      name: 'Semantic HTML',
      test: () => {
        // Check for semantic elements
        const homePage = fs.readFileSync(path.join(process.cwd(), 'src/app/page.tsx'), 'utf8');
        return homePage.includes('<section') && homePage.includes('<nav');
      }
    },
    {
      name: 'Heading Hierarchy',
      test: () => {
        // Check for proper heading structure
        const homePage = fs.readFileSync(path.join(process.cwd(), 'src/app/page.tsx'), 'utf8');
        return homePage.includes('<h1') && homePage.includes('<h2') && homePage.includes('<h3');
      }
    },
    {
      name: 'Link Purpose',
      test: () => {
        // Check for descriptive link text
        const homePage = fs.readFileSync(path.join(process.cwd(), 'src/app/page.tsx'), 'utf8');
        return homePage.includes('aria-label') || homePage.includes('Learn more');
      }
    }
  ];
  
  let allPassed = true;
  
  checks.forEach(check => {
    try {
      if (check.test()) {
        log(`  ✓ ${check.name}: Compliant`, 'green');
        results.passed.push(`WCAG: ${check.name}`);
      } else {
        log(`  ✗ ${check.name}: Non-compliant`, 'red');
        results.failed.push(`WCAG: ${check.name}`);
        allPassed = false;
      }
    } catch (error) {
      log(`  ⚠ ${check.name}: Could not test (${error.message})`, 'yellow');
      results.warnings.push(`WCAG: ${check.name}`);
    }
  });
  
  return allPassed;
}

/**
 * Generate test report
 */
function generateReport() {
  log('\n' + '='.repeat(60), 'blue');
  log('ACCESSIBILITY TEST REPORT', 'blue');
  log('='.repeat(60), 'blue');
  
  log(`\n✅ Passed: ${results.passed.length}`, 'green');
  log(`❌ Failed: ${results.failed.length}`, 'red');
  log(`⚠️  Warnings: ${results.warnings.length}`, 'yellow');
  
  if (results.failed.length > 0) {
    log('\n❌ Failed Tests:', 'red');
    results.failed.forEach(test => log(`  - ${test}`, 'red'));
  }
  
  if (results.warnings.length > 0) {
    log('\n⚠️  Warnings:', 'yellow');
    results.warnings.forEach(warning => log(`  - ${warning}`, 'yellow'));
  }
  
  const timestamp = new Date().toISOString();
  const report = {
    timestamp,
    summary: {
      passed: results.passed.length,
      failed: results.failed.length,
      warnings: results.warnings.length,
      total: results.passed.length + results.failed.length + results.warnings.length
    },
    results: {
      passed: results.passed,
      failed: results.failed,
      warnings: results.warnings
    },
    requirements: {
      '13.1': 'Press logos have descriptive alt text',
      '13.2': 'Pricing cards use semantic HTML',
      '13.3': 'Pricing links have clear text',
      '13.4': 'Keyboard navigation works',
      '13.5': 'WCAG 2.1 Level AA standards'
    }
  };
  
  // Save JSON report
  const reportPath = path.join(process.cwd(), 'accessibility-test-report.json');
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
  log(`\n📄 Report saved to: ${reportPath}`, 'cyan');
  
  // Save markdown summary
  const summaryPath = path.join(process.cwd(), 'accessibility-test-summary.md');
  const summary = `# Accessibility Test Summary

**Generated:** ${new Date(timestamp).toLocaleString()}

## Overview

- ✅ **Passed:** ${results.passed.length}
- ❌ **Failed:** ${results.failed.length}
- ⚠️ **Warnings:** ${results.warnings.length}

## Requirements Coverage

| Requirement | Description | Status |
|-------------|-------------|--------|
| 13.1 | Press logos have descriptive alt text | ${results.failed.some(f => f.includes('Press logo')) ? '❌' : '✅'} |
| 13.2 | Pricing cards use semantic HTML | ${results.failed.some(f => f.includes('Semantic')) ? '❌' : '✅'} |
| 13.3 | Pricing links have clear text | ${results.failed.some(f => f.includes('link text')) ? '❌' : '✅'} |
| 13.4 | Keyboard navigation works | ${results.failed.some(f => f.includes('Keyboard')) ? '❌' : '✅'} |
| 13.5 | WCAG 2.1 Level AA standards | ${results.failed.some(f => f.includes('WCAG')) ? '❌' : '✅'} |

## Test Results

### ✅ Passed Tests (${results.passed.length})

${results.passed.map(test => `- ${test}`).join('\n')}

${results.failed.length > 0 ? `### ❌ Failed Tests (${results.failed.length})

${results.failed.map(test => `- ${test}`).join('\n')}` : ''}

${results.warnings.length > 0 ? `### ⚠️ Warnings (${results.warnings.length})

${results.warnings.map(warning => `- ${warning}`).join('\n')}` : ''}

## Conclusion

${results.failed.length === 0 
  ? '✅ All accessibility tests passed! The implementation meets WCAG 2.1 Level AA standards.' 
  : `❌ ${results.failed.length} test(s) failed. Please review and fix the issues above.`}
`;
  
  fs.writeFileSync(summaryPath, summary);
  log(`📄 Summary saved to: ${summaryPath}`, 'cyan');
  
  return results.failed.length === 0;
}

/**
 * Main test execution
 */
function runTests() {
  log('\n🚀 Starting Accessibility Compliance Tests', 'blue');
  log('Testing requirements 13.1 through 13.5\n', 'blue');
  
  const test1 = testPressLogosAltText();
  const test2 = testPricingCardsSemanticHTML();
  const test3 = testPricingLinksClearText();
  const test4 = testKeyboardNavigation();
  const test5 = testWCAGCompliance();
  
  const allPassed = generateReport();
  
  if (allPassed) {
    log('\n✅ All accessibility tests passed!', 'green');
    process.exit(0);
  } else {
    log('\n❌ Some accessibility tests failed. Please review the report.', 'red');
    process.exit(1);
  }
}

// Run tests
runTests();
