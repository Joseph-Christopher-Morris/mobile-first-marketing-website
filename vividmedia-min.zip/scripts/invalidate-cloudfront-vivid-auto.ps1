#!/usr/bin/env pwsh

<#
.SYNOPSIS
    CloudFront Cache Invalidation for Vivid Auto SCRAM Rebuild
    
.DESCRIPTION
    Dedicated script for CloudFront cache invalidation as per task 9.2 requirements.
    Invalidates the specified paths for distribution E2IBMHQ3GCW6ZK.
    
.PARAMETER Paths
    Custom paths to invalidate (optional, uses default paths if not specified)
    
.PARAMETER WaitForCompletion
    Wait for invalidation to complete before exiting
    
.PARAMETER Verbose
    Show detailed output
    
.EXAMPLE
    .\scripts\invalidate-cloudfront-vivid-auto.ps1
    
.EXAMPLE
    .\scripts\invalidate-cloudfront-vivid-auto.ps1 -WaitForCompletion -Verbose
    
.EXAMPLE
    .\scripts\invalidate-cloudfront-vivid-auto.ps1 -Paths @("/", "/services/*")
#>

param(
    [string[]]$Paths = @(),
    [switch]$WaitForCompletion = $false,
    [switch]$Verbose = $false
)

# Configuration from task requirements
$CLOUDFRONT_DISTRIBUTION_ID = "E2IBMHQ3GCW6ZK"
$AWS_REGION = "us-east-1"

# Default invalidation paths as specified in requirements 8.3
$DEFAULT_PATHS = @(
    "/",
    "/index.html", 
    "/services/*",
    "/blog*",
    "/images/*",
    "/sitemap.xml",
    "/_next/*"
)

function Write-Header {
    param([string]$Message)
    Write-Host ""
    Write-Host "🔄 $Message" -ForegroundColor Cyan
    Write-Host ("=" * ($Message.Length + 3)) -ForegroundColor Cyan
}

function Write-Success {
    param([string]$Message)
    Write-Host "✅ $Message" -ForegroundColor Green
}

function Write-Warning {
    param([string]$Message)
    Write-Host "⚠️  $Message" -ForegroundColor Yellow
}

function Write-Error {
    param([string]$Message)
    Write-Host "❌ $Message" -ForegroundColor Red
}

function Write-Info {
    param([string]$Message)
    Write-Host "ℹ️  $Message" -ForegroundColor Blue
}

function Write-Verbose {
    param([string]$Message)
    if ($Verbose) {
        Write-Host "🔍 $Message" -ForegroundColor Gray
    }
}

function Test-CloudFrontAccess {
    Write-Header "Verifying CloudFront Access"
    
    # Check AWS CLI
    try {
        $awsVersion = aws --version 2>$null
        if ($LASTEXITCODE -eq 0) {
            Write-Verbose "AWS CLI found: $($awsVersion.Split()[0])"
        } else {
            throw "AWS CLI not found"
        }
    } catch {
        Write-Error "AWS CLI is required but not found. Please install AWS CLI."
        exit 1
    }
    
    # Check AWS credentials
    try {
        $identity = aws sts get-caller-identity --output json 2>$null | ConvertFrom-Json
        if ($identity) {
            Write-Verbose "AWS credentials configured for: $($identity.Arn)"
        } else {
            throw "No AWS credentials"
        }
    } catch {
        Write-Error "AWS credentials not configured. Run 'aws configure' first."
        exit 1
    }
    
    # Verify CloudFront distribution access
    try {
        Write-Verbose "Testing access to CloudFront distribution: $CLOUDFRONT_DISTRIBUTION_ID"
        $distribution = aws cloudfront get-distribution --id $CLOUDFRONT_DISTRIBUTION_ID --region $AWS_REGION --output json 2>$null | ConvertFrom-Json
        
        if ($distribution -and $distribution.Distribution) {
            Write-Success "CloudFront distribution access verified"
            Write-Info "Distribution: $CLOUDFRONT_DISTRIBUTION_ID"
            Write-Info "Status: $($distribution.Distribution.Status)"
            Write-Info "Domain: $($distribution.Distribution.DomainName)"
            
            if ($Verbose) {
                Write-Verbose "Last Modified: $($distribution.Distribution.LastModifiedTime)"
                Write-Verbose "Price Class: $($distribution.Distribution.DistributionConfig.PriceClass)"
            }
        } else {
            throw "Invalid distribution response"
        }
    } catch {
        Write-Error "Cannot access CloudFront distribution: $CLOUDFRONT_DISTRIBUTION_ID"
        Write-Info "Please verify:"
        Write-Info "1. Distribution ID is correct"
        Write-Info "2. AWS credentials have CloudFront permissions"
        Write-Info "3. Distribution exists and is accessible"
        exit 1
    }
}

function Start-CacheInvalidation {
    param([string[]]$PathsToInvalidate)
    
    Write-Header "Starting Cache Invalidation"
    
    # Use default paths if none provided
    if ($PathsToInvalidate.Count -eq 0) {
        $PathsToInvalidate = $DEFAULT_PATHS
        Write-Info "Using default invalidation paths"
    } else {
        Write-Info "Using custom invalidation paths"
    }
    
    Write-Info "Paths to invalidate ($($PathsToInvalidate.Count)):"
    foreach ($path in $PathsToInvalidate) {
        Write-Info "  - $path"
    }
    
    # Generate caller reference (must be unique)
    $callerReference = "vivid-auto-scram-$(Get-Date -Format 'yyyyMMdd-HHmmss-fff')"
    Write-Verbose "Caller Reference: $callerReference"
    
    try {
        Write-Info "Creating invalidation request..."
        
        $result = aws cloudfront create-invalidation `
            --distribution-id $CLOUDFRONT_DISTRIBUTION_ID `
            --paths $PathsToInvalidate `
            --region $AWS_REGION `
            --output json 2>$null
        
        if ($LASTEXITCODE -eq 0 -and $result) {
            $invalidation = $result | ConvertFrom-Json
            
            Write-Success "Cache invalidation started successfully"
            Write-Info "Invalidation ID: $($invalidation.Invalidation.Id)"
            Write-Info "Status: $($invalidation.Invalidation.Status)"
            Write-Info "Create Time: $($invalidation.Invalidation.CreateTime)"
            
            if ($Verbose) {
                Write-Verbose "Caller Reference: $($invalidation.Invalidation.InvalidationBatch.CallerReference)"
                Write-Verbose "Paths Count: $($invalidation.Invalidation.InvalidationBatch.Paths.Quantity)"
            }
            
            return $invalidation.Invalidation.Id
        } else {
            throw "CloudFront invalidation command failed (Exit code: $LASTEXITCODE)"
        }
    } catch {
        Write-Error "Cache invalidation failed: $_"
        Write-Info "Common issues:"
        Write-Info "1. Invalid distribution ID"
        Write-Info "2. Insufficient CloudFront permissions"
        Write-Info "3. Too many concurrent invalidations (limit: 3)"
        Write-Info "4. Invalid path format"
        exit 1
    }
}

function Wait-ForInvalidationCompletion {
    param([string]$InvalidationId)
    
    if (-not $WaitForCompletion) {
        Write-Info "Note: Invalidation may take 5-15 minutes to complete"
        Write-Info "Use -WaitForCompletion to wait for completion"
        return
    }
    
    Write-Header "Waiting for Invalidation Completion"
    Write-Info "Invalidation ID: $InvalidationId"
    Write-Info "This may take 5-15 minutes..."
    
    $maxWaitTime = 20 * 60  # 20 minutes max
    $checkInterval = 30     # Check every 30 seconds
    $elapsedTime = 0
    
    while ($elapsedTime -lt $maxWaitTime) {
        try {
            $status = aws cloudfront get-invalidation `
                --distribution-id $CLOUDFRONT_DISTRIBUTION_ID `
                --id $InvalidationId `
                --region $AWS_REGION `
                --output json 2>$null | ConvertFrom-Json
            
            if ($status -and $status.Invalidation) {
                $currentStatus = $status.Invalidation.Status
                Write-Info "Status: $currentStatus (Elapsed: $([math]::Round($elapsedTime/60, 1)) minutes)"
                
                if ($currentStatus -eq "Completed") {
                    Write-Success "Invalidation completed successfully!"
                    Write-Info "Total time: $([math]::Round($elapsedTime/60, 1)) minutes"
                    return
                }
                
                if ($currentStatus -eq "InProgress") {
                    Write-Verbose "Invalidation still in progress..."
                } else {
                    Write-Warning "Unexpected status: $currentStatus"
                }
            } else {
                Write-Warning "Could not retrieve invalidation status"
            }
        } catch {
            Write-Warning "Error checking invalidation status: $_"
        }
        
        Start-Sleep -Seconds $checkInterval
        $elapsedTime += $checkInterval
    }
    
    Write-Warning "Timeout waiting for invalidation completion"
    Write-Info "Invalidation may still be in progress. Check AWS Console for status."
}

function Show-InvalidationSummary {
    param([string]$InvalidationId, [string[]]$PathsInvalidated)
    
    Write-Header "Invalidation Summary"
    
    Write-Info "Distribution: $CLOUDFRONT_DISTRIBUTION_ID"
    Write-Info "Invalidation ID: $InvalidationId"
    Write-Info "Paths Invalidated: $($PathsInvalidated.Count)"
    Write-Info "Completed: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    
    Write-Success "CloudFront cache invalidation completed!"
    Write-Info ""
    Write-Info "🌐 Changes will propagate to all edge locations"
    Write-Info "⏱️  Full propagation typically takes 5-15 minutes"
    Write-Info "🔍 Monitor status in AWS CloudFront Console"
}

# Main execution
function Main {
    Write-Header "CloudFront Cache Invalidation - Vivid Auto SCRAM"
    Write-Info "Distribution: $CLOUDFRONT_DISTRIBUTION_ID"
    Write-Info "Region: $AWS_REGION"
    
    if ($Paths.Count -gt 0) {
        Write-Info "Custom paths: $($Paths.Count)"
    } else {
        Write-Info "Using default paths: $($DEFAULT_PATHS.Count)"
    }
    
    try {
        # Step 1: Verify CloudFront access
        Test-CloudFrontAccess
        
        # Step 2: Start cache invalidation
        $pathsToUse = if ($Paths.Count -gt 0) { $Paths } else { $DEFAULT_PATHS }
        $invalidationId = Start-CacheInvalidation $pathsToUse
        
        # Step 3: Wait for completion if requested
        Wait-ForInvalidationCompletion $invalidationId
        
        # Step 4: Show summary
        Show-InvalidationSummary $invalidationId $pathsToUse
        
    } catch {
        Write-Error "Invalidation process failed: $_"
        Write-Info ""
        Write-Info "🔧 Troubleshooting:"
        Write-Info "1. Verify AWS credentials: aws sts get-caller-identity"
        Write-Info "2. Check CloudFront permissions"
        Write-Info "3. Ensure distribution ID is correct: $CLOUDFRONT_DISTRIBUTION_ID"
        Write-Info "4. Check for concurrent invalidations (max 3)"
        exit 1
    }
}

# Execute main function
Main