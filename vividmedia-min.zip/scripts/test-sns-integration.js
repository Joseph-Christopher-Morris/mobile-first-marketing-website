#!/usr/bin/env node

/**
 * Test SNS Integration for CloudFront Pretty URLs
 * 
 * Comprehensive testing script for SNS integration and notification system
 * 
 * Requirements: 8.4, 7.4
 * Task: 7.2.3 Set up SNS integration and notification system
 */

const AWS = require('aws-sdk');
const fs = require('fs').promises;
const path = require('path');

class SNSIntegrationTester {
    constructor() {
        this.sns = new AWS.SNS({ region: 'us-east-1' });
        this.cloudwatch = new AWS.CloudWatch({ region: 'us-east-1' });
        this.events = new AWS.CloudWatchEvents({ region: 'us-east-1' });
        
        this.config = null;
        this.snsTopicArn = null;
        this.testResults = [];
    }

    async loadConfig() {
        try {
            const configPath = path.join(__dirname, '..', 'config', 'cloudfront-pretty-urls-monitoring-config.json');
            const configData = await fs.readFile(configPath, 'utf8');
            this.config = JSON.parse(configData);
            
            console.log('✅ Configuration loaded successfully');
            return this.config;
        } catch (error) {
            console.error('❌ Failed to load configuration:', error.message);
            throw error;
        }
    }

    async findSNSTopic() {
        try {
            const topicName = this.config.alerting.snsTopicName;
            const topics = await this.sns.listTopics().promise();
            const topic = topics.Topics.find(t => t.TopicArn.includes(topicName));
            
            if (!topic) {
                throw new Error(`SNS topic '${topicName}' not found`);
            }
            
            this.snsTopicArn = topic.TopicArn;
            console.log(`✅ Found SNS topic: ${this.snsTopicArn}`);
            return this.snsTopicArn;
        } catch (error) {
            console.error('❌ Failed to find SNS topic:', error.message);
            throw error;
        }
    }

    async testSNSTopicConfiguration() {
        try {
            console.log('🧪 Testing SNS topic configuration...');
            
            const topicAttributes = await this.sns.getTopicAttributes({
                TopicArn: this.snsTopicArn
            }).promise();

            const test = {
                name: 'SNS Topic Configuration',
                status: 'PASS',
                details: {
                    topicArn: this.snsTopicArn,
                    displayName: topicAttributes.Attributes.DisplayName,
                    policy: JSON.parse(topicAttributes.Attributes.Policy || '{}'),
                    deliveryPolicy: JSON.parse(topicAttributes.Attributes.DeliveryPolicy || '{}')
                },
                checks: []
            };

            // Check if topic has proper display name
            if (topicAttributes.Attributes.DisplayName) {
                test.checks.push({ check: 'Display Name Set', status: 'PASS' });
            } else {
                test.checks.push({ check: 'Display Name Set', status: 'FAIL' });
                test.status = 'FAIL';
            }

            // Check if topic has policy allowing CloudWatch
            const policy = JSON.parse(topicAttributes.Attributes.Policy || '{}');
            const hasCloudWatchPermission = policy.Statement && policy.Statement.some(
                stmt => stmt.Principal && stmt.Principal.Service === 'cloudwatch.amazonaws.com'
            );

            if (hasCloudWatchPermission) {
                test.checks.push({ check: 'CloudWatch Permissions', status: 'PASS' });
            } else {
                test.checks.push({ check: 'CloudWatch Permissions', status: 'FAIL' });
                test.status = 'FAIL';
            }

            this.testResults.push(test);
            console.log(`${test.status === 'PASS' ? '✅' : '❌'} SNS Topic Configuration: ${test.status}`);
            
            return test;
        } catch (error) {
            const test = {
                name: 'SNS Topic Configuration',
                status: 'ERROR',
                error: error.message
            };
            this.testResults.push(test);
            console.error('❌ SNS Topic Configuration test failed:', error.message);
            return test;
        }
    }

    async testSubscriptions() {
        try {
            console.log('📧 Testing SNS subscriptions...');
            
            const subscriptions = await this.sns.listSubscriptionsByTopic({
                TopicArn: this.snsTopicArn
            }).promise();

            const test = {
                name: 'SNS Subscriptions',
                status: 'PASS',
                details: {
                    totalSubscriptions: subscriptions.Subscriptions.length,
                    confirmedSubscriptions: 0,
                    pendingSubscriptions: 0,
                    protocols: {}
                },
                subscriptions: []
            };

            for (const sub of subscriptions.Subscriptions) {
                const subDetails = {
                    protocol: sub.Protocol,
                    endpoint: sub.Endpoint,
                    confirmed: sub.SubscriptionArn !== 'PendingConfirmation'
                };

                test.subscriptions.push(subDetails);

                if (subDetails.confirmed) {
                    test.details.confirmedSubscriptions++;
                } else {
                    test.details.pendingSubscriptions++;
                }

                test.details.protocols[sub.Protocol] = (test.details.protocols[sub.Protocol] || 0) + 1;
            }

            // Test passes if there's at least one subscription
            if (test.details.totalSubscriptions === 0) {
                test.status = 'WARN';
                test.message = 'No subscriptions configured';
            } else if (test.details.confirmedSubscriptions === 0) {
                test.status = 'WARN';
                test.message = 'No confirmed subscriptions - check email confirmations';
            }

            this.testResults.push(test);
            console.log(`${test.status === 'PASS' ? '✅' : test.status === 'WARN' ? '⚠️' : '❌'} SNS Subscriptions: ${test.status}`);
            
            return test;
        } catch (error) {
            const test = {
                name: 'SNS Subscriptions',
                status: 'ERROR',
                error: error.message
            };
            this.testResults.push(test);
            console.error('❌ SNS Subscriptions test failed:', error.message);
            return test;
        }
    }

    async testAlarmIntegration() {
        try {
            console.log('🚨 Testing alarm SNS integration...');
            
            const alarms = await this.cloudwatch.describeAlarms({
                AlarmNamePrefix: 'CloudFront-PrettyURLs-'
            }).promise();

            const compositeAlarms = await this.cloudwatch.describeAlarms({
                AlarmTypes: ['CompositeAlarm'],
                AlarmNamePrefix: 'CloudFront-PrettyURLs-'
            }).promise();

            const test = {
                name: 'Alarm SNS Integration',
                status: 'PASS',
                details: {
                    totalAlarms: alarms.MetricAlarms.length + compositeAlarms.CompositeAlarms.length,
                    alarmsWithSNS: 0,
                    alarmsWithoutSNS: 0,
                    criticalAlarms: 0,
                    warningAlarms: 0
                },
                alarms: []
            };

            // Check metric alarms
            for (const alarm of alarms.MetricAlarms) {
                const hasSNS = alarm.AlarmActions && alarm.AlarmActions.includes(this.snsTopicArn);
                const alarmDetails = {
                    name: alarm.AlarmName,
                    type: 'MetricAlarm',
                    hasSNSAction: hasSNS,
                    state: alarm.StateValue
                };

                test.alarms.push(alarmDetails);

                if (hasSNS) {
                    test.details.alarmsWithSNS++;
                } else {
                    test.details.alarmsWithoutSNS++;
                }

                if (alarm.AlarmName.includes('Critical')) {
                    test.details.criticalAlarms++;
                } else if (alarm.AlarmName.includes('Warning')) {
                    test.details.warningAlarms++;
                }
            }

            // Check composite alarms
            for (const alarm of compositeAlarms.CompositeAlarms) {
                const hasSNS = alarm.AlarmActions && alarm.AlarmActions.includes(this.snsTopicArn);
                const alarmDetails = {
                    name: alarm.AlarmName,
                    type: 'CompositeAlarm',
                    hasSNSAction: hasSNS,
                    state: alarm.StateValue
                };

                test.alarms.push(alarmDetails);

                if (hasSNS) {
                    test.details.alarmsWithSNS++;
                } else {
                    test.details.alarmsWithoutSNS++;
                }
            }

            // Test fails if any alarms don't have SNS actions
            if (test.details.alarmsWithoutSNS > 0) {
                test.status = 'FAIL';
                test.message = `${test.details.alarmsWithoutSNS} alarms missing SNS actions`;
            }

            this.testResults.push(test);
            console.log(`${test.status === 'PASS' ? '✅' : '❌'} Alarm SNS Integration: ${test.status}`);
            
            return test;
        } catch (error) {
            const test = {
                name: 'Alarm SNS Integration',
                status: 'ERROR',
                error: error.message
            };
            this.testResults.push(test);
            console.error('❌ Alarm SNS Integration test failed:', error.message);
            return test;
        }
    }

    async testEventRules() {
        try {
            console.log('📢 Testing CloudWatch Events rules...');
            
            const rules = await this.events.listRules({
                NamePrefix: 'CloudFront-PrettyURLs-'
            }).promise();

            const test = {
                name: 'CloudWatch Events Rules',
                status: 'PASS',
                details: {
                    totalRules: rules.Rules.length,
                    enabledRules: 0,
                    rulesWithTargets: 0
                },
                rules: []
            };

            for (const rule of rules.Rules) {
                const targets = await this.events.listTargetsByRule({
                    Rule: rule.Name
                }).promise();

                const hasSNSTarget = targets.Targets.some(target => target.Arn === this.snsTopicArn);

                const ruleDetails = {
                    name: rule.Name,
                    state: rule.State,
                    targetsCount: targets.Targets.length,
                    hasSNSTarget: hasSNSTarget
                };

                test.rules.push(ruleDetails);

                if (rule.State === 'ENABLED') {
                    test.details.enabledRules++;
                }

                if (targets.Targets.length > 0) {
                    test.details.rulesWithTargets++;
                }
            }

            // Test passes if there's at least one enabled rule with SNS target
            const hasValidRule = test.rules.some(rule => 
                rule.state === 'ENABLED' && rule.hasSNSTarget
            );

            if (!hasValidRule) {
                test.status = 'FAIL';
                test.message = 'No enabled rules with SNS targets found';
            }

            this.testResults.push(test);
            console.log(`${test.status === 'PASS' ? '✅' : '❌'} CloudWatch Events Rules: ${test.status}`);
            
            return test;
        } catch (error) {
            const test = {
                name: 'CloudWatch Events Rules',
                status: 'ERROR',
                error: error.message
            };
            this.testResults.push(test);
            console.error('❌ CloudWatch Events Rules test failed:', error.message);
            return test;
        }
    }

    async testNotificationDelivery() {
        try {
            console.log('📤 Testing notification delivery...');
            
            const testMessage = {
                version: '1.0',
                source: 'CloudFront Pretty URLs Monitoring - INTEGRATION TEST',
                alert: {
                    type: 'integration-test',
                    severity: 'INFO',
                    alarm: 'INTEGRATION-TEST-ALARM',
                    state: {
                        current: 'OK',
                        previous: 'UNKNOWN',
                        reason: 'Integration test notification - SNS delivery verification',
                        timestamp: new Date().toISOString()
                    },
                    metadata: {
                        region: 'us-east-1',
                        component: 'CloudFront-PrettyURLs',
                        testId: `test-${Date.now()}`
                    },
                    actions: {
                        dashboardUrl: `https://us-east-1.console.aws.amazon.com/cloudwatch/home?region=us-east-1#dashboards:name=${this.config.dashboard.name}`,
                        message: 'This is an integration test. If you receive this, SNS delivery is working!'
                    }
                }
            };

            const publishResult = await this.sns.publish({
                TopicArn: this.snsTopicArn,
                Message: JSON.stringify(testMessage, null, 2),
                Subject: '[INTEGRATION TEST] CloudFront Pretty URLs - SNS Delivery Test',
                MessageAttributes: {
                    severity: {
                        DataType: 'String',
                        StringValue: 'Info'
                    },
                    component: {
                        DataType: 'String',
                        StringValue: 'CloudFront-PrettyURLs'
                    },
                    testType: {
                        DataType: 'String',
                        StringValue: 'integration-test'
                    }
                }
            }).promise();

            const test = {
                name: 'Notification Delivery',
                status: 'PASS',
                details: {
                    messageId: publishResult.MessageId,
                    topicArn: this.snsTopicArn,
                    timestamp: new Date().toISOString()
                },
                message: 'Test notification sent successfully - check email/Slack for delivery'
            };

            this.testResults.push(test);
            console.log(`✅ Notification Delivery: ${test.status}`);
            console.log(`   Message ID: ${publishResult.MessageId}`);
            console.log('   📧 Check your configured endpoints for the test message');
            
            return test;
        } catch (error) {
            const test = {
                name: 'Notification Delivery',
                status: 'ERROR',
                error: error.message
            };
            this.testResults.push(test);
            console.error('❌ Notification Delivery test failed:', error.message);
            return test;
        }
    }

    async generateTestReport() {
        try {
            const summary = {
                totalTests: this.testResults.length,
                passed: this.testResults.filter(t => t.status === 'PASS').length,
                failed: this.testResults.filter(t => t.status === 'FAIL').length,
                warnings: this.testResults.filter(t => t.status === 'WARN').length,
                errors: this.testResults.filter(t => t.status === 'ERROR').length
            };

            const overallStatus = summary.failed > 0 || summary.errors > 0 ? 'FAILED' : 
                                 summary.warnings > 0 ? 'PASSED_WITH_WARNINGS' : 'PASSED';

            const report = {
                timestamp: new Date().toISOString(),
                overallStatus: overallStatus,
                summary: summary,
                snsTopicArn: this.snsTopicArn,
                configuration: {
                    distributionId: this.config.monitoring.distributionId,
                    functionName: this.config.monitoring.functionName,
                    region: this.config.monitoring.region
                },
                testResults: this.testResults,
                recommendations: []
            };

            // Add recommendations based on test results
            if (summary.failed > 0 || summary.errors > 0) {
                report.recommendations.push('Fix failed tests before proceeding to production');
            }

            if (summary.warnings > 0) {
                report.recommendations.push('Address warnings to ensure optimal notification delivery');
            }

            const subscriptionTest = this.testResults.find(t => t.name === 'SNS Subscriptions');
            if (subscriptionTest && subscriptionTest.details && subscriptionTest.details.pendingSubscriptions > 0) {
                report.recommendations.push('Confirm pending email subscriptions by checking email and clicking confirmation links');
            }

            const alarmTest = this.testResults.find(t => t.name === 'Alarm SNS Integration');
            if (alarmTest && alarmTest.details && alarmTest.details.alarmsWithoutSNS > 0) {
                report.recommendations.push('Update remaining alarms to include SNS actions using update-alarms-with-sns.js');
            }

            // Save report
            const reportPath = path.join(__dirname, '..', 'logs', `sns-integration-test-report-${Date.now()}.json`);
            await fs.writeFile(reportPath, JSON.stringify(report, null, 2));

            // Create summary markdown
            const summaryPath = path.join(__dirname, '..', 'logs', `sns-integration-test-summary-${Date.now()}.md`);
            const summaryContent = `
# SNS Integration Test Results

## Overall Status: ${overallStatus}

## Test Summary
- **Total Tests**: ${summary.totalTests}
- **Passed**: ${summary.passed} ✅
- **Failed**: ${summary.failed} ❌
- **Warnings**: ${summary.warnings} ⚠️
- **Errors**: ${summary.errors} 🚫

## Test Results
${this.testResults.map(test => `
### ${test.name}
- **Status**: ${test.status} ${test.status === 'PASS' ? '✅' : test.status === 'WARN' ? '⚠️' : '❌'}
- **Details**: ${test.message || 'See full report for details'}
`).join('')}

## Recommendations
${report.recommendations.map(rec => `- ${rec}`).join('\n')}

## Configuration
- **SNS Topic**: ${this.snsTopicArn}
- **Distribution**: ${this.config.monitoring.distributionId}
- **Function**: ${this.config.monitoring.functionName}

## Next Steps
1. Address any failed tests or warnings
2. Confirm email subscriptions if pending
3. Test alarm notifications in production
4. Monitor notification delivery and adjust as needed

Generated: ${new Date().toISOString()}
            `;

            await fs.writeFile(summaryPath, summaryContent);

            console.log(`✅ Test report generated:`);
            console.log(`   JSON Report: ${reportPath}`);
            console.log(`   Summary: ${summaryPath}`);

            return report;
        } catch (error) {
            console.error('❌ Failed to generate test report:', error.message);
            throw error;
        }
    }

    async runCompleteTest() {
        try {
            console.log('🧪 Running complete SNS integration test suite...\n');

            // Load configuration
            await this.loadConfig();

            // Find SNS topic
            await this.findSNSTopic();

            // Run all tests
            await this.testSNSTopicConfiguration();
            await this.testSubscriptions();
            await this.testAlarmIntegration();
            await this.testEventRules();
            await this.testNotificationDelivery();

            // Generate report
            const report = await this.generateTestReport();

            console.log('\n🎯 SNS Integration Test Complete!');
            console.log(`\n📊 Results: ${report.overallStatus}`);
            console.log(`   Passed: ${report.summary.passed}/${report.summary.totalTests}`);
            
            if (report.summary.failed > 0) {
                console.log(`   Failed: ${report.summary.failed} ❌`);
            }
            if (report.summary.warnings > 0) {
                console.log(`   Warnings: ${report.summary.warnings} ⚠️`);
            }

            return report;

        } catch (error) {
            console.error('❌ SNS integration test failed:', error.message);
            throw error;
        }
    }
}

// CLI execution
async function main() {
    const tester = new SNSIntegrationTester();
    
    try {
        const report = await tester.runCompleteTest();
        
        if (report.overallStatus === 'PASSED') {
            process.exit(0);
        } else {
            console.log('\n⚠️ Some tests failed or have warnings. Check the report for details.');
            process.exit(1);
        }
    } catch (error) {
        console.error('❌ SNS integration testing failed:', error.message);
        process.exit(1);
    }
}

// Run if called directly
if (require.main === module) {
    main();
}

module.exports = SNSIntegrationTester;