#!/usr/bin/env node

/**
 * CloudFront Function Association Test Script
 * 
 * This script tests the CloudFront Function association with cache behavior
 * to ensure the pretty URLs functionality is properly integrated.
 */

const { 
    CloudFrontClient, 
    GetDistributionConfigCommand,
    DescribeFunctionCommand
} = require('@aws-sdk/client-cloudfront');

class CloudFrontFunctionAssociationTester {
    constructor() {
        this.client = new CloudFrontClient({ 
            region: 'us-east-1'
        });
        
        this.DISTRIBUTION_ID = process.env.CLOUDFRONT_DISTRIBUTION_ID || 'E2IBMHQ3GCW6ZK';
        this.FUNCTION_NAME = 'pretty-urls-rewriter';
        
        console.log(`🧪 Testing CloudFront Function Association`);
        console.log(`📋 Distribution ID: ${this.DISTRIBUTION_ID}`);
        console.log(`🔧 Function Name: ${this.FUNCTION_NAME}`);
    }

    /**
     * Run comprehensive function association tests
     */
    async runTests() {
        try {
            console.log('\n🚀 Starting CloudFront Function Association Tests...\n');

            const results = {
                distributionConfig: false,
                functionExists: false,
                functionAssociated: false,
                cacheBehaviorIntegrity: false,
                securityHeadersPreserved: false
            };

            // Test 1: Verify dist
ribution configuration access
            console.log('1️⃣ Testing distribution configuration access...');
            const distributionConfig = await this.testDistributionAccess();
            if (distributionConfig) {
                results.distributionConfig = true;
                console.log('   ✅ Distribution configuration accessible\n');
            } else {
                console.log('   ❌ Failed to access distribution configuration\n');
                return results;
            }

            // Test 2: Verify CloudFront Function exists
            console.log('2️⃣ Testing CloudFront Function existence...');
            const functionExists = await this.testFunctionExists();
            if (functionExists) {
                results.functionExists = true;
                console.log('   ✅ CloudFront Function exists and is published\n');
            } else {
                console.log('   ❌ CloudFront Function not found or not published\n');
            }

            // Test 3: Verify function association with cache behavior
            console.log('3️⃣ Testing function association with cache behavior...');
            const functionAssociated = await this.testFunctionAssociation(distributionConfig);
            if (functionAssociated) {
                results.functionAssociated = true;
                console.log('   ✅ Function correctly associated with viewer-request events\n');
            } else {
                console.log('   ❌ Function not properly associated with cache behavior\n');
            }

            // Test 4: Verify cache behavior integrity
            console.log('4️⃣ Testing cache behavior integrity...');
            const cacheBehaviorIntact = await this.testCacheBehaviorIntegrity(distributionConfig);
            if (cacheBehaviorIntact) {
                results.cacheBehaviorIntegrity = true;
                console.log('   ✅ Cache behavior settings preserved\n');
            } else {
                console.log('   ❌ Cache behavior integrity compromised\n');
            }

            // Test 5: Verify security headers preservation
            console.log('5️⃣ Testing security headers preservation...');
            const securityHeadersPreserved = await this.testSecurityHeaders(distributionConfig);
            if (securityHeadersPreserved) {
                results.securityHeadersPreserved = true;
                console.log('   ✅ Security headers configuration preserved\n');
            } else {
                console.log('   ⚠️  Security headers configuration may have changed\n');
            }

            // Generate test report
            await this.generateTestReport(results);

            return results;

        } catch (error) {
            console.error('❌ Test execution failed:', error.message);
            throw error;
        }
    }

    /**
     * Test distribution configuration access
     */
    async testDistributionAccess() {
        try {
            const command = new GetDistributionConfigCommand({
                Id: this.DISTRIBUTION_ID
            });
            
            const response = await this.client.send(command);
            
            console.log(`   📊 Distribution Status: ${response.DistributionConfig.Enabled ? 'Enabled' : 'Disabled'}`);
            console.log(`   🌐 Domain Name: ${response.DistributionConfig.DomainName || 'Not available'}`);
            console.log(`   📄 Default Root Object: ${response.DistributionConfig.DefaultRootObject || 'Not set'}`);
            
            return response;
            
        } catch (error) {
            console.log(`   ❌ Error accessing distribution: ${error.message}`);
            return null;
        }
    }

    /**
     * Test CloudFront Function existence and status
     */
    async testFunctionExists() {
        try {
            const command = new DescribeFunctionCommand({
                Name: this.FUNCTION_NAME,
                Stage: 'LIVE'
            });
            
            const response = await this.client.send(command);
            
            console.log(`   🔧 Function Name: ${response.FunctionSummary.Name}`);
            console.log(`   📝 Function Comment: ${response.FunctionSummary.FunctionMetadata.FunctionARN}`);
            console.log(`   🚀 Stage: ${response.FunctionSummary.Stage}`);
            console.log(`   📅 Last Modified: ${response.FunctionSummary.FunctionMetadata.LastModifiedTime}`);
            
            return true;
            
        } catch (error) {
            if (error.name === 'NoSuchFunctionExists') {
                console.log(`   ❌ Function '${this.FUNCTION_NAME}' does not exist`);
            } else {
                console.log(`   ❌ Error checking function: ${error.message}`);
            }
            return false;
        }
    }

    /**
     * Test function association with cache behavior
     */
    async testFunctionAssociation(distributionConfig) {
        try {
            const cacheBehavior = distributionConfig.DistributionConfig.DefaultCacheBehavior;
            const functionAssociations = cacheBehavior.FunctionAssociations;
            
            if (!functionAssociations || functionAssociations.Quantity === 0) {
                console.log(`   ❌ No function associations found`);
                return false;
            }
            
            console.log(`   📋 Total function associations: ${functionAssociations.Quantity}`);
            
            // Check for our specific function
            const prettyUrlsFunction = functionAssociations.Items.find(
                item => item.EventType === 'viewer-request' && 
                       item.FunctionARN.includes(this.FUNCTION_NAME)
            );
            
            if (prettyUrlsFunction) {
                console.log(`   ✅ Pretty URLs function found in viewer-request associations`);
                console.log(`   🔗 Function ARN: ${prettyUrlsFunction.FunctionARN}`);
                
                // List all associations for completeness
                console.log(`   📝 All function associations:`);
                functionAssociations.Items.forEach((func, index) => {
                    const isOurFunction = func.FunctionARN.includes(this.FUNCTION_NAME);
                    const marker = isOurFunction ? '👉' : '  ';
                    console.log(`   ${marker} ${index + 1}. ${func.EventType}: ${func.FunctionARN}`);
                });
                
                return true;
            } else {
                console.log(`   ❌ Pretty URLs function not found in associations`);
                console.log(`   📝 Available associations:`);
                functionAssociations.Items.forEach((func, index) => {
                    console.log(`      ${index + 1}. ${func.EventType}: ${func.FunctionARN}`);
                });
                return false;
            }
            
        } catch (error) {
            console.log(`   ❌ Error testing function association: ${error.message}`);
            return false;
        }
    }

    /**
     * Test cache behavior integrity
     */
    async testCacheBehaviorIntegrity(distributionConfig) {
        try {
            const cacheBehavior = distributionConfig.DistributionConfig.DefaultCacheBehavior;
            
            console.log(`   🎯 Target Origin ID: ${cacheBehavior.TargetOriginId}`);
            console.log(`   🔒 Viewer Protocol Policy: ${cacheBehavior.ViewerProtocolPolicy}`);
            console.log(`   📦 Compress: ${cacheBehavior.Compress}`);
            console.log(`   ⏱️  TTL - Min: ${cacheBehavior.MinTTL}, Default: ${cacheBehavior.DefaultTTL}, Max: ${cacheBehavior.MaxTTL}`);
            
            // Check for essential policies
            if (cacheBehavior.CachePolicyId) {
                console.log(`   📋 Cache Policy ID: ${cacheBehavior.CachePolicyId}`);
            }
            
            if (cacheBehavior.OriginRequestPolicyId) {
                console.log(`   📋 Origin Request Policy ID: ${cacheBehavior.OriginRequestPolicyId}`);
            }
            
            // Verify essential settings are present
            const essentialSettings = [
                cacheBehavior.TargetOriginId,
                cacheBehavior.ViewerProtocolPolicy
            ];
            
            const allSettingsPresent = essentialSettings.every(setting => setting !== undefined && setting !== null);
            
            if (allSettingsPresent) {
                console.log(`   ✅ Essential cache behavior settings are intact`);
                return true;
            } else {
                console.log(`   ❌ Some essential cache behavior settings are missing`);
                return false;
            }
            
        } catch (error) {
            console.log(`   ❌ Error testing cache behavior integrity: ${error.message}`);
            return false;
        }
    }

    /**
     * Test security headers preservation
     */
    async testSecurityHeaders(distributionConfig) {
        try {
            const cacheBehavior = distributionConfig.DistributionConfig.DefaultCacheBehavior;
            
            if (cacheBehavior.ResponseHeadersPolicyId) {
                console.log(`   🔒 Response Headers Policy ID: ${cacheBehavior.ResponseHeadersPolicyId}`);
                console.log(`   ✅ Security headers policy is configured`);
                return true;
            } else if (cacheBehavior.ResponseHeadersPolicy) {
                console.log(`   🔒 Custom response headers policy detected`);
                console.log(`   ✅ Security headers are configured`);
                return true;
            } else {
                console.log(`   ⚠️  No response headers policy found`);
                console.log(`   ℹ️  Security headers may be configured at origin or elsewhere`);
                // Return true as this is not necessarily a failure
                return true;
            }
            
        } catch (error) {
            console.log(`   ❌ Error testing security headers: ${error.message}`);
            return false;
        }
    }

    /**
     * Generate comprehensive test report
     */
    async generateTestReport(results) {
        console.log('\n📊 TEST REPORT SUMMARY');
        console.log('========================\n');
        
        const testResults = [
            { name: 'Distribution Configuration Access', passed: results.distributionConfig },
            { name: 'CloudFront Function Exists', passed: results.functionExists },
            { name: 'Function Association with Cache Behavior', passed: results.functionAssociated },
            { name: 'Cache Behavior Integrity', passed: results.cacheBehaviorIntegrity },
            { name: 'Security Headers Preservation', passed: results.securityHeadersPreserved }
        ];
        
        let passedTests = 0;
        testResults.forEach((test, index) => {
            const status = test.passed ? '✅ PASS' : '❌ FAIL';
            console.log(`${index + 1}. ${test.name}: ${status}`);
            if (test.passed) passedTests++;
        });
        
        const totalTests = testResults.length;
        const successRate = Math.round((passedTests / totalTests) * 100);
        
        console.log(`\n📈 Overall Success Rate: ${passedTests}/${totalTests} (${successRate}%)`);
        
        if (passedTests === totalTests) {
            console.log('🎉 All tests passed! CloudFront Function association is working correctly.');
        } else {
            console.log('⚠️  Some tests failed. Please review the configuration.');
        }
        
        // Generate timestamp for report
        const timestamp = new Date().toISOString();
        console.log(`\n📅 Test completed at: ${timestamp}`);
        
        // Save results to file for reference
        const reportData = {
            timestamp,
            distributionId: this.DISTRIBUTION_ID,
            functionName: this.FUNCTION_NAME,
            results,
            testResults,
            successRate,
            overallStatus: passedTests === totalTests ? 'PASS' : 'FAIL'
        };
        
        const fs = require('fs');
        const reportPath = `cloudfront-function-association-test-${Date.now()}.json`;
        fs.writeFileSync(reportPath, JSON.stringify(reportData, null, 2));
        console.log(`📄 Detailed report saved to: ${reportPath}`);
        
        return reportData;
    }
}

// CLI execution
async function main() {
    try {
        const tester = new CloudFrontFunctionAssociationTester();
        const results = await tester.runTests();
        
        // Exit with appropriate code
        const allPassed = Object.values(results).every(result => result === true);
        process.exit(allPassed ? 0 : 1);
        
    } catch (error) {
        console.error('\n💥 Test execution failed:', error.message);
        process.exit(1);
    }
}

// Export for use in other scripts
module.exports = CloudFrontFunctionAssociationTester;

// Run if called directly
if (require.main === module) {
    main();
}