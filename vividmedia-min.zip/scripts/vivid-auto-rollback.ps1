# Vivid Auto SCRAM Rebuild - Rollback Management Script
# This script provides rollback functionality using S3 versioning and CloudFront invalidation

param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("list-versions", "rollback", "emergency", "verify", "help")]
    [string]$Action = "help",
    
    [Parameter(Mandatory=$false)]
    [string]$File = "",
    
    [Parameter(Mandatory=$false)]
    [string]$VersionId = "",
    
    [Parameter(Mandatory=$false)]
    [switch]$DryRun = $false
)

# Configuration - Vivid Auto SCRAM Infrastructure
$script:Config = @{
    Bucket = "mobile-marketing-site-prod-1759705011281-tyzuo9"
    DistributionId = "E2IBMHQ3GCW6ZK"
    Region = "us-east-1"
    Domain = "d15sc9fc739ev2.cloudfront.net"
}

# Critical files for the Vivid Auto website
$script:CriticalFiles = @(
    "index.html",
    "services/index.html", 
    "blog/index.html",
    "contact/index.html",
    "services/photography/index.html",
    "services/analytics/index.html",
    "services/ad-campaigns/index.html",
    "privacy-policy/index.html"
)

# Cache invalidation paths as per spec requirements
$script:InvalidationPaths = @(
    "/",
    "/index.html", 
    "/services/*",
    "/blog/*",
    "/images/*",
    "/sitemap.xml",
    "/_next/*"
)

function Write-Header {
    param([string]$Title)
    Write-Host ""
    Write-Host "🔄 Vivid Auto SCRAM Rollback Manager" -ForegroundColor Cyan
    Write-Host "=" * 50 -ForegroundColor Gray
    Write-Host $Title -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Infrastructure:" -ForegroundColor Gray
    Write-Host "  S3 Bucket: $($Config.Bucket)" -ForegroundColor Gray
    Write-Host "  CloudFront: $($Config.DistributionId)" -ForegroundColor Gray
    Write-Host "  Domain: $($Config.Domain)" -ForegroundColor Gray
    Write-Host ""
}

function Test-AWSCredentials {
    try {
        $identity = aws sts get-caller-identity --output json | ConvertFrom-Json
        Write-Host "✅ AWS Credentials Valid" -ForegroundColor Green
        Write-Host "   Account: $($identity.Account)" -ForegroundColor Gray
        Write-Host "   User: $($identity.Arn)" -ForegroundColor Gray
        return $true
    }
    catch {
        Write-Host "❌ AWS Credentials Invalid or Missing" -ForegroundColor Red
        Write-Host "   Please configure AWS CLI credentials" -ForegroundColor Red
        return $false
    }
}

function Get-S3ObjectVersions {
    param(
        [string]$Prefix = "",
        [int]$MaxVersions = 10
    )
    
    Write-Host "📋 Listing object versions..." -ForegroundColor Cyan
    
    if ($Prefix) {
        Write-Host "   File: $Prefix" -ForegroundColor Gray
    } else {
        Write-Host "   Scope: All files" -ForegroundColor Gray
    }
    
    try {
        $command = "aws s3api list-object-versions --bucket $($Config.Bucket) --region $($Config.Region)"
        
        if ($Prefix) {
            $command += " --prefix `"$Prefix`""
        }
        
        $command += " --output json"
        
        $result = Invoke-Expression $command | ConvertFrom-Json
        
        if ($result.Versions) {
            $versions = $result.Versions | Sort-Object LastModified -Descending
            
            if ($MaxVersions -gt 0) {
                $versions = $versions | Select-Object -First $MaxVersions
            }
            
            Write-Host ""
            Write-Host "📄 Object Versions:" -ForegroundColor Green
            Write-Host ("-" * 80) -ForegroundColor Gray
            Write-Host ("{0,-40} {1,-25} {2,-20} {3}" -f "File", "Version ID", "Last Modified", "Latest") -ForegroundColor White
            Write-Host ("-" * 80) -ForegroundColor Gray
            
            foreach ($version in $versions) {
                $isLatest = if ($version.IsLatest) { "✓" } else { "" }
                $lastModified = [DateTime]::Parse($version.LastModified).ToString("yyyy-MM-dd HH:mm:ss")
                $versionIdShort = $version.VersionId.Substring(0, [Math]::Min(20, $version.VersionId.Length)) + "..."
                
                Write-Host ("{0,-40} {1,-25} {2,-20} {3}" -f $version.Key, $versionIdShort, $lastModified, $isLatest) -ForegroundColor Gray
            }
            
            return $versions
        } else {
            Write-Host "📁 No versions found" -ForegroundColor Yellow
            return @()
        }
    }
    catch {
        Write-Host "❌ Failed to list versions: $($_.Exception.Message)" -ForegroundColor Red
        return @()
    }
}

function Restore-S3ObjectVersion {
    param(
        [string]$Key,
        [string]$VersionId,
        [string]$ContentType = "text/html",
        [string]$CacheControl = "public, max-age=600"
    )
    
    Write-Host "📤 Restoring $Key to version $($VersionId.Substring(0,8))..." -ForegroundColor Cyan
    
    if ($DryRun) {
        Write-Host "   🧪 DRY RUN - Would restore $Key" -ForegroundColor Yellow
        return $true
    }
    
    try {
        $copySource = "$($Config.Bucket)/$Key" + "?versionId=$VersionId"
        
        aws s3api copy-object `
            --bucket $Config.Bucket `
            --copy-source $copySource `
            --key $Key `
            --metadata-directive REPLACE `
            --cache-control $CacheControl `
            --content-type $ContentType `
            --region $Config.Region
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "   ✅ Successfully restored $Key" -ForegroundColor Green
            return $true
        } else {
            Write-Host "   ❌ Failed to restore $Key" -ForegroundColor Red
            return $false
        }
    }
    catch {
        Write-Host "   ❌ Error restoring $Key`: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

function Invoke-CloudFrontInvalidation {
    param(
        [string[]]$Paths = $script:InvalidationPaths,
        [string]$CallerReference = ""
    )
    
    Write-Host "🔄 Invalidating CloudFront cache..." -ForegroundColor Cyan
    
    if (-not $CallerReference) {
        $CallerReference = "vivid-auto-rollback-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
    }
    
    if ($DryRun) {
        Write-Host "   🧪 DRY RUN - Would invalidate paths:" -ForegroundColor Yellow
        foreach ($path in $Paths) {
            Write-Host "     $path" -ForegroundColor Gray
        }
        return $true
    }
    
    try {
        # Create paths JSON for AWS CLI
        $pathsJson = ($Paths | ForEach-Object { "`"$_`"" }) -join ","
        $invalidationBatch = "{`"Paths`":{`"Quantity`":$($Paths.Count),`"Items`":[$pathsJson]},`"CallerReference`":`"$CallerReference`"}"
        
        $result = aws cloudfront create-invalidation `
            --distribution-id $Config.DistributionId `
            --invalidation-batch $invalidationBatch `
            --region us-east-1 `
            --output json | ConvertFrom-Json
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "   ✅ Invalidation created successfully" -ForegroundColor Green
            Write-Host "   📋 Invalidation ID: $($result.Invalidation.Id)" -ForegroundColor Gray
            Write-Host "   ⏱️  Propagation time: 5-15 minutes" -ForegroundColor Gray
            return $true
        } else {
            Write-Host "   ❌ Failed to create invalidation" -ForegroundColor Red
            return $false
        }
    }
    catch {
        Write-Host "   ❌ Error creating invalidation: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

function Backup-CurrentVersions {
    Write-Host "💾 Creating backup of current versions..." -ForegroundColor Cyan
    
    $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $backupFile = "vivid-auto-rollback-backup-$timestamp.json"
    
    $currentVersions = @{}
    
    foreach ($file in $script:CriticalFiles) {
        try {
            $versions = aws s3api list-object-versions `
                --bucket $Config.Bucket `
                --prefix $file `
                --query 'Versions[?IsLatest==`true`].[VersionId]' `
                --output text `
                --region $Config.Region
            
            if ($versions -and $versions -ne "None") {
                $currentVersions[$file] = $versions.Trim()
                Write-Host "   📄 $file : $($versions.Trim().Substring(0,8))..." -ForegroundColor Gray
            }
        }
        catch {
            Write-Host "   ⚠️  Could not get version for $file" -ForegroundColor Yellow
        }
    }
    
    if (-not $DryRun) {
        $backupData = @{
            timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss UTC")
            bucket = $Config.Bucket
            distributionId = $Config.DistributionId
            versions = $currentVersions
        }
        
        $backupData | ConvertTo-Json -Depth 3 | Out-File $backupFile -Encoding UTF8
        Write-Host "   ✅ Backup saved to $backupFile" -ForegroundColor Green
        return $backupFile
    } else {
        Write-Host "   🧪 DRY RUN - Would save to $backupFile" -ForegroundColor Yellow
        return $backupFile
    }
}

function Invoke-EmergencyRollback {
    Write-Header "Emergency Rollback - Last Known Good State"
    
    if (-not (Test-AWSCredentials)) {
        return
    }
    
    Write-Host "🚨 EMERGENCY ROLLBACK PROCEDURE" -ForegroundColor Red
    Write-Host "This will restore all critical files to their previous versions" -ForegroundColor Yellow
    Write-Host ""
    
    if (-not $DryRun) {
        $confirmation = Read-Host "Are you sure you want to proceed? (type 'YES' to confirm)"
        if ($confirmation -ne "YES") {
            Write-Host "❌ Emergency rollback cancelled" -ForegroundColor Red
            return
        }
    }
    
    # Step 1: Backup current state
    $backupFile = Backup-CurrentVersions
    
    # Step 2: Get previous versions for each critical file
    Write-Host ""
    Write-Host "🔍 Finding previous versions..." -ForegroundColor Cyan
    
    $rollbackPlan = @{}
    
    foreach ($file in $script:CriticalFiles) {
        $versions = Get-S3ObjectVersions -Prefix $file -MaxVersions 5
        
        if ($versions.Count -ge 2) {
            # Get the second most recent version (previous version)
            $targetVersion = $versions[1]
            $rollbackPlan[$file] = $targetVersion.VersionId
            Write-Host "   📄 $file -> $($targetVersion.VersionId.Substring(0,8))... ($($targetVersion.LastModified))" -ForegroundColor Gray
        } else {
            Write-Host "   ⚠️  $file - No previous version available" -ForegroundColor Yellow
        }
    }
    
    if ($rollbackPlan.Count -eq 0) {
        Write-Host "❌ No files available for rollback" -ForegroundColor Red
        return
    }
    
    # Step 3: Execute rollback
    Write-Host ""
    Write-Host "📤 Executing rollback..." -ForegroundColor Cyan
    
    $successCount = 0
    foreach ($file in $rollbackPlan.Keys) {
        if (Restore-S3ObjectVersion -Key $file -VersionId $rollbackPlan[$file]) {
            $successCount++
        }
    }
    
    # Step 4: Invalidate cache
    Write-Host ""
    Invoke-CloudFrontInvalidation
    
    # Step 5: Summary
    Write-Host ""
    Write-Host "📊 Rollback Summary:" -ForegroundColor Green
    Write-Host "   Files processed: $($rollbackPlan.Count)" -ForegroundColor Gray
    Write-Host "   Successful: $successCount" -ForegroundColor Gray
    Write-Host "   Failed: $($rollbackPlan.Count - $successCount)" -ForegroundColor Gray
    
    if (-not $DryRun) {
        Write-Host "   Backup file: $backupFile" -ForegroundColor Gray
    }
    
    Write-Host ""
    Write-Host "🔍 Verification Commands:" -ForegroundColor Cyan
    Write-Host "   curl -I https://$($Config.Domain)/" -ForegroundColor Gray
    Write-Host "   curl -I https://$($Config.Domain)/services/" -ForegroundColor Gray
    Write-Host "   curl -I https://$($Config.Domain)/blog/" -ForegroundColor Gray
}

function Invoke-FileRollback {
    param(
        [string]$FilePath,
        [string]$TargetVersionId
    )
    
    Write-Header "File Rollback - $FilePath"
    
    if (-not (Test-AWSCredentials)) {
        return
    }
    
    if (-not $FilePath) {
        Write-Host "❌ File path is required" -ForegroundColor Red
        Write-Host "Usage: .\vivid-auto-rollback.ps1 -Action rollback -File 'index.html' -VersionId 'VERSION_ID'" -ForegroundColor Gray
        return
    }
    
    if (-not $TargetVersionId) {
        Write-Host "❌ Version ID is required" -ForegroundColor Red
        Write-Host "Use -Action list-versions -File '$FilePath' to see available versions" -ForegroundColor Gray
        return
    }
    
    Write-Host "📋 Rollback Details:" -ForegroundColor Cyan
    Write-Host "   File: $FilePath" -ForegroundColor Gray
    Write-Host "   Target Version: $($TargetVersionId.Substring(0,8))..." -ForegroundColor Gray
    Write-Host ""
    
    # Step 1: Verify target version exists
    Write-Host "🔍 Verifying target version..." -ForegroundColor Cyan
    $versions = Get-S3ObjectVersions -Prefix $FilePath -MaxVersions 20
    $targetVersion = $versions | Where-Object { $_.VersionId -eq $TargetVersionId }
    
    if (-not $targetVersion) {
        Write-Host "❌ Target version not found" -ForegroundColor Red
        Write-Host "Available versions for $FilePath`:" -ForegroundColor Yellow
        Get-S3ObjectVersions -Prefix $FilePath -MaxVersions 10
        return
    }
    
    Write-Host "   ✅ Target version found: $($targetVersion.LastModified)" -ForegroundColor Green
    
    # Step 2: Backup current version
    $backupFile = Backup-CurrentVersions
    
    # Step 3: Restore file
    Write-Host ""
    if (Restore-S3ObjectVersion -Key $FilePath -VersionId $TargetVersionId) {
        # Step 4: Invalidate cache for this file
        Write-Host ""
        $invalidationPaths = @("/$FilePath", "/$($FilePath.Replace('/index.html', '/'))")
        Invoke-CloudFrontInvalidation -Paths $invalidationPaths
        
        Write-Host ""
        Write-Host "✅ File rollback completed successfully" -ForegroundColor Green
        if (-not $DryRun) {
            Write-Host "   Backup: $backupFile" -ForegroundColor Gray
        }
        Write-Host "   Verify: curl -I https://$($Config.Domain)/$FilePath" -ForegroundColor Gray
    }
}

function Invoke-VerifyDeployment {
    Write-Header "Deployment Verification"
    
    Write-Host "🔍 Verifying Vivid Auto website deployment..." -ForegroundColor Cyan
    Write-Host ""
    
    $checks = @(
        @{ Name = "Home Page"; URL = "https://$($Config.Domain)/" },
        @{ Name = "Services Page"; URL = "https://$($Config.Domain)/services/" },
        @{ Name = "Photography Services"; URL = "https://$($Config.Domain)/services/photography/" },
        @{ Name = "Analytics Services"; URL = "https://$($Config.Domain)/services/analytics/" },
        @{ Name = "Ad Campaigns Services"; URL = "https://$($Config.Domain)/services/ad-campaigns/" },
        @{ Name = "Blog Page"; URL = "https://$($Config.Domain)/blog/" },
        @{ Name = "Contact Page"; URL = "https://$($Config.Domain)/contact/" },
        @{ Name = "Privacy Policy"; URL = "https://$($Config.Domain)/privacy-policy/" }
    )
    
    $passCount = 0
    
    foreach ($check in $checks) {
        try {
            $response = Invoke-WebRequest -Uri $check.URL -Method Head -TimeoutSec 10 -ErrorAction Stop
            if ($response.StatusCode -eq 200) {
                Write-Host "   ✅ $($check.Name) - OK (200)" -ForegroundColor Green
                $passCount++
            } else {
                Write-Host "   ⚠️  $($check.Name) - $($response.StatusCode)" -ForegroundColor Yellow
            }
        }
        catch {
            Write-Host "   ❌ $($check.Name) - Failed: $($_.Exception.Message)" -ForegroundColor Red
        }
    }
    
    Write-Host ""
    Write-Host "📊 Verification Summary:" -ForegroundColor Cyan
    Write-Host "   Passed: $passCount/$($checks.Count)" -ForegroundColor Gray
    
    if ($passCount -eq $checks.Count) {
        Write-Host "   ✅ All checks passed" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️  Some checks failed - investigate issues" -ForegroundColor Yellow
    }
    
    # Additional content checks
    Write-Host ""
    Write-Host "🔍 Content Validation:" -ForegroundColor Cyan
    
    try {
        $homeContent = Invoke-WebRequest -Uri "https://$($Config.Domain)/" -TimeoutSec 10
        
        # Check for brand compliance (no gradients, prohibited colors)
        $prohibitedPatterns = @("gradient", "indigo-", "purple-", "yellow-")
        $violations = @()
        
        foreach ($pattern in $prohibitedPatterns) {
            if ($homeContent.Content -match $pattern) {
                $violations += $pattern
            }
        }
        
        if ($violations.Count -eq 0) {
            Write-Host "   ✅ Brand compliance - No prohibited colors/gradients found" -ForegroundColor Green
        } else {
            Write-Host "   ❌ Brand violations found: $($violations -join ', ')" -ForegroundColor Red
        }
        
        # Check for hero image
        if ($homeContent.Content -match "aston-martin-db6-website\.webp") {
            Write-Host "   ✅ Hero image - Correct Aston Martin image found" -ForegroundColor Green
        } else {
            Write-Host "   ❌ Hero image - Aston Martin image not found" -ForegroundColor Red
        }
        
    }
    catch {
        Write-Host "   ⚠️  Could not perform content validation: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

function Show-Help {
    Write-Header "Help - Available Commands"
    
    Write-Host "Available Actions:" -ForegroundColor Cyan
    Write-Host ""
    
    Write-Host "📋 list-versions" -ForegroundColor Green
    Write-Host "   List available versions for files"
    Write-Host "   Usage: .\vivid-auto-rollback.ps1 -Action list-versions [-File 'filename']"
    Write-Host "   Example: .\vivid-auto-rollback.ps1 -Action list-versions -File 'index.html'"
    Write-Host ""
    
    Write-Host "🔄 rollback" -ForegroundColor Green  
    Write-Host "   Rollback specific file to target version"
    Write-Host "   Usage: .\vivid-auto-rollback.ps1 -Action rollback -File 'filename' -VersionId 'version'"
    Write-Host "   Example: .\vivid-auto-rollback.ps1 -Action rollback -File 'index.html' -VersionId 'abc123...'"
    Write-Host ""
    
    Write-Host "🚨 emergency" -ForegroundColor Red
    Write-Host "   Emergency rollback all critical files to previous versions"
    Write-Host "   Usage: .\vivid-auto-rollback.ps1 -Action emergency"
    Write-Host "   Example: .\vivid-auto-rollback.ps1 -Action emergency -DryRun"
    Write-Host ""
    
    Write-Host "🔍 verify" -ForegroundColor Green
    Write-Host "   Verify website deployment and content"
    Write-Host "   Usage: .\vivid-auto-rollback.ps1 -Action verify"
    Write-Host ""
    
    Write-Host "Parameters:" -ForegroundColor Cyan
    Write-Host "   -DryRun    : Preview changes without executing them"
    Write-Host "   -File      : Specific file to target (for list-versions and rollback)"
    Write-Host "   -VersionId : Target version ID (for rollback)"
    Write-Host ""
    
    Write-Host "Examples:" -ForegroundColor Yellow
    Write-Host "   # List versions for home page"
    Write-Host "   .\vivid-auto-rollback.ps1 -Action list-versions -File 'index.html'"
    Write-Host ""
    Write-Host "   # Rollback home page (dry run first)"
    Write-Host "   .\vivid-auto-rollback.ps1 -Action rollback -File 'index.html' -VersionId 'abc123...' -DryRun"
    Write-Host "   .\vivid-auto-rollback.ps1 -Action rollback -File 'index.html' -VersionId 'abc123...'"
    Write-Host ""
    Write-Host "   # Emergency rollback (dry run first)"
    Write-Host "   .\vivid-auto-rollback.ps1 -Action emergency -DryRun"
    Write-Host "   .\vivid-auto-rollback.ps1 -Action emergency"
    Write-Host ""
    Write-Host "   # Verify deployment"
    Write-Host "   .\vivid-auto-rollback.ps1 -Action verify"
}

# Main execution
switch ($Action) {
    "list-versions" {
        Write-Header "List Object Versions"
        if (-not (Test-AWSCredentials)) { return }
        Get-S3ObjectVersions -Prefix $File -MaxVersions 20
    }
    
    "rollback" {
        Invoke-FileRollback -FilePath $File -TargetVersionId $VersionId
    }
    
    "emergency" {
        Invoke-EmergencyRollback
    }
    
    "verify" {
        Invoke-VerifyDeployment
    }
    
    "help" {
        Show-Help
    }
    
    default {
        Show-Help
    }
}