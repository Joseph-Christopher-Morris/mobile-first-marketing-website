# Debug URL Response Script
$CLOUDFRONT_DOMAIN = "d15sc9fc739ev2.cloudfront.net"
$BASE_URL = "https://$CLOUDFRONT_DOMAIN"

$testUrl = "$BASE_URL/"
Write-Host "Debugging URL: $testUrl" -ForegroundColor Cyan

try {
    $response = Invoke-WebRequest -Uri $testUrl -Method GET -TimeoutSec 10 -ErrorAction Stop
    
    Write-Host ""
    Write-Host "Response Details:" -ForegroundColor Yellow
    Write-Host "Status Code: $($response.StatusCode)"
    Write-Host "Content-Type: $($response.Headers['Content-Type'])"
    Write-Host "Content-Length: $($response.Headers['Content-Length'])"
    Write-Host "X-Cache: $($response.Headers['X-Cache'])"
    Write-Host "X-Amz-Cf-Pop: $($response.Headers['X-Amz-Cf-Pop'])"
    
    Write-Host ""
    Write-Host "Response Content (first 500 chars):" -ForegroundColor Yellow
    $content = $response.Content
    if ($content.Length -gt 500) {
        Write-Host $content.Substring(0, 500)
        Write-Host "... (truncated)"
    } else {
        Write-Host $content
    }
    
    Write-Host ""
    Write-Host "Content Analysis:" -ForegroundColor Yellow
    Write-Host "Contains '<html': $($content -like '*<html*')"
    Write-Host "Contains '<head': $($content -like '*<head*')"
    Write-Host "Contains '<body': $($content -like '*<body*')"
    Write-Host "Content Length: $($content.Length)"
    
} catch {
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}