#!/usr/bin/env node

/**
 * Git Workflow Consistency Tests
 * 
 * Tests Git configuration, .gitignore patterns, and workflow consistency
 * to ensure clean Git operations and proper file handling.
 * 
 * Requirements: 5.4
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

class GitWorkflowConsistencyTests {
  constructor() {
    this.results = {
      tests: [],
      passed: 0,
      failed: 0,
      warnings: [],
      gitConfig: {},
      fileStatus: {}
    };
  }

  /**
   * Run all Git workflow consistency tests
   */
  runTests() {
    console.log('🔄 Running Git Workflow Consistency Tests');
    console.log('=' .repeat(45));

    try {
      this.validateGitConfiguration();
      this.validateGitignorePatterns();
      this.validatePackageConfiguration();
      this.validateLockfileConsistency();
      this.validateFileHandling();
      this.validateStagingBehavior();
      
      this.generateReport();
      
    } catch (error) {
      console.error('❌ Git workflow tests failed:', error.message);
      process.exit(1);
    }
  }

  /**
   * Validate Git configuration settings
   */
  validateGitConfiguration() {
    console.log('\n🔧 Validating Git Configuration...');

    // Test core.autocrlf setting
    this.test('Git core.autocrlf is configured', () => {
      try {
        const autocrlf = this.execGitCommand('git config core.autocrlf').trim();
        this.results.gitConfig.autocrlf = autocrlf;
        
        if (autocrlf !== 'true') {
          throw new Error(`Expected core.autocrlf=true, got: ${autocrlf || 'not set'}`);
        }
      } catch (error) {
        if (error.message.includes('not set')) {
          throw new Error('Git core.autocrlf should be set to true for Windows compatibility');
        }
        throw error;
      }
    });

    // Test user configuration
    this.test('Git user configuration exists', () => {
      try {
        const userName = this.execGitCommand('git config user.name').trim();
        const userEmail = this.execGitCommand('git config user.email').trim();
        
        this.results.gitConfig.userName = userName;
        this.results.gitConfig.userEmail = userEmail;
        
        if (!userName || !userEmail) {
          throw new Error('Git user.name and user.email should be configured');
        }
      } catch (error) {
        throw new Error('Git user configuration is required for commits');
      }
    });

    // Test repository status
    this.test('Repository is initialized', () => {
      try {
        this.execGitCommand('git status --porcelain');
      } catch (error) {
        throw new Error('Not in a Git repository or Git is not initialized');
      }
    });

    // Test remote configuration
    this.test('Remote origin is configured', () => {
      try {
        const remoteUrl = this.execGitCommand('git config remote.origin.url').trim();
        this.results.gitConfig.remoteUrl = remoteUrl;
        
        if (!remoteUrl) {
          this.addWarning('No remote origin configured - this may be intentional for local development');
        }
      } catch (error) {
        this.addWarning('No remote origin configured - this may be intentional for local development');
      }
    });
  }

  /**
   * Validate .gitignore patterns
   */
  validateGitignorePatterns() {
    console.log('\n📝 Validating .gitignore Patterns...');

    this.test('.gitignore file exists', () => {
      if (!fs.existsSync('.gitignore')) {
        throw new Error('.gitignore file not found');
      }
    });

    let gitignoreContent;
    this.test('.gitignore is readable', () => {
      gitignoreContent = fs.readFileSync('.gitignore', 'utf8');
      if (!gitignoreContent) {
        throw new Error('.gitignore file is empty');
      }
    });

    // Required patterns for Node.js projects
    const requiredPatterns = [
      { pattern: 'node_modules/', description: 'Node.js dependencies' },
      { pattern: '.next/', description: 'Next.js build output' },
      { pattern: 'out/', description: 'Static export output' },
      { pattern: '.env.local', description: 'Local environment files' },
      { pattern: '*.log', description: 'Log files' }
    ];

    requiredPatterns.forEach(({ pattern, description }) => {
      this.test(`Ignores ${description} (${pattern})`, () => {
        if (!gitignoreContent.includes(pattern)) {
          throw new Error(`Required .gitignore pattern missing: ${pattern}`);
        }
      });
    });

    // CI-specific patterns
    const ciPatterns = [
      { pattern: 'requirements-compliance-*.json', description: 'Compliance report JSON files' },
      { pattern: 'requirements-compliance-*.md', description: 'Compliance report Markdown files' },
      { pattern: '*-report-*.json', description: 'Generated report files' },
      { pattern: '*-validation-*.json', description: 'Validation result files' }
    ];

    ciPatterns.forEach(({ pattern, description }) => {
      this.test(`Ignores ${description} (${pattern})`, () => {
        if (!gitignoreContent.includes(pattern)) {
          this.addWarning(`Consider adding .gitignore pattern: ${pattern}`);
        }
      });
    });

    // Test for common mistakes
    this.test('No overly broad ignore patterns', () => {
      const dangerousPatterns = ['*', '**/*', '/*'];
      for (const pattern of dangerousPatterns) {
        if (gitignoreContent.includes(pattern)) {
          throw new Error(`Dangerous .gitignore pattern found: ${pattern}`);
        }
      }
    });
  }

  /**
   * Validate package.json configuration
   */
  validatePackageConfiguration() {
    console.log('\n📦 Validating Package Configuration...');

    this.test('package.json exists', () => {
      if (!fs.existsSync('package.json')) {
        throw new Error('package.json not found');
      }
    });

    let packageJson;
    this.test('package.json is valid JSON', () => {
      const content = fs.readFileSync('package.json', 'utf8');
      packageJson = JSON.parse(content);
    });

    this.test('Engines field specifies Node.js version', () => {
      if (!packageJson.engines) {
        throw new Error('package.json should have engines field');
      }
      
      if (!packageJson.engines.node) {
        throw new Error('package.json engines should specify node version');
      }
      
      const nodeVersion = packageJson.engines.node;
      if (!nodeVersion.includes('22.19.0') && !nodeVersion.includes('>=22.19.0')) {
        throw new Error(`Node.js version should be >=22.19.0, got: ${nodeVersion}`);
      }
    });

    this.test('npm version is specified', () => {
      if (!packageJson.engines.npm) {
        this.addWarning('Consider specifying npm version in engines field');
      } else {
        const npmVersion = packageJson.engines.npm;
        if (!npmVersion.includes('10.')) {
          this.addWarning(`npm version should be >=10.x, got: ${npmVersion}`);
        }
      }
    });

    // Check for required scripts
    const requiredScripts = ['build', 'dev'];
    requiredScripts.forEach(script => {
      this.test(`Required script: ${script}`, () => {
        if (!packageJson.scripts || !packageJson.scripts[script]) {
          throw new Error(`Required script missing: ${script}`);
        }
      });
    });
  }

  /**
   * Validate lockfile consistency
   */
  validateLockfileConsistency() {
    console.log('\n🔒 Validating Lockfile Consistency...');

    this.test('package-lock.json exists', () => {
      if (!fs.existsSync('package-lock.json')) {
        throw new Error('package-lock.json not found - run npm install to generate');
      }
    });

    this.test('Lockfile is valid JSON', () => {
      const content = fs.readFileSync('package-lock.json', 'utf8');
      JSON.parse(content); // Will throw if invalid
    });

    // Test npm ci dry run
    this.test('Lockfile consistency (npm ci dry-run)', () => {
      try {
        this.execCommand('npm ci --dry-run', { timeout: 30000 });
      } catch (error) {
        if (error.message.includes('package-lock.json was created with a different version')) {
          throw new Error('Lockfile was created with different npm version - regenerate with current npm version');
        }
        if (error.message.includes('requires a peer')) {
          this.addWarning('Peer dependency warnings detected - may need attention');
        } else {
          throw new Error(`Lockfile consistency check failed: ${error.message}`);
        }
      }
    });

    // Check for lockfile modifications after clean install
    this.test('Lockfile stability after clean install', () => {
      try {
        // Get current lockfile hash
        const beforeHash = this.getFileHash('package-lock.json');
        
        // Run npm ci (this should not modify lockfile)
        this.execCommand('npm ci', { timeout: 60000 });
        
        // Check if lockfile changed
        const afterHash = this.getFileHash('package-lock.json');
        
        if (beforeHash !== afterHash) {
          throw new Error('package-lock.json was modified by npm ci - indicates inconsistency');
        }
      } catch (error) {
        if (error.message.includes('modified by npm ci')) {
          throw error;
        }
        // Other errors might be due to missing dependencies, etc.
        this.addWarning(`Could not verify lockfile stability: ${error.message}`);
      }
    });
  }

  /**
   * Validate file handling behavior
   */
  validateFileHandling() {
    console.log('\n📁 Validating File Handling...');

    // Check Git status
    this.test('Git working directory status', () => {
      try {
        const status = this.execGitCommand('git status --porcelain');
        this.results.fileStatus.workingDirectory = status;
        
        if (status.trim()) {
          this.addWarning('Working directory has uncommitted changes');
        }
      } catch (error) {
        throw new Error(`Could not check Git status: ${error.message}`);
      }
    });

    // Test ignored files are actually ignored
    this.test('Generated files are properly ignored', () => {
      const testFiles = [
        'test-report-123.json',
        'requirements-compliance-test.json',
        'validation-results-test.md'
      ];
      
      // Create temporary test files
      testFiles.forEach(file => {
        fs.writeFileSync(file, 'test content');
      });
      
      try {
        const status = this.execGitCommand('git status --porcelain');
        
        // Check if any test files appear in status
        testFiles.forEach(file => {
          if (status.includes(file)) {
            throw new Error(`File ${file} should be ignored but appears in Git status`);
          }
        });
      } finally {
        // Clean up test files
        testFiles.forEach(file => {
          if (fs.existsSync(file)) {
            fs.unlinkSync(file);
          }
        });
      }
    });
  }

  /**
   * Validate staging behavior
   */
  validateStagingBehavior() {
    console.log('\n📋 Validating Staging Behavior...');

    // Test safe staging commands
    this.test('Git add command availability', () => {
      try {
        // Test git add --dry-run
        this.execGitCommand('git add --dry-run .');
      } catch (error) {
        if (!error.message.includes('nothing to commit')) {
          throw new Error(`Git add command failed: ${error.message}`);
        }
      }
    });

    this.test('Git diff command functionality', () => {
      try {
        this.execGitCommand('git diff --name-only');
      } catch (error) {
        throw new Error(`Git diff command failed: ${error.message}`);
      }
    });

    // Test CRLF handling
    this.test('Line ending handling', () => {
      const testFile = 'test-crlf-handling.txt';
      const testContent = 'Line 1\nLine 2\nLine 3\n';
      
      try {
        fs.writeFileSync(testFile, testContent);
        
        // Check if Git detects line ending issues
        const status = this.execGitCommand('git status --porcelain');
        
        if (status.includes(testFile)) {
          // File appears in status, check for CRLF warnings
          try {
            this.execGitCommand(`git add ${testFile}`);
            this.execGitCommand(`git reset HEAD ${testFile}`);
          } catch (error) {
            if (error.message.includes('CRLF') || error.message.includes('line ending')) {
              throw new Error('CRLF line ending issues detected - check core.autocrlf configuration');
            }
          }
        }
      } finally {
        if (fs.existsSync(testFile)) {
          fs.unlinkSync(testFile);
        }
      }
    });
  }

  /**
   * Execute Git command with error handling
   */
  execGitCommand(command) {
    return this.execCommand(command);
  }

  /**
   * Execute shell command with error handling
   */
  execCommand(command, options = {}) {
    try {
      return execSync(command, {
        encoding: 'utf8',
        stdio: 'pipe',
        timeout: options.timeout || 10000,
        ...options
      });
    } catch (error) {
      throw new Error(`Command failed: ${command}\n${error.message}`);
    }
  }

  /**
   * Get file hash for comparison
   */
  getFileHash(filePath) {
    const crypto = require('crypto');
    const content = fs.readFileSync(filePath);
    return crypto.createHash('md5').update(content).digest('hex');
  }

  /**
   * Run individual test
   */
  test(testName, testFunction) {
    try {
      testFunction();
      console.log(`  ✅ ${testName}`);
      this.results.tests.push({ name: testName, status: 'passed' });
      this.results.passed++;
    } catch (error) {
      console.log(`  ❌ ${testName}: ${error.message}`);
      this.results.tests.push({ name: testName, status: 'failed', error: error.message });
      this.results.failed++;
    }
  }

  /**
   * Add warning
   */
  addWarning(message) {
    console.log(`  ⚠️  Warning: ${message}`);
    this.results.warnings.push(message);
  }

  /**
   * Generate test report
   */
  generateReport() {
    console.log('\n' + '='.repeat(45));
    console.log('📊 Git Workflow Consistency Results');
    console.log('='.repeat(45));
    
    console.log(`\nTests: ${this.results.passed + this.results.failed}`);
    console.log(`Passed: ${this.results.passed}`);
    console.log(`Failed: ${this.results.failed}`);
    console.log(`Warnings: ${this.results.warnings.length}`);

    if (Object.keys(this.results.gitConfig).length > 0) {
      console.log('\n🔧 Git Configuration:');
      Object.entries(this.results.gitConfig).forEach(([key, value]) => {
        console.log(`  ${key}: ${value}`);
      });
    }

    if (this.results.warnings.length > 0) {
      console.log('\n⚠️  Warnings:');
      this.results.warnings.forEach(warning => {
        console.log(`  - ${warning}`);
      });
    }

    // Save detailed report
    const reportPath = `git-workflow-consistency-report-${Date.now()}.json`;
    fs.writeFileSync(reportPath, JSON.stringify(this.results, null, 2));
    console.log(`\n📄 Detailed report saved: ${reportPath}`);

    if (this.results.failed > 0) {
      console.log('\n❌ Git workflow consistency tests failed. Please fix the issues above.');
      process.exit(1);
    } else {
      console.log('\n✅ Git workflow consistency tests passed!');
    }
  }
}

// Run tests if called directly
if (require.main === module) {
  const tester = new GitWorkflowConsistencyTests();
  tester.runTests();
}

module.exports = GitWorkflowConsistencyTests;