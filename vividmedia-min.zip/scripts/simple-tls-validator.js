#!/usr/bin/env node

/**
 * Simpl