# Verify and upload trust logos to S3
param(
    [string]$BucketName = $env:S3_BUCKET_NAME,
    [string]$DistributionId = $env:CLOUDFRONT_DISTRIBUTION_ID
)

if (-not $BucketName) {
    $BucketName = "mobile-marketing-site-prod-1759705011281-tyzuo9"
}

if (-not $DistributionId) {
    $DistributionId = "E2IBMHQ3GCW6ZK"
}

Write-Host "Checking trust logos in S3 bucket: $BucketName" -ForegroundColor Green

# Check if logos exist in S3
$logosToCheck = @("bbc.v1.png", "forbes.v1.png", "ft.v1.png")
$missingLogos = @()

foreach ($logo in $logosToCheck) {
    Write-Host "Checking for $logo..." -ForegroundColor Yellow
    try {
        $result = aws s3 ls "s3://$BucketName/images/Trust/$logo" 2>$null
        if (-not $result) {
            Write-Host "Missing: $logo" -ForegroundColor Red
            $missingLogos += $logo
        } else {
            Write-Host "Found: $logo" -ForegroundColor Green
        }
    } catch {
        Write-Host "Error checking $logo : $_" -ForegroundColor Red
        $missingLogos += $logo
    }
}

# Upload missing logos
if ($missingLogos.Count -gt 0) {
    Write-Host "`nUploading missing logos..." -ForegroundColor Yellow
    
    foreach ($logo in $missingLogos) {
        $localPath = "public/images/Trust/$logo"
        $s3Path = "s3://$BucketName/images/Trust/$logo"
        
        if (Test-Path $localPath) {
            Write-Host "Uploading $logo..." -ForegroundColor Yellow
            aws s3 cp $localPath $s3Path --content-type "image/png" --cache-control "public,max-age=31536000,immutable"
            
            if ($LASTEXITCODE -eq 0) {
                Write-Host "Successfully uploaded $logo" -ForegroundColor Green
            } else {
                Write-Host "Failed to upload $logo" -ForegroundColor Red
            }
        } else {
            Write-Host "Local file not found: $localPath" -ForegroundColor Red
        }
    }
    
    # Invalidate CloudFront cache for trust logos
    Write-Host "`nInvalidating CloudFront cache..." -ForegroundColor Yellow
    aws cloudfront create-invalidation --distribution-id $DistributionId --paths "/images/Trust/*"
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "CloudFront invalidation initiated successfully" -ForegroundColor Green
    } else {
        Write-Host "Failed to invalidate CloudFront cache" -ForegroundColor Red
    }
} else {
    Write-Host "`nAll trust logos are present in S3" -ForegroundColor Green
}

# Test accessibility of logos via CloudFront
Write-Host "`nTesting logo accessibility via CloudFront..." -ForegroundColor Yellow
$baseUrl = "https://d15sc9fc739ev2.cloudfront.net"

foreach ($logo in $logosToCheck) {
    $url = "$baseUrl/images/Trust/$logo"
    Write-Host "Testing: $url" -ForegroundColor Yellow
    
    try {
        $response = Invoke-WebRequest -Uri $url -Method Head -UseBasicParsing -TimeoutSec 10
        if ($response.StatusCode -eq 200) {
            Write-Host "✓ $logo accessible (Status: $($response.StatusCode))" -ForegroundColor Green
        } else {
            Write-Host "✗ $logo returned status: $($response.StatusCode)" -ForegroundColor Red
        }
    } catch {
        Write-Host "✗ $logo failed: $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host "`nTrust logo verification complete!" -ForegroundColor Green