#!/usr/bin/env node

/**
 * Build Performance Benchmarks
 * 
 * Measures and validates build process performance metrics
 * to ensure CI pipeline efficiency and consistency.
 * 
 * Requirements: 5.5
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const os = require('os');

class BuildPerformanceBenchmarks {
  constructor() {
    this.results = {
      system: {},
      benchmarks: {},
      thresholds: {
        installTime: 120000, // 2 minutes
        buildTime: 300000,   // 5 minutes
        typeCheckTime: 60000, // 1 minute
        lintTime: 30000      // 30 seconds
      },
      tests: [],
      passed: 0,
      failed: 0,
      warnings: []
    };
    this.startTime = Date.now();
  }

  /**
   * Run all performance benchmarks
   */
  runBenchmarks() {
    console.log('⚡ Running Build Performance Benchmarks');
    console.log('=' .repeat(40));

    try {
      this.collectSystemInfo();
      this.benchmarkNodeVersion();
      this.benchmarkDependencyInstallation();
      this.benchmarkBuildProcess();
      this.benchmarkOptionalSteps();
      this.validateBuildOutput();
      this.analyzeBuildArtifacts();
      
      this.generateReport();
      
    } catch (error) {
      console.error('❌ Performance benchmarks failed:', error.message);
      process.exit(1);
    }
  }

  /**
   * Collect system information
   */
  collectSystemInfo() {
    console.log('\n💻 Collecting System Information...');
    
    this.results.system = {
      platform: os.platform(),
      arch: os.arch(),
      nodeVersion: process.version,
      npmVersion: this.getNpmVersion(),
      cpus: os.cpus().length,
      totalMemory: Math.round(os.totalmem() / 1024 / 1024 / 1024) + 'GB',
      freeMemory: Math.round(os.freemem() / 1024 / 1024 / 1024) + 'GB',
      timestamp: new Date().toISOString()
    };

    console.log(`  Platform: ${this.results.system.platform} ${this.results.system.arch}`);
    console.log(`  Node.js: ${this.results.system.nodeVersion}`);
    console.log(`  npm: ${this.results.system.npmVersion}`);
    console.log(`  CPUs: ${this.results.system.cpus}`);
    console.log(`  Memory: ${this.results.system.totalMemory} total, ${this.results.system.freeMemory} free`);
  }

  /**
   * Benchmark Node.js version verification
   */
  benchmarkNodeVersion() {
    console.log('\n🔍 Benchmarking Node.js Version Verification...');
    
    const startTime = Date.now();
    
    this.test('Node.js version meets requirements', () => {
      const nodeVersion = process.version;
      const majorVersion = parseInt(nodeVersion.slice(1).split('.')[0]);
      const minorVersion = parseInt(nodeVersion.slice(1).split('.')[1]);
      const patchVersion = parseInt(nodeVersion.slice(1).split('.')[2]);
      
      if (majorVersion < 22 || (majorVersion === 22 && minorVersion < 19)) {
        throw new Error(`Node.js version should be >=22.19.0, current: ${nodeVersion}`);
      }
      
      this.results.benchmarks.nodeVersionCheck = {
        version: nodeVersion,
        time: Date.now() - startTime,
        valid: true
      };
    });
  }

  /**
   * Benchmark dependency installation
   */
  benchmarkDependencyInstallation() {
    console.log('\n📦 Benchmarking Dependency Installation...');
    
    // Clean install benchmark
    const installStartTime = Date.now();
    
    this.test('Clean dependency installation (npm ci)', () => {
      try {
        // Remove node_modules if exists
        if (fs.existsSync('node_modules')) {
          console.log('  Removing existing node_modules...');
          this.execCommand('rm -rf node_modules', { timeout: 30000 });
        }
        
        console.log('  Running npm ci...');
        const output = this.execCommand('npm ci', { 
          timeout: this.results.thresholds.installTime 
        });
        
        const installTime = Date.now() - installStartTime;
        
        this.results.benchmarks.dependencyInstall = {
          time: installTime,
          timeFormatted: this.formatTime(installTime),
          success: true,
          output: output.slice(-500) // Last 500 chars of output
        };
        
        // Check against threshold
        if (installTime > this.results.thresholds.installTime) {
          this.addWarning(`Dependency installation took ${this.formatTime(installTime)} (>${this.formatTime(this.results.thresholds.installTime)} threshold)`);
        }
        
        console.log(`  ✅ Installation completed in ${this.formatTime(installTime)}`);
        
      } catch (error) {
        throw new Error(`Dependency installation failed: ${error.message}`);
      }
    });

    // Verify node_modules structure
    this.test('node_modules structure validation', () => {
      if (!fs.existsSync('node_modules')) {
        throw new Error('node_modules directory not created');
      }
      
      const nodeModulesStats = fs.statSync('node_modules');
      if (!nodeModulesStats.isDirectory()) {
        throw new Error('node_modules is not a directory');
      }
      
      // Count packages
      const packages = fs.readdirSync('node_modules').filter(item => 
        !item.startsWith('.') && fs.statSync(path.join('node_modules', item)).isDirectory()
      );
      
      this.results.benchmarks.nodeModules = {
        packageCount: packages.length,
        size: this.getDirectorySize('node_modules')
      };
      
      console.log(`  📊 Installed ${packages.length} packages`);
    });
  }

  /**
   * Benchmark build process
   */
  benchmarkBuildProcess() {
    console.log('\n🏗️  Benchmarking Build Process...');
    
    const buildStartTime = Date.now();
    
    this.test('Production build process', () => {
      try {
        console.log('  Running npm run build...');
        
        const output = this.execCommand('npm run build', {
          timeout: this.results.thresholds.buildTime,
          env: {
            ...process.env,
            CI: 'true',
            NEXT_TELEMETRY_DISABLED: '1',
            NODE_ENV: 'production'
          }
        });
        
        const buildTime = Date.now() - buildStartTime;
        
        this.results.benchmarks.build = {
          time: buildTime,
          timeFormatted: this.formatTime(buildTime),
          success: true,
          output: output.slice(-1000) // Last 1000 chars of output
        };
        
        // Check against threshold
        if (buildTime > this.results.thresholds.buildTime) {
          this.addWarning(`Build process took ${this.formatTime(buildTime)} (>${this.formatTime(this.results.thresholds.buildTime)} threshold)`);
        }
        
        console.log(`  ✅ Build completed in ${this.formatTime(buildTime)}`);
        
      } catch (error) {
        throw new Error(`Build process failed: ${error.message}`);
      }
    });
  }

  /**
   * Benchmark optional CI steps
   */
  benchmarkOptionalSteps() {
    console.log('\n🔧 Benchmarking Optional CI Steps...');
    
    // Type checking benchmark (if available)
    this.test('Type checking performance (if available)', () => {
      try {
        const typeCheckStartTime = Date.now();
        
        // Check if TypeScript is available
        const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
        const hasTypeScript = packageJson.devDependencies?.typescript || 
                             packageJson.dependencies?.typescript ||
                             fs.existsSync('tsconfig.json');
        
        if (hasTypeScript) {
          console.log('  Running type check...');
          
          // Try different type check commands
          let typeCheckCommand = null;
          if (packageJson.scripts?.['type-check']) {
            typeCheckCommand = 'npm run type-check';
          } else if (packageJson.scripts?.tsc) {
            typeCheckCommand = 'npm run tsc';
          } else {
            typeCheckCommand = 'npx tsc --noEmit';
          }
          
          const output = this.execCommand(typeCheckCommand, {
            timeout: this.results.thresholds.typeCheckTime
          });
          
          const typeCheckTime = Date.now() - typeCheckStartTime;
          
          this.results.benchmarks.typeCheck = {
            time: typeCheckTime,
            timeFormatted: this.formatTime(typeCheckTime),
            success: true,
            command: typeCheckCommand
          };
          
          console.log(`  ✅ Type check completed in ${this.formatTime(typeCheckTime)}`);
        } else {
          this.results.benchmarks.typeCheck = {
            skipped: true,
            reason: 'TypeScript not detected'
          };
          console.log('  ⏭️  Type checking skipped (TypeScript not detected)');
        }
        
      } catch (error) {
        this.addWarning(`Type checking failed: ${error.message}`);
        this.results.benchmarks.typeCheck = {
          failed: true,
          error: error.message
        };
      }
    });

    // Linting benchmark (if available)
    this.test('Linting performance (if available)', () => {
      try {
        const lintStartTime = Date.now();
        
        const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
        const hasLinting = packageJson.scripts?.lint || 
                          packageJson.devDependencies?.eslint ||
                          fs.existsSync('.eslintrc.json') ||
                          fs.existsSync('.eslintrc.js');
        
        if (hasLinting && packageJson.scripts?.lint) {
          console.log('  Running linting...');
          
          const output = this.execCommand('npm run lint', {
            timeout: this.results.thresholds.lintTime
          });
          
          const lintTime = Date.now() - lintStartTime;
          
          this.results.benchmarks.lint = {
            time: lintTime,
            timeFormatted: this.formatTime(lintTime),
            success: true
          };
          
          console.log(`  ✅ Linting completed in ${this.formatTime(lintTime)}`);
        } else {
          this.results.benchmarks.lint = {
            skipped: true,
            reason: 'Linting not configured'
          };
          console.log('  ⏭️  Linting skipped (not configured)');
        }
        
      } catch (error) {
        this.addWarning(`Linting failed: ${error.message}`);
        this.results.benchmarks.lint = {
          failed: true,
          error: error.message
        };
      }
    });
  }

  /**
   * Validate build output
   */
  validateBuildOutput() {
    console.log('\n📁 Validating Build Output...');
    
    this.test('Build output directory exists', () => {
      const outDir = 'out';
      if (!fs.existsSync(outDir)) {
        throw new Error('Build output directory not found');
      }
      
      const stats = fs.statSync(outDir);
      if (!stats.isDirectory()) {
        throw new Error('Build output path is not a directory');
      }
    });

    this.test('Essential build files exist', () => {
      const requiredFiles = [
        'out/index.html',
        'out/_next'
      ];
      
      for (const file of requiredFiles) {
        if (!fs.existsSync(file)) {
          throw new Error(`Required build file missing: ${file}`);
        }
      }
    });

    this.test('Build output structure validation', () => {
      const buildStats = this.getBuildStats('out');
      
      this.results.benchmarks.buildOutput = buildStats;
      
      console.log(`  📊 Build output: ${buildStats.totalFiles} files, ${this.formatBytes(buildStats.totalSize)}`);
      console.log(`  📄 HTML files: ${buildStats.htmlFiles}`);
      console.log(`  📜 JS files: ${buildStats.jsFiles}`);
      console.log(`  🎨 CSS files: ${buildStats.cssFiles}`);
      
      // Validate reasonable file counts
      if (buildStats.htmlFiles === 0) {
        throw new Error('No HTML files found in build output');
      }
      
      if (buildStats.totalSize === 0) {
        throw new Error('Build output appears to be empty');
      }
    });
  }

  /**
   * Analyze build artifacts
   */
  analyzeBuildArtifacts() {
    console.log('\n🔍 Analyzing Build Artifacts...');
    
    this.test('Build artifact analysis', () => {
      const analysis = {
        largestFiles: [],
        compressionOpportunities: [],
        cacheableAssets: []
      };
      
      // Find largest files
      const allFiles = this.getAllFiles('out');
      const sortedFiles = allFiles
        .map(file => ({
          path: file,
          size: fs.statSync(file).size
        }))
        .sort((a, b) => b.size - a.size)
        .slice(0, 10);
      
      analysis.largestFiles = sortedFiles.map(file => ({
        path: file.path.replace('out/', ''),
        size: this.formatBytes(file.size)
      }));
      
      // Check for compression opportunities
      const textFiles = allFiles.filter(file => {
        const ext = path.extname(file).toLowerCase();
        return ['.html', '.css', '.js', '.json', '.xml', '.txt'].includes(ext);
      });
      
      analysis.compressionOpportunities = textFiles
        .filter(file => fs.statSync(file).size > 10240) // > 10KB
        .map(file => ({
          path: file.replace('out/', ''),
          size: this.formatBytes(fs.statSync(file).size)
        }));
      
      // Identify cacheable assets
      const staticAssets = allFiles.filter(file => {
        const ext = path.extname(file).toLowerCase();
        return ['.js', '.css', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.woff', '.woff2'].includes(ext);
      });
      
      analysis.cacheableAssets = {
        count: staticAssets.length,
        totalSize: this.formatBytes(
          staticAssets.reduce((sum, file) => sum + fs.statSync(file).size, 0)
        )
      };
      
      this.results.benchmarks.artifactAnalysis = analysis;
      
      console.log(`  📊 Largest files: ${analysis.largestFiles.length}`);
      console.log(`  🗜️  Compression candidates: ${analysis.compressionOpportunities.length}`);
      console.log(`  💾 Cacheable assets: ${analysis.cacheableAssets.count} (${analysis.cacheableAssets.totalSize})`);
    });
  }

  /**
   * Get npm version
   */
  getNpmVersion() {
    try {
      return this.execCommand('npm --version').trim();
    } catch (error) {
      return 'unknown';
    }
  }

  /**
   * Get directory size recursively
   */
  getDirectorySize(dirPath) {
    let totalSize = 0;
    
    const walkDir = (dir) => {
      const files = fs.readdirSync(dir);
      
      for (const file of files) {
        const filePath = path.join(dir, file);
        const stats = fs.statSync(filePath);
        
        if (stats.isDirectory()) {
          walkDir(filePath);
        } else {
          totalSize += stats.size;
        }
      }
    };
    
    try {
      walkDir(dirPath);
    } catch (error) {
      // Directory might not exist or be accessible
    }
    
    return totalSize;
  }

  /**
   * Get build statistics
   */
  getBuildStats(buildDir) {
    const stats = {
      totalFiles: 0,
      totalSize: 0,
      htmlFiles: 0,
      jsFiles: 0,
      cssFiles: 0,
      imageFiles: 0,
      otherFiles: 0
    };

    const walkDir = (dir) => {
      const files = fs.readdirSync(dir);
      
      for (const file of files) {
        const filePath = path.join(dir, file);
        const stat = fs.statSync(filePath);
        
        if (stat.isDirectory()) {
          walkDir(filePath);
        } else {
          stats.totalFiles++;
          stats.totalSize += stat.size;
          
          const ext = path.extname(file).toLowerCase();
          if (ext === '.html') stats.htmlFiles++;
          else if (ext === '.js') stats.jsFiles++;
          else if (ext === '.css') stats.cssFiles++;
          else if (['.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico'].includes(ext)) stats.imageFiles++;
          else stats.otherFiles++;
        }
      }
    };

    walkDir(buildDir);
    return stats;
  }

  /**
   * Get all files recursively
   */
  getAllFiles(dirPath) {
    const files = [];
    
    const walkDir = (dir) => {
      const items = fs.readdirSync(dir);
      
      for (const item of items) {
        const itemPath = path.join(dir, item);
        const stats = fs.statSync(itemPath);
        
        if (stats.isDirectory()) {
          walkDir(itemPath);
        } else {
          files.push(itemPath);
        }
      }
    };
    
    walkDir(dirPath);
    return files;
  }

  /**
   * Execute command with timeout
   */
  execCommand(command, options = {}) {
    try {
      return execSync(command, {
        encoding: 'utf8',
        stdio: 'pipe',
        timeout: options.timeout || 30000,
        env: options.env || process.env,
        ...options
      });
    } catch (error) {
      throw new Error(`Command failed: ${command}\n${error.message}`);
    }
  }

  /**
   * Format time duration
   */
  formatTime(milliseconds) {
    if (milliseconds < 1000) {
      return `${milliseconds}ms`;
    } else if (milliseconds < 60000) {
      return `${(milliseconds / 1000).toFixed(1)}s`;
    } else {
      const minutes = Math.floor(milliseconds / 60000);
      const seconds = ((milliseconds % 60000) / 1000).toFixed(1);
      return `${minutes}m ${seconds}s`;
    }
  }

  /**
   * Format bytes
   */
  formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }

  /**
   * Run individual test
   */
  test(testName, testFunction) {
    try {
      testFunction();
      console.log(`  ✅ ${testName}`);
      this.results.tests.push({ name: testName, status: 'passed' });
      this.results.passed++;
    } catch (error) {
      console.log(`  ❌ ${testName}: ${error.message}`);
      this.results.tests.push({ name: testName, status: 'failed', error: error.message });
      this.results.failed++;
    }
  }

  /**
   * Add warning
   */
  addWarning(message) {
    console.log(`  ⚠️  Warning: ${message}`);
    this.results.warnings.push(message);
  }

  /**
   * Generate performance report
   */
  generateReport() {
    const totalTime = Date.now() - this.startTime;
    
    console.log('\n' + '='.repeat(40));
    console.log('📊 Build Performance Benchmark Results');
    console.log('='.repeat(40));
    
    console.log(`\nTests: ${this.results.passed + this.results.failed}`);
    console.log(`Passed: ${this.results.passed}`);
    console.log(`Failed: ${this.results.failed}`);
    console.log(`Warnings: ${this.results.warnings.length}`);
    console.log(`Total Execution Time: ${this.formatTime(totalTime)}`);

    // Performance summary
    if (this.results.benchmarks.dependencyInstall) {
      console.log('\n⚡ Performance Summary:');
      console.log(`  Dependency Install: ${this.results.benchmarks.dependencyInstall.timeFormatted}`);
    }
    
    if (this.results.benchmarks.build) {
      console.log(`  Build Process: ${this.results.benchmarks.build.timeFormatted}`);
    }
    
    if (this.results.benchmarks.typeCheck && !this.results.benchmarks.typeCheck.skipped) {
      console.log(`  Type Check: ${this.results.benchmarks.typeCheck.timeFormatted}`);
    }
    
    if (this.results.benchmarks.lint && !this.results.benchmarks.lint.skipped) {
      console.log(`  Linting: ${this.results.benchmarks.lint.timeFormatted}`);
    }

    if (this.results.warnings.length > 0) {
      console.log('\n⚠️  Performance Warnings:');
      this.results.warnings.forEach(warning => {
        console.log(`  - ${warning}`);
      });
    }

    // Save detailed report
    const reportPath = `build-performance-report-${Date.now()}.json`;
    fs.writeFileSync(reportPath, JSON.stringify(this.results, null, 2));
    console.log(`\n📄 Detailed report saved: ${reportPath}`);

    if (this.results.failed > 0) {
      console.log('\n❌ Performance benchmarks failed. Please review the issues above.');
      process.exit(1);
    } else {
      console.log('\n✅ Performance benchmarks completed successfully!');
    }
  }
}

// Run benchmarks if called directly
if (require.main === module) {
  const benchmarks = new BuildPerformanceBenchmarks();
  benchmarks.runBenchmarks();
}

module.exports = BuildPerformanceBenchmarks;