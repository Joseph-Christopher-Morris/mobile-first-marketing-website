# Trust Logos Deployment Script
# Follows the 5-step process to ensure trust logos work correctly

param(
    [string]$S3_BUCKET_NAME = "mobile-marketing-site-prod-1759705011281-tyzuo9",
    [string]$CLOUDFRONT_DISTRIBUTION_ID = "E2IBMHQ3GCW6ZK",
    [string]$AWS_REGION = "us-east-1"
)

Write-Host "🚀 Starting Trust Logos Deployment Process..." -ForegroundColor Green
Write-Host "Bucket: $S3_BUCKET_NAME" -ForegroundColor Cyan
Write-Host "Distribution: $CLOUDFRONT_DISTRIBUTION_ID" -ForegroundColor Cyan

# Step 1: Verify files exist in S3 with correct case
Write-Host "`n📋 Step 1: Pre-deploy sanity check..." -ForegroundColor Yellow

$logoFiles = @("bbc.v1.png", "forbes.v1.png", "ft.v1.png")
$missingFiles = @()

foreach ($file in $logoFiles) {
    $result = aws s3 ls "s3://$S3_BUCKET_NAME/images/Trust/$file" 2>$null
    if (-not $result) {
        $missingFiles += $file
        Write-Host "❌ Missing: $file" -ForegroundColor Red
    } else {
        Write-Host "✅ Found: $file" -ForegroundColor Green
    }
}

# Upload missing files if any
if ($missingFiles.Count -gt 0) {
    Write-Host "`n📤 Uploading missing logos..." -ForegroundColor Yellow
    
    # Check if local files exist
    if (-not (Test-Path "public/images/Trust")) {
        Write-Host "❌ Local Trust folder not found. Creating build first..." -ForegroundColor Red
        npm run build
        if ($LASTEXITCODE -ne 0) {
            Write-Host "❌ Build failed!" -ForegroundColor Red
            exit 1
        }
    }
    
    foreach ($file in $missingFiles) {
        $localPath = "public/images/Trust/$file"
        if (Test-Path $localPath) {
            Write-Host "📤 Uploading $file..." -ForegroundColor Cyan
            aws s3 cp $localPath "s3://$S3_BUCKET_NAME/images/Trust/$file" --content-type "image/png" --cache-control "public,max-age=31536000,immutable"
        } else {
            Write-Host "❌ Local file not found: $localPath" -ForegroundColor Red
        }
    }
} else {
    Write-Host "✅ All logo files present in S3" -ForegroundColor Green
}

# Step 2: Test CloudFront URLs directly
Write-Host "`n🌐 Step 2: Testing CloudFront URLs..." -ForegroundColor Yellow

$baseUrl = "https://d15sc9fc739ev2.cloudfront.net"
$allUrlsWork = $true

foreach ($file in $logoFiles) {
    $url = "$baseUrl/images/Trust/$file"
    Write-Host "Testing: $url" -ForegroundColor Cyan
    
    try {
        $response = Invoke-WebRequest -Uri $url -Method Head -TimeoutSec 10 -ErrorAction Stop
        if ($response.StatusCode -eq 200) {
            Write-Host "✅ $file - HTTP 200" -ForegroundColor Green
        } else {
            Write-Host "❌ $file - HTTP $($response.StatusCode)" -ForegroundColor Red
            $allUrlsWork = $false
        }
    } catch {
        Write-Host "❌ $file - Failed to connect" -ForegroundColor Red
        $allUrlsWork = $false
    }
}

# Step 3: CloudFront invalidation if needed
if (-not $allUrlsWork) {
    Write-Host "`n🔄 Step 3: Creating CloudFront invalidation..." -ForegroundColor Yellow
    aws cloudfront create-invalidation --distribution-id $CLOUDFRONT_DISTRIBUTION_ID --paths "/images/Trust/*"
    Write-Host "✅ Invalidation created. URLs should work in 1-2 minutes." -ForegroundColor Green
} else {
    Write-Host "`n✅ Step 3: All URLs working, no invalidation needed" -ForegroundColor Green
}

# Step 4: Deploy order (images first, then HTML)
Write-Host "`n📦 Step 4: Deploying in correct order..." -ForegroundColor Yellow

# Ensure we have a fresh build
Write-Host "Building site..." -ForegroundColor Cyan
npm run build
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Build failed!" -ForegroundColor Red
    exit 1
}

# 4a: Upload versioned images first (idempotent)
Write-Host "📤 Uploading images first..." -ForegroundColor Cyan
foreach ($file in $logoFiles) {
    aws s3 cp "out/images/Trust/$file" "s3://$S3_BUCKET_NAME/images/Trust/$file" --content-type "image/png" --cache-control "public,max-age=31536000,immutable"
}

# 4b: Then upload HTML (short cache)
Write-Host "📤 Uploading HTML..." -ForegroundColor Cyan
aws s3 cp "out/index.html" "s3://$S3_BUCKET_NAME/index.html" --cache-control "public,max-age=0,must-revalidate"

# Upload remaining files
Write-Host "📤 Syncing remaining files..." -ForegroundColor Cyan
aws s3 sync out/ "s3://$S3_BUCKET_NAME/" --delete --cache-control "public,max-age=31536000,immutable" --exclude "*.html"

# Step 5: Health check after deploy
Write-Host "`n🏥 Step 5: Post-deployment health check..." -ForegroundColor Yellow

Start-Sleep -Seconds 5  # Brief pause for propagation

foreach ($file in $logoFiles) {
    $url = "$baseUrl/images/Trust/$file"
    try {
        $response = Invoke-WebRequest -Uri $url -Method Head -TimeoutSec 10 -ErrorAction Stop
        if ($response.StatusCode -eq 200) {
            Write-Host "✅ $file - HTTP 200" -ForegroundColor Green
        } else {
            Write-Host "❌ $file - HTTP $($response.StatusCode)" -ForegroundColor Red
        }
    } catch {
        Write-Host "❌ $file - Failed" -ForegroundColor Red
    }
}

# Final website check
Write-Host "`n🌐 Testing main website..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri $baseUrl -Method Head -TimeoutSec 10 -ErrorAction Stop
    if ($response.StatusCode -eq 200) {
        Write-Host "✅ Main site - HTTP 200" -ForegroundColor Green
    } else {
        Write-Host "❌ Main site - HTTP $($response.StatusCode)" -ForegroundColor Red
    }
} catch {
    Write-Host "❌ Main site - Failed" -ForegroundColor Red
}

Write-Host "`n🎉 Deployment complete!" -ForegroundColor Green
Write-Host "Visit: https://d15sc9fc739ev2.cloudfront.net" -ForegroundColor Cyan
Write-Host "Trust logos should appear below the hero section." -ForegroundColor Cyan