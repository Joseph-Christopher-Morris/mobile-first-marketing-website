#!/usr/bin/env pwsh

<#
.SYNOPSIS
    Quick deployment script for Vivid Auto SCRAM rebuild
    
.DESCRIPTION
    Simplified PowerShell deployment script that implements the core requirements:
    - npm ci && npm run build:static workflow
    - S3 sync with differentiated caching
    - CloudFront invalidation
    
.EXAMPLE
    .\scripts\deploy-quick.ps1
#>

# Configuration from requirements
$S3_BUCKET = "mobile-marketing-site-prod-1759705011281-tyzuo9"
$CLOUDFRONT_DISTRIBUTION_ID = "E2IBMHQ3GCW6ZK"
$AWS_REGION = "us-east-1"

Write-Host "🚀 Vivid Auto SCRAM Quick Deployment" -ForegroundColor Cyan
Write-Host "====================================" -ForegroundColor Cyan

# Step 1: Build static export (npm ci && npm run build:static)
Write-Host ""
Write-Host "📦 Building static export..." -ForegroundColor Yellow
npm ci
if ($LASTEXITCODE -ne 0) { 
    Write-Host "❌ npm ci failed" -ForegroundColor Red
    exit 1 
}

npm run build:static
if ($LASTEXITCODE -ne 0) { 
    Write-Host "❌ Build failed" -ForegroundColor Red
    exit 1 
}

Write-Host "✅ Build completed" -ForegroundColor Green

# Step 2: Deploy HTML files with short cache headers (10 minutes)
Write-Host ""
Write-Host "📤 Deploying HTML files (short cache)..." -ForegroundColor Yellow

aws s3 sync out/ s3://$S3_BUCKET/ `
    --region $AWS_REGION `
    --exclude "*" `
    --include "*.html" `
    --cache-control "public, max-age=600" `
    --delete

if ($LASTEXITCODE -ne 0) { 
    Write-Host "❌ HTML deployment failed" -ForegroundColor Red
    exit 1 
}

Write-Host "✅ HTML files deployed" -ForegroundColor Green

# Step 3: Deploy static assets with long cache headers (1 year)
Write-Host ""
Write-Host "📤 Deploying static assets (long cache)..." -ForegroundColor Yellow

aws s3 sync out/ s3://$S3_BUCKET/ `
    --region $AWS_REGION `
    --exclude "*.html" `
    --cache-control "public, max-age=31536000, immutable" `
    --delete

if ($LASTEXITCODE -ne 0) { 
    Write-Host "❌ Assets deployment failed" -ForegroundColor Red
    exit 1 
}

Write-Host "✅ Static assets deployed" -ForegroundColor Green

# Step 4: CloudFront invalidation with specified paths
Write-Host ""
Write-Host "🔄 Invalidating CloudFront cache..." -ForegroundColor Yellow

$invalidationPaths = @(
    "/",
    "/index.html", 
    "/services/*",
    "/blog*",
    "/images/*",
    "/sitemap.xml",
    "/_next/*"
)

aws cloudfront create-invalidation `
    --distribution-id $CLOUDFRONT_DISTRIBUTION_ID `
    --paths $invalidationPaths `
    --region us-east-1

if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Cache invalidation started" -ForegroundColor Green
    Write-Host "ℹ️  Invalidation may take 5-15 minutes to complete" -ForegroundColor Blue
} else {
    Write-Host "⚠️  Cache invalidation failed" -ForegroundColor Yellow
    Write-Host "   Deployment succeeded but cache may not be updated" -ForegroundColor Yellow
}

# Summary
Write-Host ""
Write-Host "🎉 Deployment completed!" -ForegroundColor Green
Write-Host "🌐 Site: https://d15sc9fc739ev2.cloudfront.net" -ForegroundColor Cyan
Write-Host "ℹ️  Changes may take 5-15 minutes to propagate globally" -ForegroundColor Blue