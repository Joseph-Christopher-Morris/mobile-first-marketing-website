/**
 * Tablet Layout Testing Script (768px width)
 * Tests responsive design at tablet breakpoint for home-press-pricing-update spec
 * Task 9.2: Verify services cards, pricing blocks, and press logos at 768px
 */

const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

const TABLET_WIDTH = 768;
const TABLET_HEIGHT = 1024;
const TEST_URL = 'http://localhost:3000';

async function testTabletLayout() {
  console.log('🧪 Starting Tablet Layout Tests (768px width)...\n');

  const results = {
    timestamp: new Date().toISOString(),
    viewport: { width: TABLET_WIDTH, height: TABLET_HEIGHT },
    tests: [],
    summary: {
      total: 0,
      passed: 0,
      failed: 0
    }
  };

  let browser;
  try {
    browser = await puppeteer.launch({
      headless: 'new',
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    await page.setViewport({
      width: TABLET_WIDTH,
      height: TABLET_HEIGHT,
      deviceScaleFactor: 1
    });

    console.log(`📱 Viewport set to ${TABLET_WIDTH}x${TABLET_HEIGHT} (tablet)\n`);

    // Test 1: Services Cards Display Two Per Row
    console.log('Test 1: Services cards display two per row');
    try {
      await page.goto(`${TEST_URL}/`, { waitUntil: 'networkidle0', timeout: 30000 });

      // Find the services grid
      const servicesGrid = await page.$('section:has(h2:text("My Services")) .grid, section:has(h2:text("Services")) .grid');
      
      if (!servicesGrid) {
        throw new Error('Services grid not found');
      }

      // Get grid computed styles
      const gridStyles = await page.evaluate((grid) => {
        const styles = window.getComputedStyle(grid);
        return {
          display: styles.display,
          gridTemplateColumns: styles.gridTemplateColumns,
          gap: styles.gap
        };
      }, servicesGrid);

      // Count service cards
      const serviceCards = await page.$$('section:has(h2:text("My Services")) .grid > div, section:has(h2:text("Services")) .grid > div');
      const cardCount = serviceCards.length;

      // Get card positions to verify 2-column layout
      const cardPositions = await page.evaluate(() => {
        const cards = Array.from(document.querySelectorAll('section h2'))
          .find(h2 => h2.textContent.includes('My Services') || h2.textContent.includes('Services'))
          ?.closest('section')
          ?.querySelectorAll('.grid > div') || [];
        
        return Array.from(cards).map(card => {
          const rect = card.getBoundingClientRect();
          return {
            left: Math.round(rect.left),
            top: Math.round(rect.top),
            width: Math.round(rect.width)
          };
        });
      });

      // Verify 2 columns by checking if cards are in pairs at same vertical position
      const rows = {};
      cardPositions.forEach(pos => {
        const rowKey = pos.top;
        if (!rows[rowKey]) rows[rowKey] = [];
        rows[rowKey].push(pos);
      });

      const cardsPerRow = Object.values(rows).map(row => row.length);
      const hasTwoPerRow = cardsPerRow.some(count => count === 2);

      results.tests.push({
        name: 'Services cards display two per row',
        status: hasTwoPerRow ? 'PASS' : 'FAIL',
        details: {
          gridDisplay: gridStyles.display,
          gridTemplateColumns: gridStyles.gridTemplateColumns,
          totalCards: cardCount,
          cardsPerRow: cardsPerRow,
          cardPositions: cardPositions
        },
        message: hasTwoPerRow 
          ? `✓ Services cards correctly display in 2-column layout (${cardsPerRow.join(', ')} cards per row)`
          : `✗ Services cards not displaying 2 per row (found: ${cardsPerRow.join(', ')} per row)`
      });

      console.log(results.tests[results.tests.length - 1].message);

    } catch (error) {
      results.tests.push({
        name: 'Services cards display two per row',
        status: 'FAIL',
        error: error.message
      });
      console.log(`✗ Test failed: ${error.message}`);
    }

    // Test 2: Pricing Blocks Render Correctly
    console.log('\nTest 2: Pricing blocks render correctly');
    try {
      // Check home page pricing teaser
      const pricingTeaser = await page.$('section:has(h2:text("Simple, transparent pricing")), section:has(h2:text("pricing"))');
      
      if (!pricingTeaser) {
        throw new Error('Pricing teaser section not found on home page');
     