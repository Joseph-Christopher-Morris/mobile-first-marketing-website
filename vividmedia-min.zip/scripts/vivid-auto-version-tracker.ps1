# Vivid Auto SCRAM Rebuild - Version Tracking Script
# This script tracks deployment versions and creates operational logs

param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("track", "history", "runbook", "health", "versions", "help")]
    [string]$Action = "help",
    
    [Parameter(Mandatory=$false)]
    [string]$DeploymentType = "manual",
    
    [Parameter(Mandatory=$false)]
    [int]$Limit = 10
)

# Vivid Auto SCRAM Infrastructure Configuration
$script:Config = @{
    Bucket = "mobile-marketing-site-prod-1759705011281-tyzuo9"
    DistributionId = "E2IBMHQ3GCW6ZK"
    Region = "us-east-1"
    Domain = "d15sc9fc739ev2.cloudfront.net"
    Environment = "production"
}

# Critical files for version tracking
$script:CriticalFiles = @(
    "index.html",
    "services/index.html",
    "blog/index.html", 
    "contact/index.html",
    "services/photography/index.html",
    "services/analytics/index.html",
    "services/ad-campaigns/index.html",
    "privacy-policy/index.html",
    "sitemap.xml",
    "robots.txt"
)

# Portfolio images for tracking
$script:PortfolioImages = @(
    "images/services/250928-hampson-auctions-sunday-11.webp",
    "images/services/240217-australia-trip-232-1.webp",
    "images/services/240219-australia-trip-148.webp",
    "images/services/240619-london-19.webp",
    "images/services/240619-london-26-1.webp",
    "images/services/240619-london-64.webp",
    "images/services/250125-liverpool-40.webp"
)

function Write-Header {
    param([string]$Title)
    Write-Host ""
    Write-Host "📝 Vivid Auto SCRAM Version Tracker" -ForegroundColor Cyan
    Write-Host "=" * 50 -ForegroundColor Gray
    Write-Host $Title -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Infrastructure:" -ForegroundColor Gray
    Write-Host "  S3 Bucket: $($Config.Bucket)" -ForegroundColor Gray
    Write-Host "  CloudFront: $($Config.DistributionId)" -ForegroundColor Gray
    Write-Host "  Domain: $($Config.Domain)" -ForegroundColor Gray
    Write-Host ""
}

function Test-AWSCredentials {
    try {
        $identity = aws sts get-caller-identity --output json | ConvertFrom-Json
        Write-Host "✅ AWS Credentials Valid" -ForegroundColor Green
        Write-Host "   Account: $($identity.Account)" -ForegroundColor Gray
        return $true
    }
    catch {
        Write-Host "❌ AWS Credentials Invalid or Missing" -ForegroundColor Red
        return $false
    }
}

function Get-GitState {
    $gitState = @{}
    
    try {
        $gitState.branch = git rev-parse --abbrev-ref HEAD 2>$null
        $gitState.commit = git rev-parse HEAD 2>$null
        $gitState.shortCommit = git rev-parse --short HEAD 2>$null
        $gitState.message = git log -1 --pretty=%B 2>$null
        $gitState.author = git log -1 --pretty=%an 2>$null
        $gitState.email = git log -1 --pretty=%ae 2>$null
        $gitState.date = git log -1 --pretty=%ai 2>$null
        $gitState.status = git status --porcelain 2>$null
        $gitState.remoteUrl = git config --get remote.origin.url 2>$null
        
        # Clean up whitespace
        foreach ($key in $gitState.Keys) {
            if ($gitState[$key]) {
                $gitState[$key] = $gitState[$key].Trim()
            }
        }
        
        return $gitState
    }
    catch {
        Write-Host "⚠️  Could not capture Git state: $($_.Exception.Message)" -ForegroundColor Yellow
        return @{ error = $_.Exception.Message }
    }
}

function Get-FileVersions {
    Write-Host "📋 Capturing file versions..." -ForegroundColor Cyan
    
    $versions = @{}
    
    foreach ($file in $script:CriticalFiles) {
        try {
            $versionData = aws s3api list-object-versions `
                --bucket $Config.Bucket `
                --prefix $file `
                --max-items 1 `
                --region $Config.Region `
                --output json | ConvertFrom-Json
            
            if ($versionData.Versions -and $versionData.Versions.Count -gt 0) {
                $latestVersion = $versionData.Versions | Where-Object { $_.IsLatest -eq $true } | Select-Object -First 1
                if (-not $latestVersion) {
                    $latestVersion = $versionData.Versions[0]
                }
                
                $versions[$file] = @{
                    versionId = $latestVersion.VersionId
                    lastModified = $latestVersion.LastModified
                    etag = $latestVersion.ETag
                    size = $latestVersion.Size
                    storageClass = $latestVersion.StorageClass
                }
                
                Write-Host "   📄 $file : $($latestVersion.VersionId.Substring(0,8))..." -ForegroundColor Gray
            }
        }
        catch {
            Write-Host "   ⚠️  Could not get version for $file : $($_.Exception.Message)" -ForegroundColor Yellow
            $versions[$file] = @{ error = $_.Exception.Message }
        }
    }
    
    return $versions
}

function Get-ImageVersions {
    Write-Host "🖼️  Capturing image versions..." -ForegroundColor Cyan
    
    $imageVersions = @{}
    
    foreach ($image in $script:PortfolioImages) {
        try {
            $versionData = aws s3api list-object-versions `
                --bucket $Config.Bucket `
                --prefix $image `
                --max-items 1 `
                --region $Config.Region `
                --output json | ConvertFrom-Json
            
            if ($versionData.Versions -and $versionData.Versions.Count -gt 0) {
                $latestVersion = $versionData.Versions | Where-Object { $_.IsLatest -eq $true } | Select-Object -First 1
                if (-not $latestVersion) {
                    $latestVersion = $versionData.Versions[0]
                }
                
                $imageVersions[$image] = @{
                    versionId = $latestVersion.VersionId
                    lastModified = $latestVersion.LastModified
                    etag = $latestVersion.ETag
                    size = $latestVersion.Size
                }
                
                Write-Host "   🖼️  $image : $($latestVersion.VersionId.Substring(0,8))..." -ForegroundColor Gray
            }
        }
        catch {
            Write-Host "   ⚠️  Could not get version for $image : $($_.Exception.Message)" -ForegroundColor Yellow
            $imageVersions[$image] = @{ error = $_.Exception.Message }
        }
    }
    
    return $imageVersions
}

function Get-BuildInfo {
    $buildInfo = @{
        timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
        nodeVersion = if (Get-Command node -ErrorAction SilentlyContinue) { node --version } else { "Not available" }
        platform = $env:OS
        arch = $env:PROCESSOR_ARCHITECTURE
        user = $env:USERNAME
        computer = $env:COMPUTERNAME
    }
    
    try {
        # Try to read package.json
        if (Test-Path "package.json") {
            $packageJson = Get-Content "package.json" | ConvertFrom-Json
            $buildInfo.packageVersion = $packageJson.version
            $buildInfo.dependencies = @{
                next = $packageJson.dependencies.next
                react = $packageJson.dependencies.react
                tailwindcss = $packageJson.devDependencies.tailwindcss
            }
        }
        
        # Check build output
        if (Test-Path "out") {
            $outInfo = Get-Item "out"
            $buildInfo.buildOutput = @{
                created = $outInfo.CreationTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
                modified = $outInfo.LastWriteTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
                size = (Get-ChildItem "out" -Recurse | Measure-Object -Property Length -Sum).Sum
            }
        }
        
        # Check Next.js build info
        if (Test-Path ".next/build-manifest.json") {
            $buildManifest = Get-Content ".next/build-manifest.json" | ConvertFrom-Json
            $buildInfo.nextjs = @{
                buildId = if ($buildManifest.devFiles) { "development" } else { "production" }
                pages = if ($buildManifest.pages) { $buildManifest.pages.PSObject.Properties.Count } else { 0 }
            }
        }
    }
    catch {
        $buildInfo.error = $_.Exception.Message
    }
    
    return $buildInfo
}

function Test-DeploymentHealth {
    Write-Host "🔍 Performing health check..." -ForegroundColor Cyan
    
    $healthCheck = @{
        timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
        checks = @{}
    }
    
    # Check S3 bucket accessibility
    try {
        aws s3api head-object --bucket $Config.Bucket --key "index.html" --region $Config.Region | Out-Null
        if ($LASTEXITCODE -eq 0) {
            $healthCheck.checks.s3Access = @{ status = "pass"; message = "S3 bucket accessible" }
        } else {
            $healthCheck.checks.s3Access = @{ status = "fail"; message = "S3 bucket not accessible" }
        }
    }
    catch {
        $healthCheck.checks.s3Access = @{ status = "fail"; message = $_.Exception.Message }
    }
    
    # Check CloudFront distribution
    try {
        $cfResult = aws cloudfront get-distribution --id $Config.DistributionId --region us-east-1 --output json | ConvertFrom-Json
        if ($LASTEXITCODE -eq 0) {
            $healthCheck.checks.cloudfront = @{ 
                status = "pass"
                message = "Distribution status: $($cfResult.Distribution.Status)"
                enabled = $cfResult.Distribution.DistributionConfig.Enabled
            }
        } else {
            $healthCheck.checks.cloudfront = @{ status = "fail"; message = "CloudFront distribution not accessible" }
        }
    }
    catch {
        $healthCheck.checks.cloudfront = @{ status = "fail"; message = $_.Exception.Message }
    }
    
    # Check critical files exist
    $criticalFilesCount = 0
    foreach ($file in $script:CriticalFiles[0..4]) { # Check first 5 files
        try {
            aws s3api head-object --bucket $Config.Bucket --key $file --region $Config.Region | Out-Null
            if ($LASTEXITCODE -eq 0) {
                $criticalFilesCount++
            }
        }
        catch {
            # File doesn't exist or not accessible
        }
    }
    
    $healthCheck.checks.criticalFiles = @{
        status = if ($criticalFilesCount -gt 0) { "pass" } else { "fail" }
        message = "$criticalFilesCount/5 critical files accessible"
    }
    
    return $healthCheck
}

function New-DeploymentLog {
    param(
        [string]$Type = "manual"
    )
    
    Write-Header "Creating Deployment Log"
    
    if (-not (Test-AWSCredentials)) {
        return
    }
    
    $timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
    $deploymentId = "deploy-$($timestamp.Replace(':', '-').Replace('.', '-'))"
    
    Write-Host "📝 Deployment ID: $deploymentId" -ForegroundColor Cyan
    Write-Host "📅 Timestamp: $timestamp" -ForegroundColor Gray
    Write-Host "🏷️  Type: $Type" -ForegroundColor Gray
    Write-Host ""
    
    # Gather deployment information
    $gitState = Get-GitState
    $versions = Get-FileVersions
    $imageVersions = Get-ImageVersions
    $buildInfo = Get-BuildInfo
    $healthCheck = Test-DeploymentHealth
    
    # Create deployment log object
    $deploymentLog = @{
        id = $deploymentId
        timestamp = $timestamp
        type = $Type
        environment = $Config.Environment
        infrastructure = $Config
        git = $gitState
        versions = $versions
        portfolioImages = $imageVersions
        buildInfo = $buildInfo
        health = $healthCheck
        metadata = @{
            triggeredBy = $env:USERNAME
            computer = $env:COMPUTERNAME
            powershellVersion = $PSVersionTable.PSVersion.ToString()
        }
    }
    
    # Calculate integrity hash
    $integrityData = @{
        bucket = $Config.Bucket
        distributionId = $Config.DistributionId
        timestamp = $timestamp
        criticalFiles = $script:CriticalFiles | Sort-Object
        portfolioImages = $script:PortfolioImages | Sort-Object
    }
    $integrityString = ($integrityData | ConvertTo-Json -Compress)
    $deploymentLog.integrity = [System.Security.Cryptography.SHA256]::Create().ComputeHash([System.Text.Encoding]::UTF8.GetBytes($integrityString)) | ForEach-Object { $_.ToString("x2") } | Join-String
    
    # Save deployment log to S3
    $logKey = "deployment-logs/$deploymentId.json"
    $logJson = $deploymentLog | ConvertTo-Json -Depth 10
    
    try {
        # Create temporary file for upload
        $tempFile = [System.IO.Path]::GetTempFileName()
        $logJson | Out-File -FilePath $tempFile -Encoding UTF8
        
        # Upload to S3
        aws s3api put-object `
            --bucket $Config.Bucket `
            --key $logKey `
            --body $tempFile `
            --content-type "application/json" `
            --metadata "deployment-id=$deploymentId,deployment-type=$Type,environment=$($Config.Environment),timestamp=$timestamp" `
            --region $Config.Region
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✅ Deployment log saved successfully" -ForegroundColor Green
            Write-Host "   Log Key: $logKey" -ForegroundColor Gray
            Write-Host "   Critical Files: $($versions.Keys.Count)" -ForegroundColor Gray
            Write-Host "   Portfolio Images: $($imageVersions.Keys.Count)" -ForegroundColor Gray
        } else {
            Write-Host "❌ Failed to save deployment log" -ForegroundColor Red
        }
        
        # Clean up temp file
        Remove-Item $tempFile -ErrorAction SilentlyContinue
        
        # Update latest deployment pointer
        $pointer = @{
            latestDeployment = $deploymentId
            timestamp = $timestamp
            type = $Type
            environment = $Config.Environment
            git = @{
                commit = $gitState.commit
                shortCommit = $gitState.shortCommit
                branch = $gitState.branch
            }
        }
        
        $pointerJson = $pointer | ConvertTo-Json -Depth 5
        $pointerTempFile = [System.IO.Path]::GetTempFileName()
        $pointerJson | Out-File -FilePath $pointerTempFile -Encoding UTF8
        
        aws s3api put-object `
            --bucket $Config.Bucket `
            --key "deployment-logs/latest.json" `
            --body $pointerTempFile `
            --content-type "application/json" `
            --region $Config.Region
        
        Remove-Item $pointerTempFile -ErrorAction SilentlyContinue
        
        return $deploymentLog
    }
    catch {
        Write-Host "❌ Error saving deployment log: $($_.Exception.Message)" -ForegroundColor Red
        return $null
    }
}

function Get-DeploymentHistory {
    param([int]$HistoryLimit = 10)
    
    Write-Header "Deployment History"
    
    if (-not (Test-AWSCredentials)) {
        return
    }
    
    Write-Host "📚 Retrieving deployment history (limit: $HistoryLimit)..." -ForegroundColor Cyan
    
    try {
        # List deployment log files
        $logFiles = aws s3api list-objects-v2 `
            --bucket $Config.Bucket `
            --prefix "deployment-logs/" `
            --region $Config.Region `
            --output json | ConvertFrom-Json
        
        if (-not $logFiles.Contents) {
            Write-Host "📁 No deployment logs found" -ForegroundColor Yellow
            return
        }
        
        # Filter JSON files and sort by date
        $deploymentFiles = $logFiles.Contents | 
            Where-Object { $_.Key -match "\.json$" -and $_.Key -ne "deployment-logs/latest.json" } |
            Sort-Object LastModified -Descending |
            Select-Object -First $HistoryLimit
        
        Write-Host ""
        Write-Host "📋 Deployment History:" -ForegroundColor Green
        Write-Host ("-" * 80) -ForegroundColor Gray
        Write-Host ("{0,-25} {1,-20} {2,-15} {3,-10} {4}" -f "Deployment ID", "Timestamp", "Type", "Git", "Status") -ForegroundColor White
        Write-Host ("-" * 80) -ForegroundColor Gray
        
        foreach ($file in $deploymentFiles) {
            try {
                # Download and parse deployment log
                $tempFile = [System.IO.Path]::GetTempFileName()
                aws s3api get-object --bucket $Config.Bucket --key $file.Key --region $Config.Region $tempFile | Out-Null
                
                if ($LASTEXITCODE -eq 0) {
                    $deployment = Get-Content $tempFile | ConvertFrom-Json
                    
                    $deploymentIdShort = $deployment.id.Replace("deploy-", "").Substring(0, 20) + "..."
                    $timestampFormatted = [DateTime]::Parse($deployment.timestamp).ToString("yyyy-MM-dd HH:mm")
                    $gitShort = if ($deployment.git.shortCommit) { $deployment.git.shortCommit } else { "N/A" }
                    $status = if ($deployment.health.checks.s3Access.status -eq "pass") { "✅" } else { "❌" }
                    
                    Write-Host ("{0,-25} {1,-20} {2,-15} {3,-10} {4}" -f $deploymentIdShort, $timestampFormatted, $deployment.type, $gitShort, $status) -ForegroundColor Gray
                }
                
                Remove-Item $tempFile -ErrorAction SilentlyContinue
            }
            catch {
                Write-Host "⚠️  Could not read deployment log: $($file.Key)" -ForegroundColor Yellow
            }
        }
        
        Write-Host ""
        Write-Host "📊 Summary: $($deploymentFiles.Count) deployments found" -ForegroundColor Cyan
    }
    catch {
        Write-Host "❌ Failed to retrieve deployment history: $($_.Exception.Message)" -ForegroundColor Red
    }
}

function New-OperationalRunbook {
    Write-Header "Generating Operational Runbook"
    
    if (-not (Test-AWSCredentials)) {
        return
    }
    
    Write-Host "📖 Generating operational runbook..." -ForegroundColor Cyan
    
    # Get current versions and health status
    $versions = Get-FileVersions
    $healthCheck = Test-DeploymentHealth
    $gitState = Get-GitState
    
    # Create runbook content
    $runbook = @"
# Vivid Auto SCRAM Rebuild - Operational Runbook

**Generated:** $(Get-Date -Format "yyyy-MM-dd HH:mm:ss UTC")
**Environment:** $($Config.Environment)

## Infrastructure

- **S3 Bucket:** $($Config.Bucket)
- **CloudFront Distribution:** $($Config.DistributionId)
- **Domain:** $($Config.Domain)
- **Region:** $($Config.Region)

## Current Deployment Status

- **Git Branch:** $($gitState.branch)
- **Git Commit:** $($gitState.shortCommit) - $($gitState.message)
- **Last Modified:** $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")

## Critical File Versions

$(foreach ($file in $versions.Keys | Sort-Object) {
    $version = $versions[$file]
    if ($version.versionId) {
        "- **$file:** $($version.versionId.Substring(0,8))... ($([DateTime]::Parse($version.lastModified).ToString("yyyy-MM-dd HH:mm")))"
    } else {
        "- **$file:** Error - $($version.error)"
    }
} | Out-String)

## Health Check Status

$(foreach ($check in $healthCheck.checks.Keys) {
    $result = $healthCheck.checks[$check]
    $status = if ($result.status -eq "pass") { "✅" } else { "❌" }
    "$status **$check:** $($result.message)"
} | Out-String)

## Rollback Procedures

### Emergency Rollback
Rollback all critical files to previous versions:
``````powershell
.\scripts\vivid-auto-rollback.ps1 -Action emergency
``````
**Estimated Time:** 5-10 minutes

### Selective Rollback
Rollback specific file to target version:
``````powershell
.\scripts\vivid-auto-rollback.ps1 -Action rollback -File "index.html" -VersionId "VERSION_ID"
``````
**Estimated Time:** 2-5 minutes

## Verification Procedures

### Automated Health Check
``````powershell
.\scripts\vivid-auto-rollback.ps1 -Action verify
``````

### Manual Verification Checklist

- [ ] Visit https://$($Config.Domain)/ - verify home page loads
- [ ] Check services page - verify all 7 portfolio images load
- [ ] Test contact form - verify all fields present and functional
- [ ] Verify blog page - confirm Flyers ROI article is visible
- [ ] Check brand compliance - no gradients or prohibited colors

## Troubleshooting

### Website Not Loading
**Solution:** Check CloudFront distribution status and S3 bucket accessibility

### Images Not Loading (404 errors)
**Solution:** Verify image file names match kebab-case format and exist in S3

### Brand Colors Incorrect
**Solution:** Check for prohibited CSS classes (gradients, indigo, purple, yellow)

### Contact Form Not Working
**Solution:** Verify form structure matches original specification

## Emergency Contacts

- **Primary Support:** Development Team
- **Escalation:** Technical Lead
- **Documentation:** docs/vivid-auto-rollback-procedures.md

## Version Tracking Commands

``````powershell
# Track new deployment
.\scripts\vivid-auto-version-tracker.ps1 -Action track -DeploymentType manual

# View deployment history
.\scripts\vivid-auto-version-tracker.ps1 -Action history -Limit 10

# Check current versions
.\scripts\vivid-auto-version-tracker.ps1 -Action versions

# Perform health check
.\scripts\vivid-auto-version-tracker.ps1 -Action health
``````
"@

    try {
        # Save runbook locally
        $runbookFile = "vivid-auto-operational-runbook.md"
        $runbook | Out-File -FilePath $runbookFile -Encoding UTF8
        
        # Upload to S3
        aws s3api put-object `
            --bucket $Config.Bucket `
            --key "operational-runbook.md" `
            --body $runbookFile `
            --content-type "text/markdown" `
            --metadata "document-type=operational-runbook,generated=$(Get-Date -Format 'yyyy-MM-ddTHH:mm:ss'),environment=$($Config.Environment)" `
            --region $Config.Region
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✅ Operational runbook generated successfully" -ForegroundColor Green
            Write-Host "   Local file: $runbookFile" -ForegroundColor Gray
            Write-Host "   S3 key: operational-runbook.md" -ForegroundColor Gray
        } else {
            Write-Host "❌ Failed to upload runbook to S3" -ForegroundColor Red
        }
    }
    catch {
        Write-Host "❌ Error generating runbook: $($_.Exception.Message)" -ForegroundColor Red
    }
}

function Show-CurrentVersions {
    Write-Header "Current File Versions"
    
    if (-not (Test-AWSCredentials)) {
        return
    }
    
    $versions = Get-FileVersions
    
    Write-Host ""
    Write-Host "📋 Critical File Versions:" -ForegroundColor Green
    Write-Host ("-" * 80) -ForegroundColor Gray
    Write-Host ("{0,-40} {1,-25} {2}" -f "File", "Version ID", "Last Modified") -ForegroundColor White
    Write-Host ("-" * 80) -ForegroundColor Gray
    
    foreach ($file in $versions.Keys | Sort-Object) {
        $version = $versions[$file]
        if ($version.versionId) {
            $versionIdShort = $version.versionId.Substring(0, 20) + "..."
            $lastModified = [DateTime]::Parse($version.lastModified).ToString("yyyy-MM-dd HH:mm:ss")
            Write-Host ("{0,-40} {1,-25} {2}" -f $file, $versionIdShort, $lastModified) -ForegroundColor Gray
        } else {
            Write-Host ("{0,-40} {1,-25} {2}" -f $file, "ERROR", $version.error) -ForegroundColor Red
        }
    }
    
    Write-Host ""
    Write-Host "🖼️  Portfolio Image Versions:" -ForegroundColor Green
    $imageVersions = Get-ImageVersions
    
    foreach ($image in $imageVersions.Keys | Sort-Object) {
        $version = $imageVersions[$image]
        if ($version.versionId) {
            $versionIdShort = $version.versionId.Substring(0, 20) + "..."
            $lastModified = [DateTime]::Parse($version.lastModified).ToString("yyyy-MM-dd HH:mm:ss")
            Write-Host ("{0,-40} {1,-25} {2}" -f $image, $versionIdShort, $lastModified) -ForegroundColor Gray
        } else {
            Write-Host ("{0,-40} {1,-25} {2}" -f $image, "ERROR", $version.error) -ForegroundColor Red
        }
    }
}

function Show-HealthStatus {
    Write-Header "Deployment Health Check"
    
    if (-not (Test-AWSCredentials)) {
        return
    }
    
    $healthCheck = Test-DeploymentHealth
    
    Write-Host "🔍 Health Check Results:" -ForegroundColor Cyan
    Write-Host ("-" * 50) -ForegroundColor Gray
    
    foreach ($check in $healthCheck.checks.Keys) {
        $result = $healthCheck.checks[$check]
        $status = if ($result.status -eq "pass") { "✅ PASS" } else { "❌ FAIL" }
        Write-Host "$status $check : $($result.message)" -ForegroundColor $(if ($result.status -eq "pass") { "Green" } else { "Red" })
    }
    
    Write-Host ""
    Write-Host "📊 Overall Status:" -ForegroundColor Cyan
    $passCount = ($healthCheck.checks.Values | Where-Object { $_.status -eq "pass" }).Count
    $totalCount = $healthCheck.checks.Count
    
    if ($passCount -eq $totalCount) {
        Write-Host "   ✅ All checks passed ($passCount/$totalCount)" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️  Some checks failed ($passCount/$totalCount)" -ForegroundColor Yellow
    }
}

function Show-Help {
    Write-Header "Help - Available Commands"
    
    Write-Host "Available Actions:" -ForegroundColor Cyan
    Write-Host ""
    
    Write-Host "📝 track" -ForegroundColor Green
    Write-Host "   Create deployment log and version snapshot"
    Write-Host "   Usage: .\vivid-auto-version-tracker.ps1 -Action track [-DeploymentType manual|auto|rollback]"
    Write-Host ""
    
    Write-Host "📚 history" -ForegroundColor Green
    Write-Host "   Show deployment history"
    Write-Host "   Usage: .\vivid-auto-version-tracker.ps1 -Action history [-Limit 10]"
    Write-Host ""
    
    Write-Host "📖 runbook" -ForegroundColor Green
    Write-Host "   Generate operational runbook"
    Write-Host "   Usage: .\vivid-auto-version-tracker.ps1 -Action runbook"
    Write-Host ""
    
    Write-Host "🔍 health" -ForegroundColor Green
    Write-Host "   Perform deployment health check"
    Write-Host "   Usage: .\vivid-auto-version-tracker.ps1 -Action health"
    Write-Host ""
    
    Write-Host "📋 versions" -ForegroundColor Green
    Write-Host "   Show current file and image versions"
    Write-Host "   Usage: .\vivid-auto-version-tracker.ps1 -Action versions"
    Write-Host ""
    
    Write-Host "Examples:" -ForegroundColor Yellow
    Write-Host "   # Track manual deployment"
    Write-Host "   .\vivid-auto-version-tracker.ps1 -Action track -DeploymentType manual"
    Write-Host ""
    Write-Host "   # View last 5 deployments"
    Write-Host "   .\vivid-auto-version-tracker.ps1 -Action history -Limit 5"
    Write-Host ""
    Write-Host "   # Generate operational runbook"
    Write-Host "   .\vivid-auto-version-tracker.ps1 -Action runbook"
    Write-Host ""
    Write-Host "   # Check deployment health"
    Write-Host "   .\vivid-auto-version-tracker.ps1 -Action health"
}

# Main execution
switch ($Action) {
    "track" {
        New-DeploymentLog -Type $DeploymentType
    }
    
    "history" {
        Get-DeploymentHistory -HistoryLimit $Limit
    }
    
    "runbook" {
        New-OperationalRunbook
    }
    
    "health" {
        Show-HealthStatus
    }
    
    "versions" {
        Show-CurrentVersions
    }
    
    "help" {
        Show-Help
    }
    
    default {
        Show-Help
    }
}