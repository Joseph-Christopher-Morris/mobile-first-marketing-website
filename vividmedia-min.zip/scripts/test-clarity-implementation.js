/**
 * Microsoft Clarity Implementation Test
 * Validates that Clarity is properly configured without duplicates or conflicts
 */

const fs = require('fs');
const path = require('path');

console.log('🔍 Microsoft Clarity Implementation Test\n');
console.log('=' .repeat(60));

let allTestsPassed = true;

// Test 1: Check layout.tsx has single Clarity implementation
console.log('\n✓ Test 1: Single Clarity Implementation in layout.tsx');
const layoutPath = path.join(__dirname, '../src/app/layout.tsx');
const layoutContent = fs.readFileSync(layoutPath, 'utf8');

const clarityMatches = layoutContent.match(/clarity\.ms\/tag\//g) || [];
const clarityScriptCount = clarityMatches.length;

console.log(`   Clarity script references found: ${clarityScriptCount}`);
if (clarityScriptCount === 1) {
  console.log('   ✅ PASS: Exactly one Clarity script found');
} else {
  console.log(`   ❌ FAIL: Expected 1 Clarity script, found ${clarityScriptCount}`);
  allTestsPassed = false;
}

// Test 2: Check for dangerouslySetInnerHTML usage (recommended pattern)
console.log('\n✓ Test 2: Using Recommended Pattern');
const usesDangerouslySetInnerHTML = layoutContent.includes('dangerouslySetInnerHTML');
console.log(`   Uses dangerouslySetInnerHTML: ${usesDangerouslySetInnerHTML ? 'YES' : 'NO'}`);
if (usesDangerouslySetInnerHTML) {
  console.log('   ✅ PASS: Using recommended Next.js Script pattern');
} else {
  console.log('   ⚠️  WARNING: Consider using dangerouslySetInnerHTML pattern');
}

// Test 3: Check for correct project ID
console.log('\n✓ Test 3: Correct Project ID');
const hasCorrectProjectId = layoutContent.includes('u4yftkmpxx');
console.log(`   Project ID (u4yftkmpxx): ${hasCorrectProjectId ? 'FOUND' : 'NOT FOUND'}`);
if (hasCorrectProjectId) {
  console.log('   ✅ PASS: Correct project ID configured');
} else {
  console.log('   ❌ FAIL: Project ID not found or incorrect');
  allTestsPassed = false;
}

// Test 4: Check for afterInteractive strategy
console.log('\n✓ Test 4: Optimal Loading Strategy');
const hasAfterInteractive = layoutContent.includes('strategy="afterInteractive"');
console.log(`   afterInteractive strategy: ${hasAfterInteractive ? 'YES' : 'NO'}`);
if (hasAfterInteractive) {
  console.log('   ✅ PASS: Using optimal loading strategy');
} else {
  console.log('   ❌ FAIL: afterInteractive strategy not found');
  allTestsPassed = false;
}

// Test 5: Check for custom/advanced loader (should NOT exist)
console.log('\n✓ Test 5: No Custom Advanced Loader');
const hasCustomLoader = layoutContent.includes('scripts.clarity.ms/0.8.41/clarity.js');
const hasDobParameter = layoutContent.includes('"dob": 2150');
console.log(`   Custom loader found: ${hasCustomLoader ? 'YES (BAD)' : 'NO (GOOD)'}`);
console.log(`   Advanced config found: ${hasDobParameter ? 'YES (BAD)' : 'NO (GOOD)'}`);
if (!hasCustomLoader && !hasDobParameter) {
  console.log('   ✅ PASS: No conflicting custom loaders');
} else {
  console.log('   ❌ FAIL: Custom loader detected - must be removed');
  allTestsPassed = false;
}

// Test 6: Check for duplicate Clarity scripts in other files
console.log('\n✓ Test 6: No Duplicate Scripts in Other Files');
const srcDir = path.join(__dirname, '../src');

function searchForClarityInFiles(dir, results = []) {
  const files = fs.readdirSync(dir);
  
  for (const file of files) {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory() && !file.includes('node_modules')) {
      searchForClarityInFiles(filePath, results);
    } else if (file.match(/\.(tsx?|jsx?)$/)) {
      const content = fs.readFileSync(filePath, 'utf8');
      if (content.includes('clarity.ms') && !filePath.includes('layout.tsx')) {
        results.push(filePath);
      }
    }
  }
  
  return results;
}

const duplicateFiles = searchForClarityInFiles(srcDir);
console.log(`   Files with Clarity references: ${duplicateFiles.length}`);
if (duplicateFiles.length === 0) {
  console.log('   ✅ PASS: No duplicate Clarity scripts found');
} else {
  console.log('   ❌ FAIL: Duplicate Clarity scripts found in:');
  duplicateFiles.forEach(file => console.log(`      - ${file}`));
  allTestsPassed = false;
}

// Test 7: Check for window.clarity overrides
console.log('\n✓ Test 7: No window.clarity Overrides');
const hasWindowClarityOverride = layoutContent.includes('window.clarity =');
console.log(`   window.clarity override: ${hasWindowClarityOverride ? 'FOUND (BAD)' : 'NOT FOUND (GOOD)'}`);
if (!hasWindowClarityOverride) {
  console.log('   ✅ PASS: No window.clarity overrides');
} else {
  console.log('   ❌ FAIL: window.clarity override detected');
  allTestsPassed = false;
}

// Test 8: Check build output
console.log('\n✓ Test 8: Build Output Validation');
const outDir = path.join(__dirname, '../out');
if (fs.existsSync(outDir)) {
  const indexPath = path.join(outDir, 'index.html');
  if (fs.existsSync(indexPath)) {
    const indexContent = fs.readFileSync(indexPath, 'utf8');
    const buildHasClarityScript = indexContent.includes('clarity.ms/tag/');
    const buildClarityCount = (indexContent.match(/clarity\.ms\/tag\//g) || []).length;
    
    console.log(`   Clarity in build output: ${buildHasClarityScript ? 'YES' : 'NO'}`);
    console.log(`   Clarity script count in build: ${buildClarityCount}`);
    
    if (buildHasClarityScript && buildClarityCount === 1) {
      console.log('   ✅ PASS: Build output contains single Clarity script');
    } else if (buildClarityCount > 1) {
      console.log('   ❌ FAIL: Multiple Clarity scripts in build output');
      allTestsPassed = false;
    } else {
      console.log('   ❌ FAIL: Clarity script not found in build output');
      allTestsPassed = false;
    }
  } else {
    console.log('   ⚠️  WARNING: Build output not found - run npm run build first');
  }
} else {
  console.log('   ⚠️  WARNING: Build directory not found - run npm run build first');
}

// Final Summary
console.log('\n' + '='.repeat(60));
if (allTestsPassed) {
  console.log('\n✅ ALL TESTS PASSED!');
  console.log('\n📋 Implementation Summary:');
  console.log('   ✓ Single Clarity script in layout.tsx');
  console.log('   ✓ Correct project ID (u4yftkmpxx)');
  console.log('   ✓ Optimal loading strategy (afterInteractive)');
  console.log('   ✓ No duplicate or conflicting scripts');
  console.log('   ✓ No custom loaders or overrides');
  
  console.log('\n🚀 Ready for Deployment!');
  console.log('\n📊 Post-Deployment Verification:');
  console.log('   1. Deploy to production');
  console.log('   2. Run: node scripts/validate-clarity-setup.js');
  console.log('   3. Check Microsoft Clarity dashboard');
  console.log('   4. Verify session recordings appear within 5-10 minutes');
  
  process.exit(0);
} else {
  console.log('\n❌ SOME TESTS FAILED');
  console.log('\n🔧 Action Required:');
  console.log('   Review the failed tests above and fix the issues');
  console.log('   Then run this test again');
  
  process.exit(1);
}
