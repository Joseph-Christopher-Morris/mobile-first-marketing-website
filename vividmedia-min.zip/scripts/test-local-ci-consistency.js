#!/usr/bin/env node

/**
 * Test Local-CI Environment Consistency
 * 
 * This script verifies that local and CI environments are consistent
 * by testing Node version requirements, lockfile integrity, and build consistency.
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

class LocalCIConsistencyTester {
  constructor() {
    this.results = {
      nodeVersion: { status: 'pending', details: [] },
      lockfileConsistency: { status: 'pending', details: [] },
      buildConsistency: { status: 'pending', details: [] },
      packageEngines: { status: 'pending', details: [] }
    };
    this.errors = [];
    this.warnings = [];
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const prefix = type === 'error' ? '❌' : type === 'warning' ? '⚠️' : type === 'success' ? '✅' : 'ℹ️';
    console.log(`${prefix} [${timestamp}] ${message}`);
  }

  async testNodeVersionConsistency() {
    this.log('Testing Node.js version consistency...', 'info');
    
    try {
      // Get current Node version
      const currentNodeVersion = process.version;
      this.log(`Current Node.js version: ${currentNodeVersion}`);
      
      // Read package.json engines
      const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
      const requiredNodeVersion = packageJson.engines?.node;
      const requiredNpmVersion = packageJson.engines?.npm;
      
      this.log(`Required Node.js version: ${requiredNodeVersion}`);
      this.log(`Required npm version: ${requiredNpmVersion}`);
      
      // Check if current version meets requirements
      const currentMajor = parseInt(currentNodeVersion.slice(1).split('.')[0]);
      const requiredMajor = parseInt(requiredNodeVersion.replace('>=', '').split('.')[0]);
      
      if (currentMajor >= requiredMajor) {
        this.results.nodeVersion.status = 'pass';
        this.results.nodeVersion.details.push(`Node.js ${currentNodeVersion} meets requirement ${requiredNodeVersion}`);
        this.log(`Node.js version check passed`, 'success');
      } else {
        this.results.nodeVersion.status = 'fail';
        this.results.nodeVersion.details.push(`Node.js ${currentNodeVersion} does not meet requirement ${requiredNodeVersion}`);
        this.errors.push(`Local Node.js version ${currentNodeVersion} is incompatible with CI requirement ${requiredNodeVersion}`);
        this.log(`Node.js version check failed - upgrade required`, 'error');
      }
      
      // Check npm version
      const npmVersion = execSync('npm -v', { encoding: 'utf8' }).trim();
      this.log(`Current npm version: ${npmVersion}`);
      this.results.nodeVersion.details.push(`npm version: ${npmVersion}`);
      
      // Read CI workflow configuration
      const workflowPath = '.github/workflows/quality-check.yml';
      if (fs.existsSync(workflowPath)) {
        const workflowContent = fs.readFileSync(workflowPath, 'utf8');
        const nodeVersionMatch = workflowContent.match(/node-version:\s*['"]?([^'"\\s]+)['"]?/);
        if (nodeVersionMatch) {
          const ciNodeVersion = nodeVersionMatch[1];
          this.log(`CI Node.js version: ${ciNodeVersion}`);
          this.results.nodeVersion.details.push(`CI Node.js version: ${ciNodeVersion}`);
          
          if (currentNodeVersion !== `v${ciNodeVersion}`) {
            this.warnings.push(`Local Node.js ${currentNodeVersion} differs from CI Node.js v${ciNodeVersion}`);
            this.log(`Version mismatch between local and CI environments`, 'warning');
          }
        }
      }
      
    } catch (error) {
      this.results.nodeVersion.status = 'error';
      this.results.nodeVersion.details.push(`Error: ${error.message}`);
      this.errors.push(`Node version check failed: ${error.message}`);
      this.log(`Node version check error: ${error.message}`, 'error');
    }
  }

  async testLockfileConsistency() {
    this.log('Testing lockfile consistency...', 'info');
    
    try {
      // Check if package-lock.json exists
      if (!fs.existsSync('package-lock.json')) {
        this.results.lockfileConsistency.status = 'fail';
        this.results.lockfileConsistency.details.push('package-lock.json not found');
        this.errors.push('package-lock.json is missing - run npm install to generate it');
        this.log('package-lock.json not found', 'error');
        return;
      }
      
      // Get current lockfile hash
      const originalLockfile = fs.readFileSync('package-lock.json', 'utf8');
      const originalHash = require('crypto').createHash('md5').update(originalLockfile).digest('hex');
      
      this.log('Running npm ci to test lockfile consistency...');
      
      // Run npm ci in a way that doesn't modify files
      try {
        execSync('npm ci --dry-run', { encoding: 'utf8', stdio: 'pipe' });
        this.log('npm ci --dry-run completed successfully');
        
        // For a more thorough test, we could run actual npm ci but that might modify node_modules
        // Instead, we'll check if the lockfile is valid and consistent
        const lockfileContent = JSON.parse(originalLockfile);
        
        if (lockfileContent.lockfileVersion && lockfileContent.packages) {
          this.results.lockfileConsistency.status = 'pass';
          this.results.lockfileConsistency.details.push('Lockfile structure is valid');
          this.results.lockfileConsistency.details.push(`Lockfile version: ${lockfileContent.lockfileVersion}`);
          this.log('Lockfile consistency check passed', 'success');
        } else {
          this.results.lockfileConsistency.status = 'fail';
          this.results.lockfileConsistency.details.push('Lockfile structure is invalid');
          this.errors.push('package-lock.json has invalid structure');
          this.log('Lockfile structure is invalid', 'error');
        }
        
      } catch (npmError) {
        this.results.lockfileConsistency.status = 'fail';
        this.results.lockfileConsistency.details.push(`npm ci failed: ${npmError.message}`);
        this.errors.push(`npm ci validation failed: ${npmError.message}`);
        this.log(`npm ci validation failed: ${npmError.message}`, 'error');
      }
      
    } catch (error) {
      this.results.lockfileConsistency.status = 'error';
      this.results.lockfileConsistency.details.push(`Error: ${error.message}`);
      this.errors.push(`Lockfile consistency check failed: ${error.message}`);
      this.log(`Lockfile consistency error: ${error.message}`, 'error');
    }
  }

  async testBuildConsistency() {
    this.log('Testing build consistency...', 'info');
    
    try {
      // Check if build script exists
      const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
      if (!packageJson.scripts?.build) {
        this.results.buildConsistency.status = 'fail';
        this.results.buildConsistency.details.push('No build script found in package.json');
        this.errors.push('Build script not found in package.json');
        this.log('Build script not found', 'error');
        return;
      }
      
      this.log('Testing build with CI environment variables...');
      
      // Set CI environment variables like in GitHub Actions
      const env = {
        ...process.env,
        CI: 'true',
        NEXT_TELEMETRY_DISABLED: '1',
        NODE_ENV: 'production'
      };
      
      // Test build command (dry run or quick validation)
      try {
        // Instead of running full build, we'll validate the build configuration
        this.log('Validating build configuration...');
        
        // Check if Next.js config exists and is valid
        const nextConfigPath = 'next.config.js';
        if (fs.existsSync(nextConfigPath)) {
          this.results.buildConsistency.details.push('next.config.js found');
          this.log('Next.js configuration found');
        }
        
        // Check if TypeScript config exists
        const tsConfigPath = 'tsconfig.json';
        if (fs.existsSync(tsConfigPath)) {
          const tsConfig = JSON.parse(fs.readFileSync(tsConfigPath, 'utf8'));
          this.results.buildConsistency.details.push('TypeScript configuration found');
          this.log('TypeScript configuration found');
        }
        
        // Check critical dependencies
        const criticalDeps = ['next', 'react', 'react-dom'];
        const missingDeps = criticalDeps.filter(dep => !packageJson.dependencies[dep]);
        
        if (missingDeps.length === 0) {
          this.results.buildConsistency.status = 'pass';
          this.results.buildConsistency.details.push('All critical dependencies present');
          this.results.buildConsistency.details.push('Build configuration appears valid');
          this.log('Build consistency check passed', 'success');
        } else {
          this.results.buildConsistency.status = 'fail';
          this.results.buildConsistency.details.push(`Missing dependencies: ${missingDeps.join(', ')}`);
          this.errors.push(`Missing critical dependencies: ${missingDeps.join(', ')}`);
          this.log(`Missing dependencies: ${missingDeps.join(', ')}`, 'error');
        }
        
      } catch (buildError) {
        this.results.buildConsistency.status = 'fail';
        this.results.buildConsistency.details.push(`Build validation failed: ${buildError.message}`);
        this.errors.push(`Build validation failed: ${buildError.message}`);
        this.log(`Build validation failed: ${buildError.message}`, 'error');
      }
      
    } catch (error) {
      this.results.buildConsistency.status = 'error';
      this.results.buildConsistency.details.push(`Error: ${error.message}`);
      this.errors.push(`Build consistency check failed: ${error.message}`);
      this.log(`Build consistency error: ${error.message}`, 'error');
    }
  }

  async testPackageEnginesConsistency() {
    this.log('Testing package engines consistency...', 'info');
    
    try {
      const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
      const engines = packageJson.engines;
      
      if (!engines) {
        this.results.packageEngines.status = 'fail';
        this.results.packageEngines.details.push('No engines field found in package.json');
        this.errors.push('package.json missing engines field');
        this.log('No engines field in package.json', 'error');
        return;
      }
      
      // Check Node.js engine requirement
      if (engines.node) {
        this.results.packageEngines.details.push(`Node.js requirement: ${engines.node}`);
        
        // Verify it matches expected requirement (>=22.19.0)
        if (engines.node === '>=22.19.0') {
          this.results.packageEngines.status = 'pass';
          this.results.packageEngines.details.push('Node.js engine requirement is correct');
          this.log('Node.js engine requirement is correct', 'success');
        } else {
          this.results.packageEngines.status = 'fail';
          this.results.packageEngines.details.push(`Expected >=22.19.0, found ${engines.node}`);
          this.errors.push(`Node.js engine requirement should be >=22.19.0, found ${engines.node}`);
          this.log(`Incorrect Node.js engine requirement: ${engines.node}`, 'error');
        }
      } else {
        this.results.packageEngines.status = 'fail';
        this.results.packageEngines.details.push('No Node.js engine requirement specified');
        this.errors.push('package.json missing Node.js engine requirement');
        this.log('No Node.js engine requirement specified', 'error');
      }
      
      // Check npm engine requirement
      if (engines.npm) {
        this.results.packageEngines.details.push(`npm requirement: ${engines.npm}`);
        
        if (engines.npm === '>=10.8.0') {
          this.results.packageEngines.details.push('npm engine requirement is correct');
          this.log('npm engine requirement is correct', 'success');
        } else {
          this.warnings.push(`npm engine requirement is ${engines.npm}, expected >=10.8.0`);
          this.log(`npm engine requirement: ${engines.npm}`, 'warning');
        }
      }
      
    } catch (error) {
      this.results.packageEngines.status = 'error';
      this.results.packageEngines.details.push(`Error: ${error.message}`);
      this.errors.push(`Package engines check failed: ${error.message}`);
      this.log(`Package engines error: ${error.message}`, 'error');
    }
  }

  generateReport() {
    const timestamp = new Date().toISOString();
    const report = {
      timestamp,
      summary: {
        totalTests: Object.keys(this.results).length,
        passed: Object.values(this.results).filter(r => r.status === 'pass').length,
        failed: Object.values(this.results).filter(r => r.status === 'fail').length,
        errors: Object.values(this.results).filter(r => r.status === 'error').length,
        warnings: this.warnings.length
      },
      results: this.results,
      errors: this.errors,
      warnings: this.warnings,
      recommendations: this.generateRecommendations()
    };
    
    return report;
  }

  generateRecommendations() {
    const recommendations = [];
    
    // Node version recommendations
    if (this.results.nodeVersion.status === 'fail') {
      recommendations.push({
        category: 'Node.js Version',
        priority: 'high',
        action: 'Upgrade Node.js to version 22.19.0 or higher',
        commands: [
          'Using nvm-windows: nvm install 22.19.0 && nvm use 22.19.0',
          'Using corepack: corepack enable && corepack prepare node@22.19.0',
          'Direct download: https://nodejs.org/dist/v22.19.0/'
        ]
      });
    }
    
    // Lockfile recommendations
    if (this.results.lockfileConsistency.status === 'fail') {
      recommendations.push({
        category: 'Lockfile Consistency',
        priority: 'medium',
        action: 'Fix package-lock.json consistency',
        commands: [
          'rm -rf node_modules package-lock.json',
          'npm install',
          'git add package-lock.json',
          'git commit -m "fix: update package-lock.json for Node 22.19.0 compatibility"'
        ]
      });
    }
    
    // Build recommendations
    if (this.results.buildConsistency.status === 'fail') {
      recommendations.push({
        category: 'Build Consistency',
        priority: 'high',
        action: 'Fix build configuration issues',
        commands: [
          'npm run build',
          'Check build logs for specific errors',
          'Ensure all dependencies are compatible with Node 22.19.0'
        ]
      });
    }
    
    return recommendations;
  }

  async run() {
    this.log('🚀 Starting Local-CI Environment Consistency Test', 'info');
    this.log('='.repeat(60));
    
    await this.testNodeVersionConsistency();
    await this.testPackageEnginesConsistency();
    await this.testLockfileConsistency();
    await this.testBuildConsistency();
    
    const report = this.generateReport();
    
    // Save report
    const reportPath = `local-ci-consistency-report-${Date.now()}.json`;
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    
    // Display summary
    this.log('='.repeat(60));
    this.log('📊 Test Summary', 'info');
    this.log(`Total Tests: ${report.summary.totalTests}`);
    this.log(`Passed: ${report.summary.passed}`, 'success');
    this.log(`Failed: ${report.summary.failed}`, report.summary.failed > 0 ? 'error' : 'info');
    this.log(`Errors: ${report.summary.errors}`, report.summary.errors > 0 ? 'error' : 'info');
    this.log(`Warnings: ${report.summary.warnings}`, report.summary.warnings > 0 ? 'warning' : 'info');
    
    if (this.errors.length > 0) {
      this.log('\n❌ Critical Issues Found:', 'error');
      this.errors.forEach(error => this.log(`  • ${error}`, 'error'));
    }
    
    if (this.warnings.length > 0) {
      this.log('\n⚠️ Warnings:', 'warning');
      this.warnings.forEach(warning => this.log(`  • ${warning}`, 'warning'));
    }
    
    if (report.recommendations.length > 0) {
      this.log('\n💡 Recommendations:', 'info');
      report.recommendations.forEach(rec => {
        this.log(`\n${rec.category} (${rec.priority} priority):`, 'info');
        this.log(`  Action: ${rec.action}`);
        if (rec.commands) {
          this.log('  Commands:');
          rec.commands.forEach(cmd => this.log(`    ${cmd}`));
        }
      });
    }
    
    this.log(`\n📄 Full report saved to: ${reportPath}`);
    
    // Exit with appropriate code
    const hasFailures = report.summary.failed > 0 || report.summary.errors > 0;
    if (hasFailures) {
      this.log('\n❌ Local-CI consistency test FAILED', 'error');
      process.exit(1);
    } else {
      this.log('\n✅ Local-CI consistency test PASSED', 'success');
      process.exit(0);
    }
  }
}

// Run the test if called directly
if (require.main === module) {
  const tester = new LocalCIConsistencyTester();
  tester.run().catch(error => {
    console.error('❌ Test runner failed:', error);
    process.exit(1);
  });
}

module.exports = LocalCIConsistencyTester;