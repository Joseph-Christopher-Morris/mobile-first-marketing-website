#!/usr/bin/env node

/**
 * Test CloudFront Pretty URLs Monitoring Integration
 * 
 * Tests the integration of CloudFront pretty URLs alarms with existing monitoring systems
 */

const fs = require('fs').promises;
const path = require('path');

class MonitoringIntegrationTest {
    constructor() {
        this.testResults = {
            timestamp: new Date().toISOString(),
            tests: [],
            summary: {
                total: 0,
                passed: 0,
                failed: 0,
                skipped: 0
            }
        };
    }

    async runTest(testName, testFunction) {
        console.log(`🧪 Running test: ${testName}`);
        this.testResults.summary.total++;
        
        try {
            const result = await testFunction();
            this.testResults.tests.push({
                name: testName,
                status: 'PASSED',
                result: result,
                timestamp: new Date().toISOString()
            });
            this.testResults.summary.passed++;
            console.log(`   ✅ PASSED: ${testName}`);
            return result;
        } catch (error) {
            this.testResults.tests.push({
                name: testName,
                status: 'FAILED',
                error: error.message,
                timestamp: new Date().toISOString()
            });
            this.testResults.summary.failed++;
            console.log(`   ❌ FAILED: ${testName} - ${error.message}`);
            return null;
        }
    }

    async testConfigurationExists() {
        const configPath = path.join(__dirname, '..', 'config', 'cloudfront-pretty-urls-monitoring-config.json');
        const configExists = await fs.access(configPath).then(() => true).catch(() => false);
        
        if (!configExists) {
            throw new Error('Monitoring configuration file not found');
        }

        const configData = await fs.readFile(configPath, 'utf8');
        const config = JSON.parse(configData);
        
        if (!config.monitoring || !config.dashboard || !config.metrics) {
            throw new Error('Configuration missing required sections');
        }

        return {
            configExists: true,
            hasMonitoring: !!config.monitoring,
            hasDashboard: !!config.dashboard,
            hasMetrics: !!config.metrics,
            hasThresholds: !!config.thresholds
        };
    }

    async testIntegrationScriptExists() {
        const scriptPath = path.join(__dirname, 'integrate-pretty-urls-monitoring-systems.js');
        const scriptExists = await fs.access(scriptPath).then(() => true).catch(() => false);
        
        if (!scriptExists) {
            throw new Error('Integration script not found');
        }

        const scriptContent = await fs.readFile(scriptPath, 'utf8');
        
        // Check for key integration functions
        const hasDiscoveryFunction = scriptContent.includes('discoverExistingMonitoring');
        const hasWidgetIntegration = scriptContent.includes('addAlarmWidgetsToExistingDashboards');
        const hasCompositeAlarms = scriptContent.includes('createCompositeAlarms');
        
        return {
            scriptExists: true,
            hasDiscoveryFunction,
            hasWidgetIntegration,
            hasCompositeAlarms,
            scriptSize: scriptContent.length
        };
    }

    async testExistingMonitoringScripts() {
        const monitoringScripts = [
            'setup-cloudwatch-monitoring.js',
            'performance-monitoring-dashboard.js',
            'cloudfront-pretty-urls-alerting-integration.js'
        ];

        const results = {};
        
        for (const script of monitoringScripts) {
            const scriptPath = path.join(__dirname, script);
            const exists = await fs.access(scriptPath).then(() => true).catch(() => false);
            results[script] = exists;
        }

        const existingCount = Object.values(results).filter(Boolean).length;
        
        if (existingCount === 0) {
            throw new Error('No existing monitoring scripts found');
        }

        return {
            scriptsFound: existingCount,
            totalScripts: monitoringScripts.length,
            scripts: results
        };
    }

    async testDashboardIntegrationCapability() {
        // Test if we can simulate dashboard integration
        const mockDashboard = {
            widgets: [
                {
                    type: "metric",
                    x: 0, y: 0, width: 12, height: 6,
                    properties: {
                        title: "Existing Widget",
                        metrics: [["AWS/CloudFront", "Requests"]]
                    }
                }
            ]
        };

        // Simulate adding alarm widgets
        const alarmWidget = {
            type: "metric",
            x: 0, y: 6, width: 24, height: 6,
            properties: {
                title: "🚨 Pretty URLs Alarms Status",
                metrics: [["AWS/CloudWatch", "AlarmState", "AlarmName", "CloudFront-PrettyURLs-Test"]]
            }
        };

        mockDashboard.widgets.push(alarmWidget);

        const hasAlarmWidget = mockDashboard.widgets.some(widget => 
            widget.properties.title.includes('Pretty URLs Alarms')
        );

        if (!hasAlarmWidget) {
            throw new Error('Failed to add alarm widget to dashboard');
        }

        return {
            originalWidgets: 1,
            finalWidgets: mockDashboard.widgets.length,
            alarmWidgetAdded: hasAlarmWidget
        };
    }

    async testCompositeAlarmConfiguration() {
        // Test composite alarm rule building
        const mockAlarms = [
            { AlarmName: 'CloudFront-PrettyURLs-Function-Errors-Critical' },
            { AlarmName: 'CloudFront-PrettyURLs-5xx-ErrorRate-Critical' },
            { AlarmName: 'CloudFront-PrettyURLs-Accessibility-Critical' }
        ];

        const criticalAlarms = mockAlarms
            .filter(alarm => alarm.AlarmName.includes('Critical'))
            .map(alarm => `ALARM("${alarm.AlarmName}")`)
            .join(' OR ');

        const alarmRule = `(${criticalAlarms})`;

        if (!alarmRule.includes('ALARM(') || !alarmRule.includes('OR')) {
            throw new Error('Failed to build composite alarm rule');
        }

        return {
            inputAlarms: mockAlarms.length,
            criticalAlarms: mockAlarms.filter(a => a.AlarmName.includes('Critical')).length,
            alarmRule: alarmRule,
            ruleValid: alarmRule.length > 10
        };
    }

    async testPerformanceCorrelationDashboard() {
        // Test performance correlation dashboard structure
        const correlationDashboard = {
            widgets: [
                {
                    type: "text",
                    properties: {
                        markdown: "# Performance Correlation Dashboard"
                    }
                },
                {
                    type: "metric",
                    properties: {
                        title: "Function Performance vs Origin Latency",
                        metrics: [
                            ["AWS/CloudFront", "FunctionExecutionTime", "FunctionName", "pretty-urls-rewriter"],
                            [".", "OriginLatency", "DistributionId", "E2IBMHQ3GCW6ZK"]
                        ]
                    }
                }
            ]
        };

        const hasTextWidget = correlationDashboard.widgets.some(w => w.type === 'text');
        const hasMetricWidget = correlationDashboard.widgets.some(w => w.type === 'metric');
        const hasCorrelationMetrics = correlationDashboard.widgets.some(w => 
            w.properties.metrics && w.properties.metrics.length >= 2
        );

        if (!hasTextWidget || !hasMetricWidget || !hasCorrelationMetrics) {
            throw new Error('Performance correlation dashboard structure invalid');
        }

        return {
            totalWidgets: correlationDashboard.widgets.length,
            hasTextWidget,
            hasMetricWidget,
            hasCorrelationMetrics
        };
    }

    async runAllTests() {
        console.log('🚀 Starting CloudFront Pretty URLs Monitoring Integration Tests\n');

        await this.runTest('Configuration File Exists', () => this.testConfigurationExists());
        await this.runTest('Integration Script Exists', () => this.testIntegrationScriptExists());
        await this.runTest('Existing Monitoring Scripts', () => this.testExistingMonitoringScripts());
        await this.runTest('Dashboard Integration Capability', () => this.testDashboardIntegrationCapability());
        await this.runTest('Composite Alarm Configuration', () => this.testCompositeAlarmConfiguration());
        await this.runTest('Performance Correlation Dashboard', () => this.testPerformanceCorrelationDashboard());

        // Generate test report
        await this.generateTestReport();

        console.log('\n📊 Test Summary:');
        console.log(`   Total Tests: ${this.testResults.summary.total}`);
        console.log(`   Passed: ${this.testResults.summary.passed}`);
        console.log(`   Failed: ${this.testResults.summary.failed}`);
        console.log(`   Success Rate: ${((this.testResults.summary.passed / this.testResults.summary.total) * 100).toFixed(1)}%`);

        if (this.testResults.summary.failed > 0) {
            console.log('\n❌ Failed Tests:');
            this.testResults.tests
                .filter(test => test.status === 'FAILED')
                .forEach(test => {
                    console.log(`   - ${test.name}: ${test.error}`);
                });
        }

        return this.testResults;
    }

    async generateTestReport() {
        const reportPath = path.join(__dirname, '..', 'logs', `monitoring-integration-test-${Date.now()}.json`);
        
        try {
            await fs.mkdir(path.dirname(reportPath), { recursive: true });
            await fs.writeFile(reportPath, JSON.stringify(this.testResults, null, 2));
            console.log(`\n📋 Test report saved: ${reportPath}`);
        } catch (error) {
            console.warn(`⚠️  Could not save test report: ${error.message}`);
        }
    }
}

// Run tests if called directly
if (require.main === module) {
    const tester = new MonitoringIntegrationTest();
    tester.runAllTests()
        .then(results => {
            const success = results.summary.failed === 0;
            process.exit(success ? 0 : 1);
        })
        .catch(error => {
            console.error('❌ Test execution failed:', error);
            process.exit(1);
        });
}

module.exports = MonitoringIntegrationTest;