#!/usr/bin/env node

/**
 * Test script to verify URL validation logic without making actual HTTP requests
 */

const URLValidator = require('./validate-pretty-urls');

// Mock the makeRequest method for testing
class TestURLValidator extends URLValidator {
    async makeRequest(url) {
        // Mock responses based on URL patterns
        const mockResponses = {
            '/': {
                statusCode: 200,
                headers: { 'content-type': 'text/html; charset=utf-8' },
                body: '<html><head><title>Home</title></head><body>Welcome</body></html>',
                url: 'https://d15sc9fc739ev2.cloudfront.net/'
            },
            '/privacy-policy/': {
                statusCode: 200,
                headers: { 'content-type': 'text/html; charset=utf-8' },
                body: '<html><head><title>Privacy Policy</title></head><body>Privacy policy content</body></html>',
                url: 'https://d15sc9fc739ev2.cloudfront.net/privacy-policy/'
            },
            '/about/': {
                statusCode: 200,
                headers: { 'content-type': 'text/html; charset=utf-8' },
                body: '<html><head><title>About</title></head><body>About content</body></html>',
                url: 'https://d15sc9fc739ev2.cloudfront.net/about/'
            },
            '/favicon.ico': {
                statusCode: 200,
                headers: { 'content-type': 'image/x-icon' },
                body: 'binary-favicon-data',
                url: 'https://d15sc9fc739ev2.cloudfront.net/favicon.ico'
            },
            '/robots.txt': {
                statusCode: 200,
                headers: { 'content-type': 'text/plain' },
                body: 'User-agent: *\nDisallow:',
                url: 'https://d15sc9fc739ev2.cloudfront.net/robots.txt'
            }
        };

        // Return mock response or default
        return mockResponses[url] || {
            statusCode: 200,
            headers: { 'content-type': 'text/html; charset=utf-8' },
            body: '<html><head><title>Test Page</title></head><body>Test content</body></html>',
            url: `https://d15sc9fc739ev2.cloudfront.net${url}`
        };
    }
}

async function testValidationLogic() {
    console.log('Testing URL validation logic...\n');
    
    const validator = new TestURLValidator();
    
    // Test a few key test cases
    const testCases = [
        {
            url: '/',
            expectedStatus: 200,
            expectedContentType: 'text/html',
            description: 'Root URL serves index.html',
            mustContain: ['<html', '<head', '<body']
        },
        {
            url: '/privacy-policy/',
            expectedStatus: 200,
            expectedContentType: 'text/html',
            description: 'Directory URL serves correct index.html',
            mustContain: ['<html', 'privacy', 'policy']
        },
        {
            url: '/favicon.ico',
            expectedStatus: 200,
            expectedContentType: 'image/x-icon',
            description: 'Static assets are not affected by URL rewriting'
        }
    ];

    let passed = 0;
    let failed = 0;

    for (const testCase of testCases) {
        try {
            const response = await validator.makeRequest(testCase.url);
            const validation = validator.validateResponse(testCase, response);
            
            if (validation.errors.length === 0) {
                console.log(`✅ PASS: ${testCase.description}`);
                passed++;
            } else {
                console.log(`❌ FAIL: ${testCase.description}`);
                validation.errors.forEach(error => console.log(`   Error: ${error}`));
                failed++;
            }
        } catch (error) {
            console.log(`💥 ERROR: ${testCase.description} - ${error.message}`);
            failed++;
        }
    }

    console.log(`\nTest Results: ${passed} passed, ${failed} failed`);
    return failed === 0;
}

// Run the test
if (require.main === module) {
    testValidationLogic().then(success => {
        console.log(success ? '\n🎉 All validation logic tests passed!' : '\n❌ Some tests failed');
        process.exit(success ? 0 : 1);
    });
}

module.exports = { TestURLValidator, testValidationLogic };