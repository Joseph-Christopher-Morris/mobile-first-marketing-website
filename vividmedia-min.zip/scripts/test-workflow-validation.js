#!/usr/bin/env node

/**
 * GitHub Actions Workflow Validation Tests
 * 
 * Validates the quality-check.yml workflow configuration
 * to ensure it meets CI requirements.
 * 
 * Requirements: 5.1, 5.2, 5.3
 */

const fs = require('fs');

class WorkflowValidationTests {
  constructor() {
    this.workflowPath = '.github/workflows/quality-check.yml';
    this.results = {
      tests: [],
      passed: 0,
      failed: 0,
      warnings: []
    };
  }

  /**
   * Run all workflow validation tests
   */
  runTests() {
    console.log('🔍 Running GitHub Actions Workflow Validation Tests');
    console.log('=' .repeat(50));

    try {
      // Load and parse workflow
      const workflow = this.loadWorkflow();
      
      // Run validation tests
      this.validateWorkflowStructure(workflow);
      this.validateNodeJsConfiguration(workflow);
      this.validateWorkflowSteps(workflow);
      this.validateEnvironmentConfiguration(workflow);
      this.validateCacheConfiguration(workflow);
      this.validateTriggerConfiguration(workflow);
      
      // Generate report
      this.generateReport();
      
    } catch (error) {
      console.error('❌ Workflow validation failed:', error.message);
      process.exit(1);
    }
  }

  /**
   * Load and parse workflow YAML
   */
  loadWorkflow() {
    this.test('Workflow file exists', () => {
      if (!fs.existsSync(this.workflowPath)) {
        throw new Error(`Workflow file not found: ${this.workflowPath}`);
      }
    });

    let workflow;
    this.test('Workflow YAML is valid', () => {
      const content = fs.readFileSync(this.workflowPath, 'utf8');
      
      // Simple YAML parsing for workflow validation
      // This is a basic parser for the specific workflow structure we need
      try {
        workflow = this.parseWorkflowYAML(content);
        
        if (!workflow || typeof workflow !== 'object') {
          throw new Error('Invalid workflow YAML structure');
        }
      } catch (error) {
        throw new Error(`Failed to parse workflow YAML: ${error.message}`);
      }
    });

    return workflow;
  }

  /**
   * Validate basic workflow structure
   */
  validateWorkflowStructure(workflow) {
    this.test('Workflow has name', () => {
      if (!workflow.name) {
        throw new Error('Workflow should have a name');
      }
    });

    this.test('Workflow has jobs', () => {
      if (!workflow.jobs || typeof workflow.jobs !== 'object') {
        throw new Error('Workflow should have jobs defined');
      }
    });

    this.test('Quality check job exists', () => {
      if (!workflow.jobs['quality-check']) {
        throw new Error('Workflow should have a quality-check job');
      }
    });

    this.test('Job runs on ubuntu-latest', () => {
      const job = workflow.jobs['quality-check'];
      if (!job['runs-on'] || job['runs-on'] !== 'ubuntu-latest') {
        throw new Error('Job should run on ubuntu-latest');
      }
    });
  }

  /**
   * Validate Node.js configuration
   */
  validateNodeJsConfiguration(workflow) {
    const setupNodeStep = this.findStep(workflow, 'Setup Node.js');
    
    this.test('Setup Node.js step exists', () => {
      if (!setupNodeStep) {
        throw new Error('Setup Node.js step not found');
      }
    });

    this.test('Node.js version is 22.19.0', () => {
      if (!setupNodeStep.with || setupNodeStep.with['node-version'] !== '22.19.0') {
        throw new Error('Node.js version should be 22.19.0');
      }
    });

    this.test('Uses official setup-node action', () => {
      if (!setupNodeStep.uses || !setupNodeStep.uses.startsWith('actions/setup-node@')) {
        throw new Error('Should use official actions/setup-node action');
      }
    });
  }

  /**
   * Validate workflow steps
   */
  validateWorkflowSteps(workflow) {
    const requiredSteps = [
      { name: 'Checkout repository', action: 'actions/checkout@' },
      { name: 'Setup Node.js', action: 'actions/setup-node@' },
      { name: 'Install dependencies', command: 'npm ci' },
      { name: 'Verify lockfile consistency', command: 'git diff' },
      { name: 'Build project', command: 'npm run build' }
    ];

    requiredSteps.forEach(({ name, action, command }) => {
      this.test(`Required step: ${name}`, () => {
        const step = this.findStep(workflow, name);
        if (!step) {
          throw new Error(`Required step not found: ${name}`);
        }

        if (action && (!step.uses || !step.uses.startsWith(action))) {
          throw new Error(`Step should use ${action} action`);
        }

        if (command && (!step.run || !step.run.includes(command))) {
          throw new Error(`Step should include ${command} command`);
        }
      });
    });

    // Validate conditional execution
    this.test('Type check step has conditional execution', () => {
      const typeCheckStep = this.findStep(workflow, 'type check');
      if (typeCheckStep && !typeCheckStep.if) {
        this.addWarning('Type check step should have conditional execution');
      }
    });

    this.test('Lint step has conditional execution', () => {
      const lintStep = this.findStep(workflow, 'lint');
      if (lintStep && !lintStep.if) {
        this.addWarning('Lint step should have conditional execution');
      }
    });
  }

  /**
   * Validate environment configuration
   */
  validateEnvironmentConfiguration(workflow) {
    const buildStep = this.findStep(workflow, 'Build project');
    
    this.test('Build step has environment variables', () => {
      if (!buildStep || !buildStep.env) {
        throw new Error('Build step should have environment variables');
      }
    });

    const requiredEnvVars = {
      'CI': 'true',
      'NEXT_TELEMETRY_DISABLED': '1'
    };

    Object.entries(requiredEnvVars).forEach(([key, expectedValue]) => {
      this.test(`Environment variable ${key} is set correctly`, () => {
        if (!buildStep.env[key]) {
          throw new Error(`Environment variable ${key} is missing`);
        }
        
        if (buildStep.env[key] !== expectedValue) {
          throw new Error(`Environment variable ${key} should be ${expectedValue}`);
        }
      });
    });
  }

  /**
   * Validate cache configuration
   */
  validateCacheConfiguration(workflow) {
    const setupNodeStep = this.findStep(workflow, 'Setup Node.js');
    
    this.test('npm cache is configured', () => {
      if (!setupNodeStep.with || setupNodeStep.with.cache !== 'npm') {
        throw new Error('npm cache should be configured in Setup Node.js step');
      }
    });

    this.test('Cache dependency path is specified', () => {
      if (setupNodeStep.with['cache-dependency-path']) {
        const cachePath = setupNodeStep.with['cache-dependency-path'];
        if (cachePath !== 'package-lock.json') {
          this.addWarning(`Cache dependency path is ${cachePath}, consider using package-lock.json`);
        }
      }
    });
  }

  /**
   * Validate trigger configuration
   */
  validateTriggerConfiguration(workflow) {
    this.test('Workflow has triggers defined', () => {
      if (!workflow.on) {
        throw new Error('Workflow should have triggers defined');
      }
    });

    this.test('Push trigger is configured', () => {
      const triggers = workflow.on;
      const hasPushTrigger = triggers.push || 
                           (Array.isArray(triggers) && triggers.includes('push')) ||
                           (typeof triggers === 'string' && triggers === 'push');
      
      if (!hasPushTrigger) {
        throw new Error('Workflow should have push trigger');
      }
    });

    // Check for main branch restriction
    if (workflow.on.push && workflow.on.push.branches) {
      this.test('Push trigger targets main branch', () => {
        const branches = workflow.on.push.branches;
        if (!branches.includes('main') && !branches.includes('master')) {
          this.addWarning('Consider restricting push trigger to main/master branch');
        }
      });
    }
  }

  /**
   * Simple YAML parser for GitHub Actions workflow
   * This is a basic parser that handles the specific structure we need
   */
  parseWorkflowYAML(content) {
    const lines = content.split('\n');
    const result = {};
    let currentPath = [];
    let currentIndent = 0;
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();
      
      // Skip empty lines and comments
      if (!trimmed || trimmed.startsWith('#')) {
        continue;
      }
      
      // Calculate indentation
      const indent = line.length - line.trimStart().length;
      
      // Handle key-value pairs
      if (trimmed.includes(':')) {
        const [key, ...valueParts] = trimmed.split(':');
        const value = valueParts.join(':').trim();
        
        // Adjust path based on indentation
        if (indent <= currentIndent) {
          // Same level or going back
          const levels = Math.floor((currentIndent - indent) / 2) + 1;
          currentPath = currentPath.slice(0, -levels);
        }
        
        currentPath.push(key.trim());
        currentIndent = indent;
        
        // Set value in result object
        let current = result;
        for (let j = 0; j < currentPath.length - 1; j++) {
          const pathKey = currentPath[j];
          if (!current[pathKey]) {
            current[pathKey] = {};
          }
          current = current[pathKey];
        }
        
        const finalKey = currentPath[currentPath.length - 1];
        
        if (value) {
          // Handle different value types
          if (value.startsWith('"') && value.endsWith('"')) {
            current[finalKey] = value.slice(1, -1); // Remove quotes
          } else if (value.startsWith("'") && value.endsWith("'")) {
            current[finalKey] = value.slice(1, -1); // Remove quotes
          } else if (value === 'true') {
            current[finalKey] = true;
          } else if (value === 'false') {
            current[finalKey] = false;
          } else if (!isNaN(value)) {
            current[finalKey] = Number(value);
          } else {
            current[finalKey] = value;
          }
        } else {
          current[finalKey] = {};
        }
      }
      // Handle array items
      else if (trimmed.startsWith('- ')) {
        const value = trimmed.slice(2).trim();
        
        // Get parent object
        let current = result;
        for (let j = 0; j < currentPath.length; j++) {
          current = current[currentPath[j]];
        }
        
        // Initialize array if needed
        if (!Array.isArray(current)) {
          // Convert object to array if it has numeric keys
          const keys = Object.keys(current);
          if (keys.length === 0) {
            // Replace empty object with array
            let parent = result;
            for (let j = 0; j < currentPath.length - 1; j++) {
              parent = parent[currentPath[j]];
            }
            parent[currentPath[currentPath.length - 1]] = [];
            current = parent[currentPath[currentPath.length - 1]];
          }
        }
        
        if (Array.isArray(current)) {
          if (value.includes(':')) {
            // Object in array
            const obj = {};
            const [key, ...valueParts] = value.split(':');
            const objValue = valueParts.join(':').trim();
            obj[key.trim()] = objValue || {};
            current.push(obj);
          } else {
            current.push(value);
          }
        }
      }
    }
    
    return result;
  }

  /**
   * Find workflow step by name (case-insensitive partial match)
   */
  findStep(workflow, stepName) {
    const job = workflow.jobs && workflow.jobs['quality-check'];
    if (!job || !job.steps) {
      return null;
    }

    return job.steps.find(step => 
      step.name && step.name.toLowerCase().includes(stepName.toLowerCase())
    );
  }

  /**
   * Run individual test
   */
  test(testName, testFunction) {
    try {
      testFunction();
      console.log(`  ✅ ${testName}`);
      this.results.tests.push({ name: testName, status: 'passed' });
      this.results.passed++;
    } catch (error) {
      console.log(`  ❌ ${testName}: ${error.message}`);
      this.results.tests.push({ name: testName, status: 'failed', error: error.message });
      this.results.failed++;
    }
  }

  /**
   * Add warning
   */
  addWarning(message) {
    console.log(`  ⚠️  Warning: ${message}`);
    this.results.warnings.push(message);
  }

  /**
   * Generate test report
   */
  generateReport() {
    console.log('\n' + '='.repeat(50));
    console.log('📊 Workflow Validation Results');
    console.log('='.repeat(50));
    
    console.log(`\nTests: ${this.results.passed + this.results.failed}`);
    console.log(`Passed: ${this.results.passed}`);
    console.log(`Failed: ${this.results.failed}`);
    console.log(`Warnings: ${this.results.warnings.length}`);

    if (this.results.warnings.length > 0) {
      console.log('\n⚠️  Warnings:');
      this.results.warnings.forEach(warning => {
        console.log(`  - ${warning}`);
      });
    }

    // Save detailed report
    const reportPath = `workflow-validation-report-${Date.now()}.json`;
    fs.writeFileSync(reportPath, JSON.stringify(this.results, null, 2));
    console.log(`\n📄 Detailed report saved: ${reportPath}`);

    if (this.results.failed > 0) {
      console.log('\n❌ Workflow validation failed. Please fix the issues above.');
      process.exit(1);
    } else {
      console.log('\n✅ Workflow validation passed!');
    }
  }
}

// Run tests if called directly
if (require.main === module) {
  const validator = new WorkflowValidationTests();
  validator.runTests();
}

module.exports = WorkflowValidationTests;