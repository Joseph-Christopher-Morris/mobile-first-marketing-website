#!/usr/bin/env node

/**
 * Formspree Integration Test Script
 * 
 * Tests the Formspree integration for contact form and newsletter signup
 */

const https = require('https');

const FORMSPREE_ENDPOINT = 'https://formspree.io/f/xovkngyr';

class FormspreeIntegrationTester {
  constructor() {
    this.results = {
      contactForm: { status: 'pending', details: [] },
      newsletter: { status: 'pending', details: [] },
      overallStatus: 'pending'
    };
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const prefix = type === 'error' ? '❌' : type === 'success' ? '✅' : 'ℹ️';
    console.log(`${prefix} [${timestamp}] ${message}`);
  }

  async makeFormspreeRequest(data) {
    return new Promise((resolve, reject) => {
      const postData = JSON.stringify(data);
      
      const options = {
        hostname: 'formspree.io',
        port: 443,
        path: '/f/xovkngyr',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData),
          'User-Agent': 'Formspree-Integration-Test/1.0'
        }
      };

      const req = https.request(options, (res) => {
        let responseData = '';
        
        res.on('data', (chunk) => {
          responseData += chunk;
        });
        
        res.on('end', () => {
          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            body: responseData
          });
        });
      });

      req.on('error', (error) => {
        reject(error);
      });

      req.write(postData);
      req.end();
    });
  }

  async testContactForm() {
    this.log('Testing contact form integration...');
    
    try {
      const testData = {
        name: 'Test User',
        email: 'test@example.com',
        phone: '+44 123 456 7890',
        service: 'photography',
        message: 'This is a test message from the Formspree integration test.',
        _subject: 'Test Contact Form Submission',
        _replyto: 'test@example.com'
      };

      const response = await this.makeFormspreeRequest(testData);
      
      if (response.statusCode === 200 || response.statusCode === 302) {
        this.results.contactForm.status = 'success';
        this.results.contactForm.details.push('✅ Contact form submission successful');
        this.results.contactForm.details.push(`HTTP Status: ${response.statusCode}`);
        this.log('Contact form integration test passed', 'success');
      } else if (response.statusCode === 422) {
        this.results.contactForm.status = 'warning';
        this.results.contactForm.details.push('⚠️ Form validation error (expected for test data)');
        this.results.contactForm.details.push(`HTTP Status: ${response.statusCode}`);
        this.log('Contact form validation working (test data rejected as expected)', 'success');
      } else {
        this.results.contactForm.status = 'error';
        this.results.contactForm.details.push(`❌ Unexpected status code: ${response.statusCode}`);
        this.log(`Contact form test failed with status ${response.statusCode}`, 'error');
      }
      
    } catch (error) {
      this.results.contactForm.status = 'error';
      this.results.contactForm.details.push(`❌ Request error: ${error.message}`);
      this.log(`Contact form test error: ${error.message}`, 'error');
    }
  }

  async testNewsletter() {
    this.log('Testing newsletter signup integration...');
    
    try {
      const testData = {
        email: 'newsletter-test@example.com',
        _subject: 'Test Newsletter Subscription',
        message: 'Newsletter subscription test',
        type: 'newsletter'
      };

      const response = await this.makeFormspreeRequest(testData);
      
      if (response.statusCode === 200 || response.statusCode === 302) {
        this.results.newsletter.status = 'success';
        this.results.newsletter.details.push('✅ Newsletter signup submission successful');
        this.results.newsletter.details.push(`HTTP Status: ${response.statusCode}`);
        this.log('Newsletter integration test passed', 'success');
      } else if (response.statusCode === 422) {
        this.results.newsletter.status = 'warning';
        this.results.newsletter.details.push('⚠️ Form validation error (expected for test data)');
        this.results.newsletter.details.push(`HTTP Status: ${response.statusCode}`);
        this.log('Newsletter validation working (test data rejected as expected)', 'success');
      } else {
        this.results.newsletter.status = 'error';
        this.results.newsletter.details.push(`❌ Unexpected status code: ${response.statusCode}`);
        this.log(`Newsletter test failed with status ${response.statusCode}`, 'error');
      }
      
    } catch (error) {
      this.results.newsletter.status = 'error';
      this.results.newsletter.details.push(`❌ Request error: ${error.message}`);
      this.log(`Newsletter test error: ${error.message}`, 'error');
    }
  }

  generateReport() {
    const timestamp = new Date().toISOString();
    
    // Determine overall status
    const statuses = [this.results.contactForm.status, this.results.newsletter.status];
    if (statuses.includes('error')) {
      this.results.overallStatus = 'error';
    } else if (statuses.includes('warning')) {
      this.results.overallStatus = 'warning';
    } else if (statuses.every(s => s === 'success')) {
      this.results.overallStatus = 'success';
    }

    const report = {
      timestamp,
      testType: 'Formspree Integration Test',
      endpoint: FORMSPREE_ENDPOINT,
      results: this.results,
      summary: {
        overallStatus: this.results.overallStatus,
        testsRun: 2,
        successCount: statuses.filter(s => s === 'success').length,
        warningCount: statuses.filter(s => s === 'warning').length,
        errorCount: statuses.filter(s => s === 'error').length
      }
    };

    // Write report
    const fs = require('fs');
    const reportPath = `formspree-integration-test-${Date.now()}.json`;
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    
    this.log(`Test report saved to: ${reportPath}`);
    
    return report;
  }

  async runAllTests() {
    this.log('Starting Formspree Integration Tests...');
    this.log('='.repeat(60));
    
    await this.testContactForm();
    await this.testNewsletter();
    
    this.log('='.repeat(60));
    const report = this.generateReport();
    
    this.log(`Tests completed with status: ${report.summary.overallStatus.toUpperCase()}`);
    
    // Print summary
    console.log('\n📊 Test Summary:');
    console.log(`- Contact Form: ${this.results.contactForm.status.toUpperCase()}`);
    console.log(`- Newsletter: ${this.results.newsletter.status.toUpperCase()}`);
    console.log(`- Overall: ${this.results.overallStatus.toUpperCase()}`);
    
    // Exit with appropriate code
    if (report.summary.overallStatus === 'error') {
      process.exit(1);
    } else {
      process.exit(0);
    }
  }
}

// Run tests if called directly
if (require.main === module) {
  const tester = new FormspreeIntegrationTester();
  tester.runAllTests().catch(error => {
    console.error('❌ Test suite failed:', error);
    process.exit(1);
  });
}

module.exports = FormspreeIntegrationTester;