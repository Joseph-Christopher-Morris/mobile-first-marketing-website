#!/usr/bin/env pwsh
# Microsoft Clarity Session Fix Deployment
# Ensures Clarity sessions are properly tracked and visible

Write-Host "🔧 Microsoft Clarity Session Fix Deployment" -ForegroundColor Cyan
Write-Host "=" * 60

# Step 1: Validate implementation
Write-Host "`n📋 Step 1: Validating Clarity Implementation..." -ForegroundColor Yellow
node scripts/test-clarity-implementation.js
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Implementation validation failed!" -ForegroundColor Red
    exit 1
}

# Step 2: Build the site
Write-Host "`n🏗️  Step 2: Building site..." -ForegroundColor Yellow
npm run build
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Build failed!" -ForegroundColor Red
    exit 1
}

# Step 3: Deploy to S3
Write-Host "`n☁️  Step 3: Deploying to S3..." -ForegroundColor Yellow
$env:S3_BUCKET_NAME = "mobile-marketing-site-prod-1759705011281-tyzuo9"
$env:CLOUDFRONT_DISTRIBUTION_ID = "E2IBMHQ3GCW6ZK"
$env:AWS_REGION = "us-east-1"

node scripts/deploy.js
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Deployment failed!" -ForegroundColor Red
    exit 1
}

# Step 4: Invalidate CloudFront cache
Write-Host "`n🔄 Step 4: Invalidating CloudFront cache..." -ForegroundColor Yellow
aws cloudfront create-invalidation `
    --distribution-id E2IBMHQ3GCW6ZK `
    --paths "/*" `
    --region us-east-1

Write-Host "`n✅ Deployment Complete!" -ForegroundColor Green
Write-Host "`n📊 Next Steps:" -ForegroundColor Cyan
Write-Host "1. Wait 2-3 minutes for CloudFront invalidation"
Write-Host "2. Visit your site and accept cookies"
Write-Host "3. Navigate between pages and interact"
Write-Host "4. Check Clarity dashboard in 5-10 minutes:"
Write-Host "   https://clarity.microsoft.com/projects/view/u4yftkmpxx/dashboard"
Write-Host "`n💡 Tip: Sessions may take up to 10 minutes to appear in Clarity"
