# PowerShell Script for CloudFront Cache Invalidation
# 
# Implements the vivid-auto-scram-rebuild invalidation strategy:
# - Invalidation paths: /, /index.html, /services/*, /blog*, /images/*, /sitemap.xml, /_next/*
# - Verifies proper cache headers are applied after deployment
#
# Requirements addressed:
# - 8.3: Configure invalidation for specified paths
# - 8.5: Verify proper cache headers and test cache behavior

param(
    [string]$DistributionId = $env:CLOUDFRONT_DISTRIBUTION_ID,
    [string]$CloudFrontDomain = $env:CLOUDFRONT_DOMAIN_NAME
)

# Configuration
if (-not $DistributionId) {
    $DistributionId = "E2IBMHQ3GCW6ZK"
}

if (-not $CloudFrontDomain) {
    $CloudFrontDomain = "d15sc9fc739ev2.cloudfront.net"
}

# Specific invalidation paths as per requirements
$InvalidationPaths = @(
    "/",
    "/index.html", 
    "/services/*",
    "/blog*",
    "/images/*",
    "/sitemap.xml",
    "/_next/*"
)

Write-Host "🔄 CloudFront Cache Invalidation" -ForegroundColor Green
Write-Host "   Distribution ID: $DistributionId" -ForegroundColor Cyan
Write-Host "   CloudFront Domain: $CloudFrontDomain" -ForegroundColor Cyan
Write-Host "   Invalidation Paths: $($InvalidationPaths.Count)" -ForegroundColor Cyan
Write-Host ""

# Step 1: Create CloudFront invalidation
Write-Host "🚀 Creating CloudFront invalidation..." -ForegroundColor Blue

Write-Host "📋 Invalidation paths:" -ForegroundColor Yellow
foreach ($path in $InvalidationPaths) {
    Write-Host "   $path" -ForegroundColor Cyan
}
Write-Host ""

try {
    # Create the invalidation using AWS CLI
    $CallerReference = "vivid-auto-scram-$(Get-Date -Format 'yyyyMMddHHmmss')"
    
    # Convert paths to JSON format for AWS CLI
    $PathsJson = $InvalidationPaths | ConvertTo-Json -Compress
    
    # Create invalidation batch JSON
    $InvalidationBatch = @{
        Paths = @{
            Quantity = $InvalidationPaths.Count
            Items = $InvalidationPaths
        }
        CallerReference = $CallerReference
    } | ConvertTo-Json -Depth 3 -Compress
    
    Write-Host "Creating invalidation with caller reference: $CallerReference" -ForegroundColor Yellow
    
    $InvalidationResult = aws cloudfront create-invalidation `
        --distribution-id $DistributionId `
        --invalidation-batch $InvalidationBatch `
        --output json
    
    if ($LASTEXITCODE -eq 0) {
        $Invalidation = $InvalidationResult | ConvertFrom-Json
        $InvalidationId = $Invalidation.Invalidation.Id
        $Status = $Invalidation.Invalidation.Status
        
        Write-Host "✅ CloudFront invalidation created successfully" -ForegroundColor Green
        Write-Host "   Invalidation ID: $InvalidationId" -ForegroundColor Cyan
        Write-Host "   Status: $Status" -ForegroundColor Cyan
        Write-Host ""
    }
    else {
        throw "AWS CLI returned exit code $LASTEXITCODE"
    }
}
catch {
    Write-Host "❌ CloudFront invalidation failed: $_" -ForegroundColor Red
    exit 1
}

# Step 2: Check invalidation status
Write-Host "🔍 Checking invalidation status..." -ForegroundColor Blue

try {
    $StatusResult = aws cloudfront get-invalidation `
        --distribution-id $DistributionId `
        --id $InvalidationId `
        --output json
    
    if ($LASTEXITCODE -eq 0) {
        $StatusInfo = $StatusResult | ConvertFrom-Json
        $CurrentStatus = $StatusInfo.Invalidation.Status
        
        Write-Host "   Status: $CurrentStatus" -ForegroundColor Cyan
        
        if ($CurrentStatus -eq "Completed") {
            Write-Host "✅ Invalidation completed successfully" -ForegroundColor Green
        }
        else {
            Write-Host "⏳ Invalidation still in progress..." -ForegroundColor Yellow
            Write-Host "   Note: Invalidation may take 5-15 minutes to complete" -ForegroundColor Yellow
        }
    }
}
catch {
    Write-Host "⚠️  Failed to check invalidation status: $_" -ForegroundColor Yellow
}

# Step 3: Verify cache headers (basic test)
Write-Host "🔍 Verifying cache headers..." -ForegroundColor Blue

$TestUrls = @(
    @{ Url = "https://$CloudFrontDomain/"; Type = "HTML"; Expected = "public, max-age=600" },
    @{ Url = "https://$CloudFrontDomain/services/"; Type = "HTML"; Expected = "public, max-age=600" },
    @{ Url = "https://$CloudFrontDomain/images/hero/aston-martin-db6-website.webp"; Type = "Image"; Expected = "public, max-age=31536000, immutable" }
)

foreach ($test in $TestUrls) {
    try {
        Write-Host "   Testing: $($test.Url)" -ForegroundColor Yellow
        
        $Response = Invoke-WebRequest -Uri $test.Url -Method Head -TimeoutSec 15 -ErrorAction Stop
        $CacheControl = $Response.Headers['Cache-Control']
        
        if ($Response.StatusCode -eq 200) {
            if ($CacheControl -eq $test.Expected) {
                Write-Host "     ✅ $($test.Type) - Cache headers correct: $CacheControl" -ForegroundColor Green
            }
            else {
                Write-Host "     ⚠️  $($test.Type) - Cache headers mismatch:" -ForegroundColor Yellow
                Write-Host "         Expected: $($test.Expected)" -ForegroundColor Yellow
                Write-Host "         Actual: $($CacheControl -join ', ')" -ForegroundColor Yellow
            }
        }
        else {
            Write-Host "     ❌ $($test.Type) - HTTP $($Response.StatusCode)" -ForegroundColor Red
        }
    }
    catch {
        Write-Host "     ❌ $($test.Type) - Request failed: $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "📊 CloudFront Invalidation Summary:" -ForegroundColor Green
Write-Host "   Distribution ID: $DistributionId" -ForegroundColor Cyan
Write-Host "   Invalidation ID: $InvalidationId" -ForegroundColor Cyan
Write-Host "   Status: $CurrentStatus" -ForegroundColor Cyan
Write-Host "   Paths Invalidated: $($InvalidationPaths.Count)" -ForegroundColor Cyan
Write-Host ""
Write-Host "📋 Invalidated Paths:" -ForegroundColor Green
foreach ($path in $InvalidationPaths) {
    Write-Host "   $path" -ForegroundColor Cyan
}
Write-Host ""
Write-Host "✅ CloudFront invalidation strategy completed successfully!" -ForegroundColor Green
Write-Host "   All specified paths have been invalidated" -ForegroundColor Cyan
Write-Host "   Cache headers verification completed" -ForegroundColor Cyan
Write-Host ""
Write-Host "⏳ Note: Cache invalidation may take 5-15 minutes to complete globally" -ForegroundColor Yellow