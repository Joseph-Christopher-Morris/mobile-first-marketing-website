#!/usr/bin/env node

const https = require('https');

const CLOUDFRONT_DOMAIN = 'd15sc9fc739ev2.cloudfront.net';

// Test both logo paths
const logoPaths = [
  '/images/icons/vivid-auto-photography-logo.png',
  '/images/icons/Vivid%20Auto%20Photography%20Logo.png'  // URL encoded version
];

console.log('🔍 Testing Logo Paths...\n');

async function testLogo(logoPath) {
  return new Promise((resolve) => {
    const url = `https://${CLOUDFRONT_DOMAIN}${logoPath}`;
    
    const req = https.get(url, (res) => {
      const contentType = res.headers['content-type'];
      const contentLength = res.headers['content-length'];
      
      if (res.statusCode === 200 && contentType && contentType.startsWith('image/')) {
        console.log(`✅ ${logoPath}`);
        console.log(`   Status: ${res.statusCode}`);
        console.log(`   Content-Type: ${contentType}`);
        console.log(`   Size: ${contentLength} bytes\n`);
        resolve({ success: true, path: logoPath, status: res.statusCode, contentType });
      } else {
        console.log(`❌ ${logoPath}`);
        console.log(`   Status: ${res.statusCode}`);
        console.log(`   Content-Type: ${contentType}\n`);
        resolve({ success: false, path: logoPath, status: res.statusCode, contentType });
      }
      
      res.resume();
    });
    
    req.on('error', (err) => {
      console.log(`❌ ${logoPath}`);
      console.log(`   Error: ${err.message}\n`);
      resolve({ success: false, path: logoPath, error: err.message });
    });
    
    req.setTimeout(5000, () => {
      console.log(`❌ ${logoPath}`);
      console.log(`   Error: Request timeout\n`);
      req.destroy();
      resolve({ success: false, path: logoPath, error: 'Timeout' });
    });
  });
}

async function testAllLogos() {
  for (const logoPath of logoPaths) {
    await testLogo(logoPath);
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  
  console.log('🌐 Logo test completed!');
}

testAllLogos().catch(console.error);