#!/usr/bin/env node

/**
 * Performance Budget Setup Validator
 * Tests that all performance budget infrastructure is in place
 */

const fs = require('fs');
const path = require('path');

console.log('🔍 Validating Performance Budget Setup...\n');

let allPassed = true;

// Test 1: Check budgets.json exists
console.log('1️⃣  Checking budgets.json...');
try {
  const budgetsPath = path.join(process.cwd(), 'budgets.json');
  const budgets = JSON.parse(fs.readFileSync(budgetsPath, 'utf8'));
  
  console.log('   ✅ budgets.json exists');
  console.log('   ✅ Valid JSON format');
  
  // Validate structure
  if (budgets[0]?.resourceSizes && budgets[0]?.timings) {
    console.log('   ✅ Contains resourceSizes');
    console.log('   ✅ Contains timings');
    
    // Check key metrics
    const lcpBudget = budgets[0].timings.find(t => t.metric === 'largest-contentful-paint');
    const clsBudget = budgets[0].timings.find(t => t.metric === 'cumulative-layout-shift');
    
    if (lcpBudget && lcpBudget.budget === 1800) {
      console.log('   ✅ LCP budget: 1800ms (1.8s)');
    }
    if (clsBudget && clsBudget.budget === 0.1) {
      console.log('   ✅ CLS budget: 0.1');
    }
  }
} catch (err) {
  console.log('   ❌ Error:', err.message);
  allPassed = false;
}

// Test 2: Check check-lighthouse.mjs exists
console.log('\n2️⃣  Checking check-lighthouse.mjs...');
try {
  const scriptPath = path.join(process.cwd(), 'scripts', 'check-lighthouse.mjs');
  const scriptContent = fs.readFileSync(scriptPath, 'utf8');
  
  console.log('   ✅ check-lighthouse.mjs exists');
  
  if (scriptContent.includes('LCP_MS')) {
    console.log('   ✅ LCP threshold check implemented');
  }
  if (scriptContent.includes('CLS')) {
    console.log('   ✅ CLS threshold check implemented');
  }
  if (scriptContent.includes('INP_MS')) {
    console.log('   ✅ INP threshold check implemented');
  }
  if (scriptContent.includes('process.exit(1)')) {
    console.log('   ✅ Fails build on threshold violations');
  }
} catch (err) {
  console.log('   ❌ Error:', err.message);
  allPassed = false;
}

// Test 3: Check package.json script
console.log('\n3️⃣  Checking package.json scripts...');
try {
  const packagePath = path.join(process.cwd(), 'package.json');
  const packageJson = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
  
  if (packageJson.scripts['lh:check']) {
    console.log('   ✅ lh:check script exists');
    console.log('   ✅ Command:', packageJson.scripts['lh:check']);
  } else {
    console.log('   ❌ lh:check script not found');
    allPassed = false;
  }
} catch (err) {
  console.log('   ❌ Error:', err.message);
  allPassed = false;
}

// Test 4: Create reports directory if needed
console.log('\n4️⃣  Checking reports directory...');
try {
  const reportsDir = path.join(process.cwd(), 'reports');
  if (!fs.existsSync(reportsDir)) {
    fs.mkdirSync(reportsDir, { recursive: true });
    console.log('   ✅ Created reports/ directory');
  } else {
    console.log('   ✅ reports/ directory exists');
  }
} catch (err) {
  console.log('   ❌ Error:', err.message);
  allPassed = false;
}

// Summary
console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
if (allPassed) {
  console.log('✅ Performance Budget Setup: COMPLETE\n');
  console.log('📋 Next Steps:');
  console.log('   1. Run Lighthouse on your pages:');
  console.log('      lighthouse https://d15sc9fc739ev2.cloudfront.net \\');
  console.log('        --preset=mobile \\');
  console.log('        --budgets-path=./budgets.json \\');
  console.log('        --output=json \\');
  console.log('        --output-path=./reports/home-mobile.json\n');
  console.log('   2. Check results:');
  console.log('      npm run lh:check\n');
  console.log('   3. Add to CI/CD pipeline (GitHub Actions)\n');
  
  console.log('🎯 Performance Thresholds:');
  console.log('   • LCP < 1.8s');
  console.log('   • CLS < 0.1');
  console.log('   • INP < 200ms');
  console.log('   • Total page size < 1MB');
  console.log('   • Script size < 180KB');
  console.log('   • Image size < 600KB\n');
} else {
  console.log('❌ Performance Budget Setup: INCOMPLETE\n');
  console.log('Please fix the errors above and try again.\n');
  process.exit(1);
}
