#!/usr/bin/env pwsh
Write-Host "Converting Markdown blog posts to TSX format..." -ForegroundColor Green
Write-Host ""
node scripts/md-to-tsx.js
Write-Host ""
Write-Host "Conversion complete! Check src/content/blog/ for generated files." -ForegroundColor Green
Read-Host "Press Enter to continue"