#!/usr/bin/env node

/**
 * Test CloudFront Function Logic Locally
 * 
 * This script tests the CloudFront Function URL rewriting logic
 * to ensure it works correctly before deployment.
 */

const { handler } = require('./cloudfront-function-pretty-urls.js');

// Test cases covering various URL patterns
const testCases = [
    // Root URL handling
    {
        input: '/',
        expected: '/index.html',
        description: 'Root URL should serve index.html'
    },
    
    // Directory URLs (ending with /)
    {
        input: '/privacy-policy/',
        expected: '/privacy-policy/index.html',
        description: 'Directory URL should append index.html'
    },
    {
        input: '/about/',
        expected: '/about/index.html',
        description: 'About directory should append index.html'
    },
    {
        input: '/contact/',
        expected: '/contact/index.html',
        description: 'Contact directory should append index.html'
    },
    
    // Extensionless URLs (should become directories)
    {
        input: '/privacy-policy',
        expected: '/privacy-policy/index.html',
        description: 'Extensionless URL should become directory + index.html'
    },
    {
        input: '/about',
        expected: '/about/index.html',
        description: 'Extensionless about should become directory + index.html'
    },
    {
        input: '/contact',
        expected: '/contact/index.html',
        description: 'Extensionless contact should become directory + index.html'
    },
    
    // Static assets (should not be modified)
    {
        input: '/styles.css',
        expected: '/styles.css',
        description: 'CSS files should not be modified'
    },
    {
        input: '/script.js',
        expected: '/script.js',
        description: 'JavaScript files should not be modified'
    },
    {
        input: '/image.png',
        expected: '/image.png',
        description: 'Image files should not be modified'
    },
    {
        input: '/favicon.ico',
        expected: '/favicon.ico',
        description: 'Favicon should not be modified'
    },
    
    // Next.js static assets
    {
        input: '/_next/static/chunks/main.js',
        expected: '/_next/static/chunks/main.js',
        description: 'Next.js static assets should not be modified'
    },
    {
        input: '/_next/static/css/app.css',
        expected: '/_next/static/css/app.css',
        description: 'Next.js CSS should not be modified'
    },
    
    // Edge cases
    {
        input: '',
        expected: '',
        description: 'Empty URI should be passed through'
    },
    {
        input: '/path/with/multiple/segments/',
        expected: '/path/with/multiple/segments/index.html',
        description: 'Multi-segment directory should append index.html'
    },
    {
        input: '/path/with/multiple/segments',
        expected: '/path/with/multiple/segments/index.html',
        description: 'Multi-segment extensionless should become directory + index.html'
    }
];

function runTests() {
    console.log('🧪 Testing CloudFront Function URL Rewriting Logic\n');
    
    let passed = 0;
    let failed = 0;
    
    testCases.forEach((testCase, index) => {
        try {
            // Create mock event object
            const mockEvent = {
                request: {
                    uri: testCase.input
                }
            };
            
            // Run the function
            const result = handler(mockEvent);
            const actualOutput = result.request.uri;
            
            // Check result
            if (actualOutput === testCase.expected) {
                console.log(`✅ Test ${index + 1}: ${testCase.description}`);
                console.log(`   Input: "${testCase.input}" → Output: "${actualOutput}"`);
                passed++;
            } else {
                console.log(`❌ Test ${index + 1}: ${testCase.description}`);
                console.log(`   Input: "${testCase.input}"`);
                console.log(`   Expected: "${testCase.expected}"`);
                console.log(`   Actual: "${actualOutput}"`);
                failed++;
            }
            
        } catch (error) {
            console.log(`💥 Test ${index + 1}: ${testCase.description}`);
            console.log(`   Error: ${error.message}`);
            failed++;
        }
        
        console.log(''); // Empty line for readability
    });
    
    // Summary
    console.log('📊 Test Results Summary:');
    console.log(`   ✅ Passed: ${passed}`);
    console.log(`   ❌ Failed: ${failed}`);
    console.log(`   📈 Success Rate: ${Math.round((passed / (passed + failed)) * 100)}%`);
    
    if (failed === 0) {
        console.log('\n🎉 All tests passed! The CloudFront Function is ready for deployment.');
        return true;
    } else {
        console.log('\n⚠️  Some tests failed. Please review the function logic before deployment.');
        return false;
    }
}

// Performance test
function performanceTest() {
    console.log('\n⚡ Performance Testing...');
    
    const iterations = 10000;
    const testUri = '/privacy-policy/';
    
    const startTime = process.hrtime.bigint();
    
    for (let i = 0; i < iterations; i++) {
        const mockEvent = {
            request: { uri: testUri }
        };
        handler(mockEvent);
    }
    
    const endTime = process.hrtime.bigint();
    const totalTime = Number(endTime - startTime) / 1000000; // Convert to milliseconds
    const avgTime = totalTime / iterations;
    
    console.log(`   📊 Executed ${iterations} iterations`);
    console.log(`   ⏱️  Total time: ${totalTime.toFixed(2)}ms`);
    console.log(`   📈 Average time per execution: ${avgTime.toFixed(4)}ms`);
    
    if (avgTime < 0.1) {
        console.log('   ✅ Performance is excellent (< 0.1ms per execution)');
    } else if (avgTime < 1) {
        console.log('   ✅ Performance is good (< 1ms per execution)');
    } else {
        console.log('   ⚠️  Performance may need optimization (> 1ms per execution)');
    }
}

// Main execution
function main() {
    const testsPass = runTests();
    performanceTest();
    
    if (testsPass) {
        console.log('\n✅ CloudFront Function validation completed successfully!');
        process.exit(0);
    } else {
        console.log('\n❌ CloudFront Function validation failed!');
        process.exit(1);
    }
}

// Run if called directly
if (require.main === module) {
    main();
}

module.exports = { runTests, performanceTest };