#!/usr/bin/env node

/**
 * Test Commit Workflow Validator
 * 
 * This script validates that CI fixes are working by:
 * 1. Creating a test commit
 * 2. Pushing to a test branch
 * 3. Monitoring GitHub Actions workflow
 * 4. Validating workflow success
 * 
 * Requirements: 6.1, 6.2, 6.3, 6.4
 */

const { execSync, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

class TestCommitWorkflow {
    constructor() {
        this.testBranch = `ci-test-${Date.now()}`;
        this.testFile = 'test-ci-validation.tmp';
        this.originalBranch = null;
    }

    async run() {
        console.log('🚀 Starting CI Test Commit Workflow Validation');
        console.log('=' .repeat(50));

        try {
            await this.validatePrerequisites();
            await this.createTestCommit();
            await this.pushTestBranch();
            await this.monitorWorkflow();
            await this.cleanup();
            
            console.log('\n✅ CI Test Commit Workflow Validation PASSED');
            console.log('GitHub Actions workflow is working correctly!');
            
        } catch (error) {
            console.error('\n❌ CI Test Commit Workflow Validation FAILED');
            console.error('Error:', error.message);
            await this.cleanup();
            process.exit(1);
        }
    }

    async validatePrerequisites() {
        console.log('\n📋 Validating Prerequisites...');
        
        // Check if we're in a git repository
        try {
            this.originalBranch = execSync('git branch --show-current', { encoding: 'utf8' }).trim();
            console.log(`✓ Current branch: ${this.originalBranch}`);
        } catch (error) {
            throw new Error('Not in a git repository or git not available');
        }

        // Check if GitHub Actions workflow exists
        const workflowPath = '.github/workflows/quality-check.yml';
        if (!fs.existsSync(workflowPath)) {
            throw new Error(`GitHub Actions workflow not found: ${workflowPath}`);
        }
        console.log('✓ GitHub Actions workflow file exists');

        // Check Node.js version
        const nodeVersion = process.version;
        console.log(`✓ Node.js version: ${nodeVersion}`);
        
        if (!nodeVersion.startsWith('v22.')) {
            console.warn('⚠️  Warning: Local Node.js version is not 22.x, but CI should use 22.19.0');
        }

        // Check if working directory is clean
        try {
            const status = execSync('git status --porcelain', { encoding: 'utf8' });
            if (status.trim()) {
                throw new Error('Working directory is not clean. Please commit or stash changes first.');
            }
            console.log('✓ Working directory is clean');
        } catch (error) {
            throw new Error('Failed to check git status');
        }
    }

    async createTestCommit() {
        console.log('\n🔧 Creating Test Commit...');
        
        // Create test branch
        try {
            execSync(`git checkout -b ${this.testBranch}`, { stdio: 'pipe' });
            console.log(`✓ Created test branch: ${this.testBranch}`);
        } catch (error) {
            throw new Error(`Failed to create test branch: ${error.message}`);
        }

        // Create a test file
        const testContent = `# CI Test Validation
Generated at: ${new Date().toISOString()}
Purpose: Validate GitHub Actions workflow after CI fixes
Node.js version: ${process.version}
Branch: ${this.testBranch}

This file will be automatically deleted after testing.
`;

        fs.writeFileSync(this.testFile, testContent);
        console.log(`✓ Created test file: ${this.testFile}`);

        // Stage and commit the test file
        try {
            execSync(`git add ${this.testFile}`, { stdio: 'pipe' });
            execSync(`git commit -m "test: validate CI workflow fixes

- Test commit to verify GitHub Actions workflow
- Validate Node.js 22.19.0 compatibility
- Check lockfile consistency
- Verify build process

[skip ci] if needed for testing"`, { stdio: 'pipe' });
            
            console.log('✓ Created test commit');
        } catch (error) {
            throw new Error(`Failed to create test commit: ${error.message}`);
        }
    }

    async pushTestBranch() {
        console.log('\n📤 Pushing Test Branch...');
        
        try {
            // Push the test branch
            execSync(`git push origin ${this.testBranch}`, { stdio: 'pipe' });
            console.log(`✓ Pushed test branch to origin/${this.testBranch}`);
            
            // Get the commit SHA
            const commitSha = execSync('git rev-parse HEAD', { encoding: 'utf8' }).trim();
            console.log(`✓ Commit SHA: ${commitSha.substring(0, 8)}`);
            
        } catch (error) {
            throw new Error(`Failed to push test branch: ${error.message}`);
        }
    }

    async monitorWorkflow() {
        console.log('\n👀 Monitoring GitHub Actions Workflow...');
        console.log('Note: This requires GitHub CLI (gh) to be installed and authenticated');
        console.log('If gh is not available, please manually check the workflow at:');
        console.log(`https://github.com/[your-repo]/actions`);
        
        // Check if GitHub CLI is available
        try {
            execSync('gh --version', { stdio: 'pipe' });
        } catch (error) {
            console.log('\n⚠️  GitHub CLI not available. Please manually verify:');
            console.log(`1. Go to your repository's Actions tab`);
            console.log(`2. Find the workflow run for branch: ${this.testBranch}`);
            console.log(`3. Verify all steps pass successfully`);
            console.log(`4. Check for Node.js version warnings in logs`);
            return;
        }

        // Wait a moment for the workflow to start
        console.log('Waiting 30 seconds for workflow to start...');
        await this.sleep(30000);

        try {
            // Get workflow runs for the test branch
            const runs = execSync(`gh run list --branch ${this.testBranch} --limit 1 --json status,conclusion,url`, 
                { encoding: 'utf8' });
            
            const runData = JSON.parse(runs);
            
            if (runData.length === 0) {
                console.log('⚠️  No workflow runs found yet. Please check manually.');
                return;
            }

            const run = runData[0];
            console.log(`✓ Found workflow run: ${run.url}`);
            console.log(`Status: ${run.status}, Conclusion: ${run.conclusion || 'pending'}`);

            // If workflow is still running, provide guidance
            if (run.status === 'in_progress') {
                console.log('\n⏳ Workflow is still running. Please monitor manually:');
                console.log(`URL: ${run.url}`);
                console.log('\nExpected successful steps:');
                console.log('- Checkout repository');
                console.log('- Setup Node.js 22.19.0');
                console.log('- Install dependencies (npm ci)');
                console.log('- Run type checks (if available)');
                console.log('- Run linting (if available)');
                console.log('- Build project');
            } else if (run.conclusion === 'success') {
                console.log('✅ Workflow completed successfully!');
            } else if (run.conclusion === 'failure') {
                throw new Error(`Workflow failed. Check details at: ${run.url}`);
            }

        } catch (error) {
            console.log(`⚠️  Could not monitor workflow automatically: ${error.message}`);
            console.log('Please check the workflow manually in GitHub Actions');
        }
    }

    async cleanup() {
        console.log('\n🧹 Cleaning Up...');
        
        try {
            // Switch back to original branch
            if (this.originalBranch) {
                execSync(`git checkout ${this.originalBranch}`, { stdio: 'pipe' });
                console.log(`✓ Switched back to ${this.originalBranch}`);
            }

            // Delete local test branch
            try {
                execSync(`git branch -D ${this.testBranch}`, { stdio: 'pipe' });
                console.log(`✓ Deleted local test branch: ${this.testBranch}`);
            } catch (error) {
                // Branch might not exist if we failed early
            }

            // Delete remote test branch
            try {
                execSync(`git push origin --delete ${this.testBranch}`, { stdio: 'pipe' });
                console.log(`✓ Deleted remote test branch: origin/${this.testBranch}`);
            } catch (error) {
                console.log(`⚠️  Could not delete remote branch: ${error.message}`);
            }

            // Remove test file if it exists
            if (fs.existsSync(this.testFile)) {
                fs.unlinkSync(this.testFile);
                console.log(`✓ Removed test file: ${this.testFile}`);
            }

        } catch (error) {
            console.error(`Warning: Cleanup failed: ${error.message}`);
        }
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Run the test if called directly
if (require.main === module) {
    const validator = new TestCommitWorkflow();
    validator.run().catch(error => {
        console.error('Fatal error:', error);
        process.exit(1);
    });
}

module.exports = TestCommitWorkflow;