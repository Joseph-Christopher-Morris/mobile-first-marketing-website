const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

/**
 * Test Desktop Layout (1024px+ width)
 * Validates:
 * - Services cards display three per row, centered
 * - All pricing blocks render correctly
 * - Press logos display in single row
 */

const DESKTOP_WIDTH = 1440; // Desktop viewport
const DESKTOP_HEIGHT = 900;

const BASE_URL = process.env.TEST_URL || 'https://d15sc9fc739ev2.cloudfront.net';

const TEST_PAGES = [
  { url: `${BASE_URL}/`, name: 'Home Page' },
  { url: `${BASE_URL}/services/hosting`, name: 'Hosting Page' },
  { url: `${BASE_URL}/services/photography`, name: 'Photography Page' },
  { url: `${BASE_URL}/services/ad-campaigns`, name: 'Ads/Campaigns Page' },
  { url: `${BASE_URL}/services/analytics`, name: 'Analytics Page' },
];

async function testDesktopLayout() {
  console.log('🖥️  Testing Desktop Layout (1024px+ width)...\n');

  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const results = {
    timestamp: new Date().toISOString(),
    viewport: { width: DESKTOP_WIDTH, height: DESKTOP_HEIGHT },
    tests: [],
    summary: {
      total: 0,
      passed: 0,
      failed: 0
    }
  };

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: DESKTOP_WIDTH, height: DESKTOP_HEIGHT });

    // Test Home Page
    console.log('📄 Testing Home Page...');
    const homeTests = await testHomePage(page);
    results.tests.push(...homeTests);

    // Test Service Pages
    for (const testPage of TEST_PAGES.slice(1)) {
      console.log(`📄 Testing ${testPage.name}...`);
      const pageTests = await testServicePage(page, testPage.url, testPage.name);
      results.tests.push(...pageTests);
    }

    // Calculate summary
    results.summary.total = results.tests.length;
    results.summary.passed = results.tests.filter(t => t.passed).length;
    results.summary.failed = results.tests.filter(t => !t.passed).length;

    // Save results
    const reportPath = path.join(__dirname, '..', 'desktop-layout-test-results.json');
    fs.writeFileSync(reportPath, JSON.stringify(results, null, 2));

    // Generate summary
    generateSummary(results);

    console.log(`\n✅ Desktop layout testing complete!`);
    console.log(`📊 Results: ${results.summary.passed}/${results.summary.total} tests passed`);
    console.log(`📁 Full report: ${reportPath}`);

  } catch (error) {
    console.error('❌ Error during testing:', error);
    throw error;
  } finally {
    await browser.close();
  }

  return results;
}

async function testHomePage(page) {
  const tests = [];

  try {
    await page.goto(TEST_PAGES[0].url, { waitUntil: 'networkidle0', timeout: 30000 });

    // Test 1: Services cards display three per row
    console.log('  ✓ Testing services grid layout...');
    const servicesGrid = await page.evaluate(() => {
      const grid = document.querySelector('.grid');
      if (!grid) return null;

      const computedStyle = window.getComputedStyle(grid);
      const gridTemplateColumns = computedStyle.gridTemplateColumns;
      const cards = grid.querySelectorAll('.bg-white.rounded-2xl');

      return {
        found: !!grid,
        gridTemplateColumns,
        columnCount: gridTemplateColumns ? gridTemplateColumns.split(' ').length : 0,
        cardCount: cards.length,
        hasJustifyItemsCenter: grid.classList.contains('justify-items-center') || 
                                computedStyle.justifyItems === 'center'
      };
    });

    tests.push({
      page: 'Home Page',
      test: 'Services grid has 3 columns on desktop',
      passed: servicesGrid && servicesGrid.columnCount === 3,
      details: servicesGrid ? `Grid columns: ${servicesGrid.columnCount}, Cards: ${servicesGrid.cardCount}` : 'Grid not found',
      requirement: '12.5'
    });

    tests.push({
      page: 'Home Page',
      test: 'Services grid is centered',
      passed: servicesGrid && servicesGrid.hasJustifyItemsCenter,
      details: servicesGrid ? `Centered: ${servicesGrid.hasJustifyItemsCenter}` : 'Grid not found',
      requirement: '12.5'
    });

    // Test 2: Press logos display in single row
    console.log('  ✓ Testing press logos layout...');
    const pressLogos = await page.evaluate(() => {
      const logosContainer = document.querySelector('.flex.flex-wrap.justify-center');
      if (!logosContainer) return null;

      const images = logosContainer.querySelectorAll('img[alt*="logo"]');
      const containerWidth = logosContainer.offsetWidth;
      
      // Check if logos are in a single row by comparing positions
      let rows = new Set();
      images.forEach(img => {
        const rect = img.getBoundingClientRect();
        rows.add(Math.floor(rect.top));
      });

      return {
        found: !!logosContainer,
        logoCount: images.length,
        rowCount: rows.size,
        containerWidth
      };
    });

    tests.push({
      page: 'Home Page',
      test: 'Press logos display in single row',
      passed: pressLogos && pressLogos.rowCount === 1,
      details: pressLogos ? `Logos: ${pressLogos.logoCount}, Rows: ${pressLogos.rowCount}` : 'Press logos not found',
      requirement: '12.5'
    });

    // Test 3: Pricing teaser renders correctly
    console.log('  ✓ Testing pricing teaser...');
    const pricingTeaser = await page.evaluate(() => {
      const teaser = document.querySelector('section.py-12.bg-gray-50');
      if (!teaser) return null;

      const heading = teaser.querySelector('h2');
      const button = teaser.querySelector('a[href="/pricing"]');

      return {
        found: !!teaser,
        hasHeading: !!heading,
        headingText: heading ? heading.textContent : '',
        hasButton: !!button,
        buttonText: button ? button.textContent : ''
      };
    });

    tests.push({
      page: 'Home Page',
      test: 'Pricing teaser renders correctly',
      passed: pricingTeaser && pricingTeaser.hasHeading && pricingTeaser.hasButton,
      details: pricingTeaser ? `Heading: "${pricingTeaser.headingText}", Button: "${pricingTeaser.buttonText}"` : 'Pricing teaser not found',
      requirement: '12.5'
    });

  } catch (error) {
    tests.push({
      page: 'Home Page',
      test: 'Page load and layout test',
      passed: false,
      details: `Error: ${error.message}`,
      requirement: '12.5'
    });
  }

  return tests;
}

async function testServicePage(page, url, pageName) {
  const tests = [];

  try {
    await page.goto(url, { waitUntil: 'networkidle0', timeout: 30000 });

    // Test: Pricing block renders correctly
    console.log(`  ✓ Testing pricing block on ${pageName}...`);
    const pricingBlock = await page.evaluate(() => {
      const block = document.querySelector('.bg-white.rounded-2xl, .bg-slate-50.rounded-2xl');
      if (!block) return null;

      const heading = block.querySelector('h2, h3');
      const pricingLink = block.querySelector('a[href="/pricing"]');
      const pricingItems = block.querySelectorAll('p');

      return {
        found: !!block,
        hasHeading: !!heading,
        headingText: heading ? heading.textContent : '',
        hasPricingLink: !!pricingLink,
        pricingItemCount: pricingItems.length,
        blockWidth: block.offsetWidth
      };
    });

    tests.push({
      page: pageName,
      test: 'Pricing block renders correctly',
      passed: pricingBlock && pricingBlock.hasHeading && pricingBlock.hasPricingLink,
      details: pricingBlock ? `Heading: "${pricingBlock.headingText}", Items: ${pricingBlock.pricingItemCount}, Link: ${pricingBlock.hasPricingLink}` : 'Pricing block not found',
      requirement: '12.5'
    });

    // Test: No horizontal scrolling
    console.log(`  ✓ Testing no horizontal scroll on ${pageName}...`);
    const scrollCheck = await page.evaluate(() => {
      return {
        bodyWidth: document.body.scrollWidth,
        windowWidth: window.innerWidth,
        hasHorizontalScroll: document.body.scrollWidth > window.innerWidth
      };
    });

    tests.push({
      page: pageName,
      test: 'No horizontal scrolling',
      passed: !scrollCheck.hasHorizontalScroll,
      details: `Body width: ${scrollCheck.bodyWidth}px, Window width: ${scrollCheck.windowWidth}px`,
      requirement: '12.5'
    });

  } catch (error) {
    tests.push({
      page: pageName,
      test: 'Page load and layout test',
      passed: false,
      details: `Error: ${error.message}`,
      requirement: '12.5'
    });
  }

  return tests;
}

function generateSummary(results) {
  const summaryPath = path.join(__dirname, '..', 'desktop-layout-test-summary.md');
  
  let summary = `# Desktop Layout Test Summary\n\n`;
  summary += `**Test Date:** ${new Date(results.timestamp).toLocaleString()}\n`;
  summary += `**Viewport:** ${results.viewport.width}x${results.viewport.height}\n\n`;
  
  summary += `## Results Overview\n\n`;
  summary += `- **Total Tests:** ${results.summary.total}\n`;
  summary += `- **Passed:** ${results.summary.passed} ✅\n`;
  summary += `- **Failed:** ${results.summary.failed} ❌\n`;
  summary += `- **Success Rate:** ${((results.summary.passed / results.summary.total) * 100).toFixed(1)}%\n\n`;

  summary += `## Test Results by Page\n\n`;
  
  const pageGroups = {};
  results.tests.forEach(test => {
    if (!pageGroups[test.page]) {
      pageGroups[test.page] = [];
    }
    pageGroups[test.page].push(test);
  });

  Object.keys(pageGroups).forEach(pageName => {
    summary += `### ${pageName}\n\n`;
    pageGroups[pageName].forEach(test => {
      const icon = test.passed ? '✅' : '❌';
      summary += `${icon} **${test.test}**\n`;
      summary += `   - ${test.details}\n`;
      summary += `   - Requirement: ${test.requirement}\n\n`;
    });
  });

  summary += `## Key Findings\n\n`;
  
  const failedTests = results.tests.filter(t => !t.passed);
  if (failedTests.length === 0) {
    summary += `✅ All desktop layout tests passed successfully!\n\n`;
    summary += `- Services cards display three per row, centered\n`;
    summary += `- All pricing blocks render correctly\n`;
    summary += `- Press logos display in single row\n`;
    summary += `- No horizontal scrolling on any page\n`;
  } else {
    summary += `⚠️ ${failedTests.length} test(s) failed:\n\n`;
    failedTests.forEach(test => {
      summary += `- **${test.page}:** ${test.test}\n`;
      summary += `  - ${test.details}\n\n`;
    });
  }

  summary += `\n## Requirements Validation\n\n`;
  summary += `This test validates Requirement 12.5:\n`;
  summary += `- Desktop layout (≥1024px) displays correctly\n`;
  summary += `- Services cards show three per row, centered\n`;
  summary += `- Pricing blocks render properly on all service pages\n`;
  summary += `- Press logos display in a single row\n`;

  fs.writeFileSync(summaryPath, summary);
  console.log(`\n📄 Summary report: ${summaryPath}`);
}

// Run tests
if (require.main === module) {
  testDesktopLayout()
    .then(() => process.exit(0))
    .catch(error => {
      console.error('Test failed:', error);
      process.exit(1);
    });
}

module.exports = { testDesktopLayout };
