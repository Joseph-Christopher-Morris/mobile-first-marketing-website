#!/usr/bin/env pwsh

<#
.SYNOPSIS
    Vivid Auto SCRAM Rebuild Deployment Script
    
.DESCRIPTION
    PowerShell deployment script for the Vivid Auto Photography website rebuild.
    Implements differentiated caching strategy as per task 9.1 requirements:
    - HTML files: Cache-Control: public, max-age=600 (10 minutes)
    - Static assets: Cache-Control: public, max-age=31536000, immutable (1 year)
    
.PARAMETER Environment
    Deployment environment (default: production)
    
.PARAMETER SkipBuild
    Skip the build process and deploy existing /out directory
    
.PARAMETER DryRun
    Show what would be deployed without actually deploying
    
.EXAMPLE
    .\scripts\deploy-vivid-auto-scram.ps1
    
.EXAMPLE
    .\scripts\deploy-vivid-auto-scram.ps1 -Environment staging -DryRun
#>

param(
    [string]$Environment = "production",
    [switch]$SkipBuild = $false,
    [switch]$DryRun = $false
)

# Configuration
$S3_BUCKET = "mobile-marketing-site-prod-1759705011281-tyzuo9"
$CLOUDFRONT_DISTRIBUTION_ID = "E2IBMHQ3GCW6ZK"
$AWS_REGION = "us-east-1"
$BUILD_DIR = "out"

# Cache control headers per task requirements
$HTML_CACHE_HEADERS = "public, max-age=600"  # 10 minutes for HTML
$ASSET_CACHE_HEADERS = "public, max-age=31536000, immutable"  # 1 year for assets

# Invalidation paths as specified in requirements
$INVALIDATION_PATHS = @(
    "/",
    "/index.html", 
    "/services/*",
    "/blog*",
    "/images/*",
    "/sitemap.xml",
    "/_next/*"
)

function Write-Header {
    param([string]$Message)
    Write-Host ""
    Write-Host "🚀 $Message" -ForegroundColor Cyan
    Write-Host ("=" * ($Message.Length + 3)) -ForegroundColor Cyan
}

function Write-Success {
    param([string]$Message)
    Write-Host "✅ $Message" -ForegroundColor Green
}

function Write-Warning {
    param([string]$Message)
    Write-Host "⚠️  $Message" -ForegroundColor Yellow
}

function Write-Error {
    param([string]$Message)
    Write-Host "❌ $Message" -ForegroundColor Red
}

function Write-Info {
    param([string]$Message)
    Write-Host "ℹ️  $Message" -ForegroundColor Blue
}

function Test-Prerequisites {
    Write-Header "Checking Prerequisites"
    
    # Check AWS CLI
    try {
        $awsVersion = aws --version 2>$null
        if ($LASTEXITCODE -eq 0) {
            Write-Success "AWS CLI found: $($awsVersion.Split()[0])"
        } else {
            throw "AWS CLI not found"
        }
    } catch {
        Write-Error "AWS CLI is required but not found. Please install AWS CLI."
        exit 1
    }
    
    # Check AWS credentials
    try {
        $identity = aws sts get-caller-identity --output json 2>$null | ConvertFrom-Json
        if ($identity) {
            Write-Success "AWS credentials configured for: $($identity.Arn)"
        } else {
            throw "No AWS credentials"
        }
    } catch {
        Write-Error "AWS credentials not configured. Run 'aws configure' first."
        exit 1
    }
    
    # Check Node.js and npm
    try {
        $nodeVersion = node --version 2>$null
        $npmVersion = npm --version 2>$null
        if ($nodeVersion -and $npmVersion) {
            Write-Success "Node.js $nodeVersion, npm $npmVersion"
        } else {
            throw "Node.js or npm not found"
        }
    } catch {
        Write-Error "Node.js and npm are required. Please install Node.js."
        exit 1
    }
    
    # Verify S3 bucket access
    try {
        aws s3 ls "s3://$S3_BUCKET" --region $AWS_REGION >$null 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Success "S3 bucket access verified: $S3_BUCKET"
        } else {
            throw "Cannot access S3 bucket"
        }
    } catch {
        Write-Error "Cannot access S3 bucket: $S3_BUCKET"
        Write-Info "Please verify bucket name and permissions."
        exit 1
    }
    
    # Verify CloudFront distribution access
    try {
        aws cloudfront get-distribution --id $CLOUDFRONT_DISTRIBUTION_ID --region us-east-1 >$null 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Success "CloudFront distribution access verified: $CLOUDFRONT_DISTRIBUTION_ID"
        } else {
            Write-Warning "Cannot access CloudFront distribution: $CLOUDFRONT_DISTRIBUTION_ID"
            Write-Info "Cache invalidation will be skipped."
        }
    } catch {
        Write-Warning "CloudFront access check failed. Cache invalidation will be skipped."
    }
}

function Build-Project {
    if ($SkipBuild) {
        Write-Info "Skipping build process (using existing build)"
        if (-not (Test-Path $BUILD_DIR)) {
            Write-Error "Build directory '$BUILD_DIR' not found. Cannot skip build."
            exit 1
        }
        return
    }
    
    Write-Header "Building Next.js Static Export"
    
    # Clean previous build
    if (Test-Path $BUILD_DIR) {
        Write-Info "Cleaning previous build..."
        Remove-Item -Recurse -Force $BUILD_DIR -ErrorAction SilentlyContinue
    }
    
    # Install dependencies
    Write-Info "Installing dependencies..."
    if ($DryRun) {
        Write-Info "[DRY RUN] Would run: npm ci"
    } else {
        npm ci
        if ($LASTEXITCODE -ne 0) {
            Write-Error "npm ci failed"
            exit 1
        }
    }
    
    # Build static export
    Write-Info "Building static export..."
    if ($DryRun) {
        Write-Info "[DRY RUN] Would run: npm run build:static"
    } else {
        npm run build:static
        if ($LASTEXITCODE -ne 0) {
            Write-Error "Build failed"
            exit 1
        }
    }
    
    # Verify build output
    if (-not $DryRun -and -not (Test-Path $BUILD_DIR)) {
        Write-Error "Build directory '$BUILD_DIR' was not created"
        exit 1
    }
    
    if (-not $DryRun) {
        $fileCount = (Get-ChildItem -Recurse $BUILD_DIR -File).Count
        $totalSize = (Get-ChildItem -Recurse $BUILD_DIR -File | Measure-Object -Property Length -Sum).Sum
        $sizeFormatted = Format-FileSize $totalSize
        
        Write-Success "Build completed successfully"
        Write-Info "Files: $fileCount"
        Write-Info "Total size: $sizeFormatted"
    }
}

function Format-FileSize {
    param([long]$Bytes)
    
    if ($Bytes -eq 0) { return "0 Bytes" }
    
    $sizes = @("Bytes", "KB", "MB", "GB")
    $i = [math]::Floor([math]::Log($Bytes) / [math]::Log(1024))
    
    return "{0:N2} {1}" -f ($Bytes / [math]::Pow(1024, $i)), $sizes[$i]
}

function Get-CacheHeaders {
    param([string]$FilePath)
    
    $extension = [System.IO.Path]::GetExtension($FilePath).ToLower()
    $fileName = [System.IO.Path]::GetFileName($FilePath)
    
    # HTML files - short cache (10 minutes)
    if ($extension -eq ".html") {
        return $HTML_CACHE_HEADERS
    }
    
    # Static assets - long cache (1 year)
    $staticExtensions = @(".webp", ".jpg", ".jpeg", ".png", ".gif", ".svg", ".ico", ".avif", ".js", ".css", ".woff", ".woff2", ".ttf", ".eot")
    if ($staticExtensions -contains $extension) {
        return $ASSET_CACHE_HEADERS
    }
    
    # Next.js static files - long cache
    if ($FilePath -like "*/_next/static/*") {
        return $ASSET_CACHE_HEADERS
    }
    
    # Default - short cache
    return "public, max-age=3600"
}

function Deploy-HTMLFiles {
    Write-Header "Deploying HTML Files (Short Cache)"
    
    $htmlFiles = Get-ChildItem -Recurse $BUILD_DIR -Filter "*.html"
    
    if ($htmlFiles.Count -eq 0) {
        Write-Warning "No HTML files found to deploy"
        return
    }
    
    Write-Info "Found $($htmlFiles.Count) HTML files to deploy"
    
    foreach ($file in $htmlFiles) {
        $relativePath = $file.FullName.Substring((Get-Item $BUILD_DIR).FullName.Length + 1)
        $s3Key = $relativePath -replace '\\', '/'
        
        $cacheHeaders = Get-CacheHeaders $file.FullName
        
        if ($DryRun) {
            Write-Info "[DRY RUN] Would upload: $s3Key (Cache: $cacheHeaders)"
        } else {
            Write-Info "Uploading: $s3Key"
            
            aws s3 cp $file.FullName "s3://$S3_BUCKET/$s3Key" `
                --region $AWS_REGION `
                --cache-control $cacheHeaders `
                --content-type "text/html" `
                --metadata "deployment-type=vivid-auto-scram,uploaded-at=$(Get-Date -Format 'yyyy-MM-ddTHH:mm:ssZ')"
            
            if ($LASTEXITCODE -ne 0) {
                Write-Error "Failed to upload $s3Key"
                exit 1
            }
        }
    }
    
    Write-Success "HTML files deployment completed"
}

function Deploy-StaticAssets {
    Write-Header "Deploying Static Assets (Long Cache)"
    
    # Get all non-HTML files
    $allFiles = Get-ChildItem -Recurse $BUILD_DIR -File
    $assetFiles = $allFiles | Where-Object { $_.Extension -ne ".html" }
    
    if ($assetFiles.Count -eq 0) {
        Write-Warning "No static assets found to deploy"
        return
    }
    
    Write-Info "Found $($assetFiles.Count) static assets to deploy"
    
    foreach ($file in $assetFiles) {
        $relativePath = $file.FullName.Substring((Get-Item $BUILD_DIR).FullName.Length + 1)
        $s3Key = $relativePath -replace '\\', '/'
        
        $cacheHeaders = Get-CacheHeaders $file.FullName
        $contentType = Get-ContentType $file.Extension
        
        if ($DryRun) {
            Write-Info "[DRY RUN] Would upload: $s3Key (Cache: $cacheHeaders, Type: $contentType)"
        } else {
            Write-Info "Uploading: $s3Key"
            
            aws s3 cp $file.FullName "s3://$S3_BUCKET/$s3Key" `
                --region $AWS_REGION `
                --cache-control $cacheHeaders `
                --content-type $contentType `
                --metadata "deployment-type=vivid-auto-scram,uploaded-at=$(Get-Date -Format 'yyyy-MM-ddTHH:mm:ssZ')"
            
            if ($LASTEXITCODE -ne 0) {
                Write-Error "Failed to upload $s3Key"
                exit 1
            }
        }
    }
    
    Write-Success "Static assets deployment completed"
}

function Get-ContentType {
    param([string]$Extension)
    
    $contentTypes = @{
        ".html" = "text/html"
        ".css" = "text/css"
        ".js" = "application/javascript"
        ".json" = "application/json"
        ".png" = "image/png"
        ".jpg" = "image/jpeg"
        ".jpeg" = "image/jpeg"
        ".gif" = "image/gif"
        ".svg" = "image/svg+xml"
        ".ico" = "image/x-icon"
        ".webp" = "image/webp"
        ".avif" = "image/avif"
        ".woff" = "font/woff"
        ".woff2" = "font/woff2"
        ".ttf" = "font/ttf"
        ".eot" = "application/vnd.ms-fontobject"
        ".xml" = "application/xml"
        ".txt" = "text/plain"
    }
    
    return $contentTypes[$Extension.ToLower()] ?? "application/octet-stream"
}

function Invoke-CloudFrontInvalidation {
    Write-Header "CloudFront Cache Invalidation"
    
    # Create invalidation paths string
    $pathsJson = $INVALIDATION_PATHS | ConvertTo-Json -Compress
    $callerReference = "vivid-auto-scram-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
    
    if ($DryRun) {
        Write-Info "[DRY RUN] Would invalidate paths:"
        foreach ($path in $INVALIDATION_PATHS) {
            Write-Info "  - $path"
        }
        Write-Info "[DRY RUN] Distribution: $CLOUDFRONT_DISTRIBUTION_ID"
        Write-Info "[DRY RUN] Caller Reference: $callerReference"
        return
    }
    
    Write-Info "Invalidating $($INVALIDATION_PATHS.Count) paths..."
    foreach ($path in $INVALIDATION_PATHS) {
        Write-Info "  - $path"
    }
    
    try {
        $result = aws cloudfront create-invalidation `
            --distribution-id $CLOUDFRONT_DISTRIBUTION_ID `
            --paths $INVALIDATION_PATHS `
            --region us-east-1 `
            --output json 2>$null
        
        if ($LASTEXITCODE -eq 0 -and $result) {
            $invalidation = $result | ConvertFrom-Json
            Write-Success "Cache invalidation started"
            Write-Info "Invalidation ID: $($invalidation.Invalidation.Id)"
            Write-Info "Status: $($invalidation.Invalidation.Status)"
            Write-Info "Note: Invalidation may take 5-15 minutes to complete"
        } else {
            throw "CloudFront invalidation command failed"
        }
    } catch {
        Write-Error "Cache invalidation failed: $_"
        Write-Warning "Deployment succeeded but cache may not be updated"
        Write-Info "You can manually invalidate the cache in the AWS Console"
    }
}

function Show-DeploymentSummary {
    param([datetime]$StartTime)
    
    $endTime = Get-Date
    $duration = ($endTime - $StartTime).TotalSeconds
    
    Write-Header "Deployment Summary"
    
    Write-Info "Environment: $Environment"
    Write-Info "S3 Bucket: $S3_BUCKET"
    Write-Info "CloudFront Distribution: $CLOUDFRONT_DISTRIBUTION_ID"
    Write-Info "Build Directory: $BUILD_DIR"
    Write-Info "Duration: $([math]::Round($duration, 1)) seconds"
    Write-Info "Completed: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    
    if ($DryRun) {
        Write-Warning "This was a DRY RUN - no actual deployment occurred"
    } else {
        Write-Success "Deployment completed successfully!"
        Write-Info ""
        Write-Info "🌐 Your site is available at:"
        Write-Info "   https://d15sc9fc739ev2.cloudfront.net"
        Write-Info ""
        Write-Info "Note: Changes may take 5-15 minutes to propagate globally"
    }
}

# Main execution
function Main {
    $startTime = Get-Date
    
    Write-Header "Vivid Auto SCRAM Rebuild Deployment"
    Write-Info "Environment: $Environment"
    Write-Info "Build Directory: $BUILD_DIR"
    Write-Info "S3 Bucket: $S3_BUCKET"
    Write-Info "CloudFront Distribution: $CLOUDFRONT_DISTRIBUTION_ID"
    
    if ($DryRun) {
        Write-Warning "DRY RUN MODE - No actual changes will be made"
    }
    
    try {
        # Step 1: Check prerequisites
        Test-Prerequisites
        
        # Step 2: Build the project
        Build-Project
        
        # Step 3: Deploy HTML files with short cache
        Deploy-HTMLFiles
        
        # Step 4: Deploy static assets with long cache
        Deploy-StaticAssets
        
        # Step 5: Invalidate CloudFront cache
        Invoke-CloudFrontInvalidation
        
        # Step 6: Show summary
        Show-DeploymentSummary $startTime
        
    } catch {
        Write-Error "Deployment failed: $_"
        Write-Info ""
        Write-Info "🔧 Troubleshooting tips:"
        Write-Info "1. Verify AWS credentials: aws sts get-caller-identity"
        Write-Info "2. Check S3 bucket permissions"
        Write-Info "3. Ensure CloudFront distribution ID is correct"
        Write-Info "4. Verify the build completed successfully"
        exit 1
    }
}

# Execute main function
Main