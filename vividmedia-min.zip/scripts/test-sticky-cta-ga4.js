const fs = require('fs');
const path = require('path');

console.log('🧪 Testing Sticky CTA and GA4 Implementation...\n');

let passed = 0;
let failed = 0;

function test(description, condition) {
  if (condition) {
    console.log(`✅ ${description}`);
    passed++;
  } else {
    console.log(`❌ ${description}`);
    failed++;
  }
}

// Test 1: Check StickyCTA component exists
const stickyCTAPath = path.join(__dirname, '../src/components/StickyCTA.tsx');
test('StickyCTA component file exists', fs.existsSync(stickyCTAPath));

// Test 2: Check StickyCTA has GA4 tracking
if (fs.existsSync(stickyCTAPath)) {
  const stickyCTAContent = fs.readFileSync(stickyCTAPath, 'utf-8');
  test('StickyCTA includes sticky_cta_click event', stickyCTAContent.includes('sticky_cta_click'));
  test('StickyCTA includes gtag function', stickyCTAContent.includes('window.gtag'));
  test('StickyCTA includes scroll visibility logic', stickyCTAContent.includes('window.scrollY > 300'));
  test('StickyCTA includes page type tracking', stickyCTAContent.includes('page_type'));
}

// Test 3: Check layout imports StickyCTA
const layoutPath = path.join(__dirname, '../src/app/layout.tsx');
if (fs.existsSync(layoutPath)) {
  const layoutContent = fs.readFileSync(layoutPath, 'utf-8');
  test('Layout imports StickyCTA', layoutContent.includes('import StickyCTA'));
  test('Layout renders StickyCTA', layoutContent.includes('<StickyCTA />'));
  test('Layout does not use old StickyConversionBar', !layoutContent.includes('StickyConversionBar'));
}

// Test 4: Check GeneralContactForm has GA4 tracking
const formPath = path.join(__dirname, '../src/components/sections/GeneralContactForm.tsx');
if (fs.existsSync(formPath)) {
  const formContent = fs.readFileSync(formPath, 'utf-8');
  test('GeneralContactForm includes cta_form_input event', formContent.includes('cta_form_input'));
  test('GeneralContactForm includes lead_form_submit event', formContent.includes('lead_form_submit'));
  test('GeneralContactForm includes form_id parameter', formContent.includes('form_id'));
  test('GeneralContactForm tracks service selection', formContent.includes('serviceInterest'));
}

// Test 5: Check TrackedContactForm exists
const trackedFormPath = path.join(__dirname, '../src/components/sections/TrackedContactForm.tsx');
test('TrackedContactForm component exists', fs.existsSync(trackedFormPath));

// Test 6: Check deployment scripts exist
const deployScriptPath = path.join(__dirname, 'deploy-sticky-cta-ga4.js');
const deployPSPath = path.join(__dirname, '../deploy-sticky-cta-ga4.ps1');
test('Node.js deployment script exists', fs.existsSync(deployScriptPath));
test('PowerShell deployment script exists', fs.existsSync(deployPSPath));

// Test 7: Check documentation exists
const docPath = path.join(__dirname, '../docs/vmc-sticky-cta-and-ga4-plan.md');
const summaryPath = path.join(__dirname, '../STICKY-CTA-GA4-IMPLEMENTATION-COMPLETE.md');
test('Implementation plan documentation exists', fs.existsSync(docPath));
test('Implementation summary exists', fs.existsSync(summaryPath));

// Test 8: Check for required GA4 event parameters
if (fs.existsSync(stickyCTAPath)) {
  const stickyCTAContent = fs.readFileSync(stickyCTAPath, 'utf-8');
  test('StickyCTA tracks cta_text parameter', stickyCTAContent.includes('cta_text'));
  test('StickyCTA tracks page_path parameter', stickyCTAContent.includes('page_path'));
}

// Summary
console.log('\n' + '='.repeat(60));
console.log(`Test Results: ${passed} passed, ${failed} failed`);
console.log('='.repeat(60));

if (failed === 0) {
  console.log('\n✅ All tests passed! Implementation is ready for deployment.\n');
  process.exit(0);
} else {
  console.log('\n❌ Some tests failed. Please review the implementation.\n');
  process.exit(1);
}
