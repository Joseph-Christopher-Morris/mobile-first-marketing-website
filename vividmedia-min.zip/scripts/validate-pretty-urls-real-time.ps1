#!/usr/bin/env powershell

<#
.SYNOPSIS
Real-time URL Functionality Validation Script (PowerShell)

.DESCRIPTION
This script validates that CloudFront pretty URLs are working correctly:
- Root URL serves index.html automatically
- Directory URLs work without index.html
- Extensionless URLs redirect properly

Requirements: 1.4, 2.4
#>

# Configuration
$CLOUDFRONT_DOMAIN = "d15sc9fc739ev2.cloudfront.net"
$BASE_URL = "https://$CLOUDFRONT_DOMAIN"

# Test cases for URL validation
$URL_TEST_CASES = @(
    @{
        name = "Root URL serves index.html automatically"
        url = "/"
        expectedStatus = 200
        expectedContentType = "text/html"
        shouldContain = @('<html', '<head', '<body')
        description = "Root URL (/) should serve index.html automatically"
        requirement = "1.4"
    },
    @{
        name = "Privacy Policy directory URL works without index.html"
        url = "/privacy-policy/"
        expectedStatus = 200
        expectedContentType = "text/html"
        shouldContain = @('Privacy Policy', '<html')
        description = "Directory URL (/privacy-policy/) should serve index.html from that directory"
        requirement = "2.4"
    },
    @{
        name = "About directory URL works without index.html"
        url = "/about/"
        expectedStatus = 200
        expectedContentType = "text/html"
        shouldContain = @('<html', '<head')
        description = "Directory URL (/about/) should serve index.html from that directory"
        requirement = "2.4"
    },
    @{
        name = "Contact directory URL works without index.html"
        url = "/contact/"
        expectedStatus = 200
        expectedContentType = "text/html"
        shouldContain = @('<html', '<head')
        description = "Directory URL (/contact/) should serve index.html from that directory"
        requirement = "2.4"
    },
    @{
        name = "Services directory URL works without index.html"
        url = "/services/"
        expectedStatus = 200
        expectedContentType = "text/html"
        shouldContain = @('<html', '<head')
        description = "Directory URL (/services/) should serve index.html from that directory"
        requirement = "2.4"
    },
    @{
        name = "Blog directory URL works without index.html"
        url = "/blog/"
        expectedStatus = 200
        expectedContentType = "text/html"
        shouldContain = @('<html', '<head')
        description = "Directory URL (/blog/) should serve index.html from that directory"
        requirement = "2.4"
    },
    @{
        name = "Extensionless URL redirects properly - privacy-policy"
        url = "/privacy-policy"
        expectedStatus = 200
        expectedContentType = "text/html"
        shouldContain = @('Privacy Policy', '<html')
        description = "Extensionless URL (/privacy-policy) should serve /privacy-policy/index.html"
        requirement = "2.4"
    },
    @{
        name = "Extensionless URL redirects properly - about"
        url = "/about"
        expectedStatus = 200
        expectedContentType = "text/html"
        shouldContain = @('<html', '<head')
        description = "Extensionless URL (/about) should serve /about/index.html"
        requirement = "2.4"
    },
    @{
        name = "Extensionless URL redirects properly - contact"
        url = "/contact"
        expectedStatus = 200
        expectedContentType = "text/html"
        shouldContain = @('<html', '<head')
        description = "Extensionless URL (/contact) should serve /contact/index.html"
        requirement = "2.4"
    },
    @{
        name = "Extensionless URL redirects properly - services"
        url = "/services"
        expectedStatus = 200
        expectedContentType = "text/html"
        shouldContain = @('<html', '<head')
        description = "Extensionless URL (/services) should serve /services/index.html"
        requirement = "2.4"
    },
    @{
        name = "Extensionless URL redirects properly - blog"
        url = "/blog"
        expectedStatus = 200
        expectedContentType = "text/html"
        shouldContain = @('<html', '<head')
        description = "Extensionless URL (/blog) should serve /blog/index.html"
        requirement = "2.4"
    },
    @{
        name = "Explicit file paths continue to work"
        url = "/privacy-policy/index.html"
        expectedStatus = 200
        expectedContentType = "text/html"
        shouldContain = @('Privacy Policy', '<html')
        description = "Explicit file paths should continue to work for backward compatibility"
        requirement = "1.4"
    },
    @{
        name = "Static assets are not affected"
        url = "/favicon.ico"
        expectedStatus = 200
        expectedContentType = "image/"
        shouldContain = @()
        description = "Static assets should not be affected by URL rewriting"
        requirement = "1.4"
    }
)

function Test-UrlEndpoint {
    param(
        [string]$Url,
        [hashtable]$TestCase
    )
    
    $result = @{
        name = $TestCase.name
        url = $TestCase.url
        requirement = $TestCase.requirement
        passed = $false
        details = @()
        errors = @()
    }
    
    try {
        $fullUrl = "$BASE_URL$($TestCase.url)"
        Write-Host "Testing: $fullUrl"
        
        # Make HTTP request
        $response = Invoke-WebRequest -Uri $fullUrl -Method GET -TimeoutSec 10 -UserAgent "CloudFront-Pretty-URLs-Validator/1.0" -ErrorAction Stop
        
        # Check status code
        if ($response.StatusCode -eq $TestCase.expectedStatus) {
            $result.details += "PASS Status code: $($response.StatusCode)"
        } else {
            $result.errors += "FAIL Expected status $($TestCase.expectedStatus), got $($response.StatusCode)"
        }
        
        # Check content type
        $contentType = $response.Headers['Content-Type']
        if ($contentType -and $contentType -like "*$($TestCase.expectedContentType)*") {
            $result.details += "PASS Content-Type: $contentType"
        } else {
            $result.errors += "FAIL Expected content-type to contain '$($TestCase.expectedContentType)', got '$contentType'"
        }
        
        # Check content contains expected strings
        if ($TestCase.shouldContain -and $TestCase.shouldContain.Count -gt 0) {
            $content = $response.Content
            foreach ($expectedContent in $TestCase.shouldContain) {
                if ($content -like "*$expectedContent*") {
                    $result.details += "PASS Contains: '$expectedContent'"
                } else {
                    $result.errors += "FAIL Missing expected content: '$expectedContent'"
                }
            }
        }
        
        # Check CloudFront headers
        if ($response.Headers['X-Cache']) {
            $result.details += "PASS CloudFront cache status: $($response.Headers['X-Cache'])"
        }
        
        if ($response.Headers['X-Amz-Cf-Pop']) {
            $result.details += "PASS CloudFront POP: $($response.Headers['X-Amz-Cf-Pop'])"
        }
        
        # Test passes if no errors
        $result.passed = $result.errors.Count -eq 0
        
    } catch {
        $result.errors += "FAIL Request failed: $($_.Exception.Message)"
        $result.passed = $false
    }
    
    return $result
}

function Start-UrlValidation {
    Write-Host "🚀 Starting Real-time URL Functionality Validation" -ForegroundColor Green
    Write-Host "📍 Testing domain: $BASE_URL" -ForegroundColor Cyan
    Write-Host "📅 Test started: $(Get-Date -Format 'yyyy-MM-ddTHH:mm:ss.fffZ')" -ForegroundColor Cyan
    Write-Host ""
    
    $results = @()
    $passedTests = 0
    $totalTests = $URL_TEST_CASES.Count
    
    foreach ($testCase in $URL_TEST_CASES) {
        Write-Host ""
        Write-Host "🔍 $($testCase.name)" -ForegroundColor Yellow
        Write-Host "   Description: $($testCase.description)" -ForegroundColor Gray
        Write-Host "   Requirement: $($testCase.requirement)" -ForegroundColor Gray
        
        $result = Test-UrlEndpoint -Url $testCase.url -TestCase $testCase
        $results += $result
        
        if ($result.passed) {
            Write-Host "   PASSED" -ForegroundColor Green
            $passedTests++
        } else {
            Write-Host "   FAILED" -ForegroundColor Red
        }
        
        # Show details
        foreach ($detail in $result.details) {
            Write-Host "      $detail" -ForegroundColor Green
        }
        foreach ($error in $result.errors) {
            Write-Host "      $error" -ForegroundColor Red
        }
        
        # Small delay between requests
        Start-Sleep -Milliseconds 500
    }
    
    # Summary
    Write-Host ""
    Write-Host ("=" * 80) -ForegroundColor Cyan
    Write-Host "📊 VALIDATION SUMMARY" -ForegroundColor Cyan
    Write-Host ("=" * 80) -ForegroundColor Cyan
    Write-Host "Total Tests: $totalTests"
    Write-Host "Passed: $passedTests" -ForegroundColor Green
    Write-Host "Failed: $($totalTests - $passedTests)" -ForegroundColor Red
    Write-Host "Success Rate: $(($passedTests / $totalTests * 100).ToString('F1'))%"
    
    if ($passedTests -eq $totalTests) {
        Write-Host ""
        Write-Host "ALL TESTS PASSED! Pretty URLs are working correctly." -ForegroundColor Green
    } else {
        Write-Host ""
        Write-Host "SOME TESTS FAILED. Please review the errors above." -ForegroundColor Yellow
    }
    
    # Detailed results
    Write-Host ""
    Write-Host "📋 DETAILED RESULTS:" -ForegroundColor Cyan
    for ($i = 0; $i -lt $results.Count; $i++) {
        $result = $results[$i]
        Write-Host ""
        Write-Host "$($i + 1). $($result.name)"
        Write-Host "   URL: $BASE_URL$($result.url)"
        Write-Host "   Status: $(if ($result.passed) { 'PASSED' } else { 'FAILED' })"
        Write-Host "   Requirement: $($result.requirement)"
        
        if ($result.errors.Count -gt 0) {
            Write-Host "   Errors:" -ForegroundColor Red
            foreach ($error in $result.errors) {
                Write-Host "     - $error" -ForegroundColor Red
            }
        }
    }
    
    # Generate JSON report
    $report = @{
        timestamp = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss.fffZ')
        domain = $BASE_URL
        summary = @{
            totalTests = $totalTests
            passedTests = $passedTests
            failedTests = $totalTests - $passedTests
            successRate = "$(($passedTests / $totalTests * 100).ToString('F1'))%"
        }
        results = $results
    }
    
    $reportFilename = "pretty-urls-validation-report-$(Get-Date -Format 'yyyyMMddHHmmss').json"
    $report | ConvertTo-Json -Depth 10 | Out-File -FilePath $reportFilename -Encoding UTF8
    Write-Host ""
    Write-Host "📄 Detailed report saved to: $reportFilename" -ForegroundColor Cyan
    
    return ($passedTests -eq $totalTests)
}

# Main execution
try {
    $success = Start-UrlValidation
    if ($success) {
        exit 0
    } else {
        exit 1
    }
} catch {
    Write-Host "Validation failed with error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}