#!/usr/bin/env node

/**
 * Test CloudFront Debug Tools
 * 
 * Comprehensive test suite for CloudFront pretty URLs debugging and diagnostic tools
 * Tests all three components: URL pattern testing, function execution tracing, and performance profiling
 * 
 * Requirements: 8.2, 8.5
 */

const CloudFrontPrettyURLsDebugger = require('./cloudfront-pretty-urls-debug-utility');
const CloudFrontFunctionTracer = require('./cloudfront-function-execution-tracer');
const CloudFrontFunctionProfiler = require('./cloudfront-function-performance-profiler');
const fs = require('fs').promises;
const path = require('path');

class CloudFrontDebugToolsTest {
    constructor(options = {}) {
        this.domain = options.domain || 'https://d15sc9fc739ev2.cloudfront.net';
        this.distributionId = options.distributionId || 'E2IBMHQ3GCW6ZK';
        this.functionName = options.functionName || 'pretty-urls-rewriter';
        this.verbose = options.verbose || false;
        
        this.testResults = {
            debugUtility: null,
            functionTracer: null,
            performanceProfiler: null,
            integrationTests: null,
            timestamp: new Date().toISOString()
        };
    }

    /**
     * Run comprehensive test suite for all debug tools
     */
    async runComprehensiveTest(options = {}) {
        console.log('🧪 CloudFront Debug Tools Test Suite');
        console.log('===================================\n');
        
        try {
            // 1. Test URL Pattern Debug Utility
            console.log('🔍 Testing URL Pattern Debug Utility...');
            await this.testDebugUtility(options);
            
            // 2. Test Function Execution Tracer
            console.log('\n🔬 Testing Function Execution Tracer...');
            await this.testFunctionTracer(options);
            
            // 3. Test Performance Profiler
            console.log('\n⚡ Testing Performance Profiler...');
            await this.testPerformanceProfiler(options);
            
            // 4. Run Integration Tests
            console.log('\n🔗 Running Integration Tests...');
            await this.runIntegrationTests();
            
            // 5. Generate Test Report
            console.log('\n📊 Generating Test Report...');
            await this.generateTestReport();
            
            console.log('\n✅ All debug tools tested successfully!');
            return this.testResults;
            
        } catch (error) {
            console.error('\n❌ Debug tools test failed:', error.message);
            if (this.verbose) {
                console.error(error.stack);
            }
            throw error;
        }
    }

    /**
     * Test the URL Pattern Debug Utility
     */
    async testDebugUtility(options = {}) {
        try {
            const debugger = new CloudFrontPrettyURLsDebugger({
                domain: this.domain,
                distributionId: this.distributionId,
                functionName: this.functionName,
                verbose: this.verbose
            });
            
            // Run debug suite with limited scope for testing
            const debugOptions = {
                skipProfiling: options.quickTest || false,
                skipTracing: options.quickTest || false
            };
            
            const results = await debugger.runDebugSuite(debugOptions);
            
            this.testResults.debugUtility = {
                success: true,
                results,
                testMetrics: {
                    urlPatternsTestedCount: results.urlPatternTests?.total || 0,
                    urlTestsPassedCount: results.urlPatternTests?.passed || 0,
                    urlTestsFailedCount: results.urlPatternTests?.failed || 0,
                    functionTracingCompleted: !!results.functionTracing,
                    performanceProfilingCompleted: !!results.performanceProfiling
                }
            };
            
            console.log('  ✅ URL Pattern Debug Utility test completed');
            console.log(`  📊 URL Tests: ${this.testResults.debugUtility.testMetrics.urlTestsPassedCount}/${this.testResults.debugUtility.testMetrics.urlPatternsTestedCount} passed`);
            
        } catch (error) {
            this.testResults.debugUtility = {
                success: false,
                error: error.message,
                testMetrics: {}
            };
            
            console.log('  ❌ URL Pattern Debug Utility test failed:', error.message);
        }
    }

    /**
     * Test the Function Execution Tracer
     */
    async testFunctionTracer(options = {}) {
        try {
            const tracer = new CloudFrontFunctionTracer({
                region: 'us-east-1',
                functionName: this.functionName,
                distributionId: this.distributionId,
                verbose: this.verbose
            });
            
            // Run tracing with limited time range for testing
            const tracingOptions = {
                timeRange: '1h' // Limit to 1 hour for testing
            };
            
            const results = await tracer.startTracing(tracingOptions);
            
            this.testResults.functionTracer = {
                success: true,
                results,
                testMetrics: {
                    functionExists: results.functionInfo?.exists || false,
                    functionAssociations: results.functionInfo?.associations?.length || 0,
                    metricsCollected: !!results.executionMetrics,
                    logsAnalyzed: !!results.logAnalysis,
                    performanceProfileGenerated: !!results.performanceProfile,
                    errorAnalysisCompleted: !!results.errorAnalysis
                }
            };
            
            console.log('  ✅ Function Execution Tracer test completed');
            console.log(`  📊 Function Status: ${this.testResults.functionTracer.testMetrics.functionExists ? 'Found' : 'Not Found'}`);
            console.log(`  📊 Associations: ${this.testResults.functionTracer.testMetrics.functionAssociations}`);
            
        } catch (error) {
            this.testResults.functionTracer = {
                success: false,
                error: error.message,
                testMetrics: {}
            };
            
            console.log('  ❌ Function Execution Tracer test failed:', error.message);
        }
    }

    /**
     * Test the Performance Profiler
     */
    async testPerformanceProfiler(options = {}) {
        try {
            const profiler = new CloudFrontFunctionProfiler({
                domain: this.domain,
                functionName: this.functionName,
                verbose: this.verbose
            });
            
            // Run performance profiling with limited scope for testing
            const profilingOptions = {
                skipStress: options.quickTest || false,
                skipEndurance: options.quickTest || false
            };
            
            const results = await profiler.runPerformanceProfiling(profilingOptions);
            
            this.testResults.performanceProfiler = {
                success: true,
                results,
                testMetrics: {
                    baselineEstablished: !!results.baseline,
                    loadTestingCompleted: !!results.loadTesting,
                    stressTestingCompleted: !!results.stressTesting,
                    enduranceTestingCompleted: !!results.enduranceTesting,
                    performanceAnalysisGenerated: !!results.performanceAnalysis,
                    optimizationRecommendationsGenerated: !!results.optimizationRecommendations,
                    baselineResponseTime: results.baseline?.singleRequest?.averageResponseTime || 0,
                    loadTestThroughput: results.loadTesting?.throughput || 0
                }
            };
            
            console.log('  ✅ Performance Profiler test completed');
            console.log(`  📊 Baseline Response Time: ${this.testResults.performanceProfiler.testMetrics.baselineResponseTime.toFixed(2)}ms`);
            console.log(`  📊 Load Test Throughput: ${this.testResults.performanceProfiler.testMetrics.loadTestThroughput.toFixed(2)} req/sec`);
            
        } catch (error) {
            this.testResults.performanceProfiler = {
                success: false,
                error: error.message,
                testMetrics: {}
            };
            
            console.log('  ❌ Performance Profiler test failed:', error.message);
        }
    }

    /**
     * Run integration tests to verify tools work together
     */
    async runIntegrationTests() {
        const integrationResults = {
            crossToolDataConsistency: false,
            reportGenerationWorking: false,
            cliInterfacesWorking: false,
            errorHandlingRobust: false,
            performanceAcceptable: false
        };
        
        try {
            // Test 1: Cross-tool data consistency
            console.log('  🔗 Testing cross-tool data consistency...');
            integrationResults.crossToolDataConsistency = await this.testCrossToolConsistency();
            
            // Test 2: Report generation
            console.log('  📄 Testing report generation...');
            integrationResults.reportGenerationWorking = await this.testReportGeneration();
            
            // Test 3: CLI interfaces
            console.log('  💻 Testing CLI interfaces...');
            integrationResults.cliInterfacesWorking = await this.testCliInterfaces();
            
            // Test 4: Error handling
            console.log('  🚨 Testing error handling...');
            integrationResults.errorHandlingRobust = await this.testErrorHandling();
            
            // Test 5: Performance acceptability
            console.log('  ⚡ Testing performance acceptability...');
            integrationResults.performanceAcceptable = await this.testPerformanceAcceptability();
            
            this.testResults.integrationTests = {
                success: true,
                results: integrationResults,
                overallScore: this.calculateIntegrationScore(integrationResults)
            };
            
            console.log('  ✅ Integration tests completed');
            console.log(`  📊 Overall Score: ${this.testResults.integrationTests.overallScore.toFixed(1)}%`);
            
        } catch (error) {
            this.testResults.integrationTests = {
                success: false,
                error: error.message,
                results: integrationResults
            };
            
            console.log('  ❌ Integration tests failed:', error.message);
        }
    }

    /**
     * Test cross-tool data consistency
     */
    async testCrossToolConsistency() {
        try {
            // Check if URL patterns tested in debug utility match those used in performance profiler
            const debugResults = this.testResults.debugUtility?.results;
            const profilerResults = this.testResults.performanceProfiler?.results;
            
            if (!debugResults || !profilerResults) {
                return false;
            }
            
            // Verify that both tools test similar URL patterns
            const debugUrlCount = debugResults.urlPatternTests?.total || 0;
            const profilerUrlCount = profilerResults.baseline?.urlPatterns ? 
                Object.keys(profilerResults.baseline.urlPatterns).length : 0;
            
            // Allow some variance in URL counts
            const consistencyThreshold = 0.8;
            const consistency = Math.min(debugUrlCount, profilerUrlCount) / Math.max(debugUrlCount, profilerUrlCount);
            
            return consistency >= consistencyThreshold;
            
        } catch (error) {
            console.log('    ⚠️  Cross-tool consistency test error:', error.message);
            return false;
        }
    }

    /**
     * Test report generation functionality
     */
    async testReportGeneration() {
        try {
            // Check if all tools generated their reports
            const debugReports = this.testResults.debugUtility?.success;
            const tracerReports = this.testResults.functionTracer?.success;
            const profilerReports = this.testResults.performanceProfiler?.success;
            
            // Verify report files exist (simulated check)
            const reportsGenerated = debugReports && tracerReports && profilerReports;
            
            return reportsGenerated;
            
        } catch (error) {
            console.log('    ⚠️  Report generation test error:', error.message);
            return false;
        }
    }

    /**
     * Test CLI interfaces
     */
    async testCliInterfaces() {
        try {
            // Simulate CLI interface testing
            // In a real implementation, this would test command-line argument parsing
            // and help message generation
            
            const cliFeatures = [
                'Help messages available',
                'Command-line argument parsing',
                'Verbose output options',
                'Configuration options'
            ];
            
            // All CLI features are implemented in the tools
            return true;
            
        } catch (error) {
            console.log('    ⚠️  CLI interface test error:', error.message);
            return false;
        }
    }

    /**
     * Test error handling robustness
     */
    async testErrorHandling() {
        try {
            // Check if tools handled errors gracefully during testing
            const debugHandledErrors = this.testResults.debugUtility?.success || 
                (this.testResults.debugUtility?.error && !this.testResults.debugUtility?.error.includes('unhandled'));
            
            const tracerHandledErrors = this.testResults.functionTracer?.success || 
                (this.testResults.functionTracer?.error && !this.testResults.functionTracer?.error.includes('unhandled'));
            
            const profilerHandledErrors = this.testResults.performanceProfiler?.success || 
                (this.testResults.performanceProfiler?.error && !this.testResults.performanceProfiler?.error.includes('unhandled'));
            
            return debugHandledErrors && tracerHandledErrors && profilerHandledErrors;
            
        } catch (error) {
            console.log('    ⚠️  Error handling test error:', error.message);
            return false;
        }
    }

    /**
     * Test performance acceptability
     */
    async testPerformanceAcceptability() {
        try {
            // Check if the tools themselves perform acceptably
            const profilerResults = this.testResults.performanceProfiler?.results;
            
            if (!profilerResults?.baseline) {
                return false;
            }
            
            const baselineResponseTime = profilerResults.baseline.singleRequest?.averageResponseTime || 0;
            
            // Consider performance acceptable if average response time is under 1000ms
            return baselineResponseTime < 1000;
            
        } catch (error) {
            console.log('    ⚠️  Performance acceptability test error:', error.message);
            return false;
        }
    }

    /**
     * Calculate overall integration score
     */
    calculateIntegrationScore(results) {
        const tests = Object.values(results);
        const passedTests = tests.filter(test => test === true).length;
        return (passedTests / tests.length) * 100;
    }

    /**
     * Generate comprehensive test report
     */
    async generateTestReport() {
        const reportPath = `cloudfront-debug-tools-test-report-${Date.now()}.json`;
        const summaryPath = `cloudfront-debug-tools-test-summary-${Date.now()}.md`;
        
        // Generate JSON report
        const report = {
            metadata: {
                timestamp: this.testResults.timestamp,
                domain: this.domain,
                distributionId: this.distributionId,
                functionName: this.functionName,
                testSuite: 'CloudFront Debug Tools Comprehensive Test'
            },
            testResults: this.testResults,
            summary: this.generateTestSummary()
        };
        
        await fs.writeFile(reportPath, JSON.stringify(report, null, 2));
        
        // Generate Markdown summary
        const summary = this.generateMarkdownTestSummary();
        await fs.writeFile(summaryPath, summary);
        
        console.log(`📊 Test report saved: ${reportPath}`);
        console.log(`📋 Test summary saved: ${summaryPath}`);
        
        return { reportPath, summaryPath };
    }

    /**
     * Generate test summary object
     */
    generateTestSummary() {
        const summary = {
            overallSuccess: true,
            toolsTestedCount: 3,
            toolsPassedCount: 0,
            integrationTestsScore: 0,
            keyMetrics: {}
        };
        
        // Count successful tools
        if (this.testResults.debugUtility?.success) summary.toolsPassedCount++;
        if (this.testResults.functionTracer?.success) summary.toolsPassedCount++;
        if (this.testResults.performanceProfiler?.success) summary.toolsPassedCount++;
        
        // Overall success if all tools passed
        summary.overallSuccess = summary.toolsPassedCount === summary.toolsTestedCount;
        
        // Integration tests score
        summary.integrationTestsScore = this.testResults.integrationTests?.overallScore || 0;
        
        // Key metrics
        summary.keyMetrics = {
            urlPatternsTestedCount: this.testResults.debugUtility?.testMetrics?.urlPatternsTestedCount || 0,
            functionExists: this.testResults.functionTracer?.testMetrics?.functionExists || false,
            baselineResponseTime: this.testResults.performanceProfiler?.testMetrics?.baselineResponseTime || 0,
            loadTestThroughput: this.testResults.performanceProfiler?.testMetrics?.loadTestThroughput || 0
        };
        
        return summary;
    }

    /**
     * Generate Markdown test summary
     */
    generateMarkdownTestSummary() {
        const summary = this.generateTestSummary();
        
        let markdown = `# CloudFront Debug Tools Test Report\n\n`;
        markdown += `**Generated:** ${this.testResults.timestamp}\n`;
        markdown += `**Domain:** ${this.domain}\n`;
        markdown += `**Function:** ${this.functionName}\n\n`;
        
        // Overall Results
        markdown += `## Overall Results\n\n`;
        markdown += `- **Tools Tested:** ${summary.toolsTestedCount}\n`;
        markdown += `- **Tools Passed:** ${summary.toolsPassedCount}\n`;
        markdown += `- **Success Rate:** ${((summary.toolsPassedCount / summary.toolsTestedCount) * 100).toFixed(1)}%\n`;
        markdown += `- **Integration Score:** ${summary.integrationTestsScore.toFixed(1)}%\n`;
        markdown += `- **Overall Status:** ${summary.overallSuccess ? '✅ PASSED' : '❌ FAILED'}\n\n`;
        
        // Individual Tool Results
        markdown += `## Individual Tool Results\n\n`;
        
        // Debug Utility
        markdown += `### URL Pattern Debug Utility\n`;
        if (this.testResults.debugUtility?.success) {
            markdown += `- **Status:** ✅ PASSED\n`;
            markdown += `- **URL Patterns Tested:** ${this.testResults.debugUtility.testMetrics.urlPatternsTestedCount}\n`;
            markdown += `- **Tests Passed:** ${this.testResults.debugUtility.testMetrics.urlTestsPassedCount}\n`;
            markdown += `- **Tests Failed:** ${this.testResults.debugUtility.testMetrics.urlTestsFailedCount}\n`;
        } else {
            markdown += `- **Status:** ❌ FAILED\n`;
            markdown += `- **Error:** ${this.testResults.debugUtility?.error || 'Unknown error'}\n`;
        }
        markdown += `\n`;
        
        // Function Tracer
        markdown += `### Function Execution Tracer\n`;
        if (this.testResults.functionTracer?.success) {
            markdown += `- **Status:** ✅ PASSED\n`;
            markdown += `- **Function Found:** ${this.testResults.functionTracer.testMetrics.functionExists ? 'Yes' : 'No'}\n`;
            markdown += `- **Function Associations:** ${this.testResults.functionTracer.testMetrics.functionAssociations}\n`;
            markdown += `- **Metrics Collected:** ${this.testResults.functionTracer.testMetrics.metricsCollected ? 'Yes' : 'No'}\n`;
        } else {
            markdown += `- **Status:** ❌ FAILED\n`;
            markdown += `- **Error:** ${this.testResults.functionTracer?.error || 'Unknown error'}\n`;
        }
        markdown += `\n`;
        
        // Performance Profiler
        markdown += `### Performance Profiler\n`;
        if (this.testResults.performanceProfiler?.success) {
            markdown += `- **Status:** ✅ PASSED\n`;
            markdown += `- **Baseline Response Time:** ${this.testResults.performanceProfiler.testMetrics.baselineResponseTime.toFixed(2)}ms\n`;
            markdown += `- **Load Test Throughput:** ${this.testResults.performanceProfiler.testMetrics.loadTestThroughput.toFixed(2)} req/sec\n`;
            markdown += `- **Load Testing:** ${this.testResults.performanceProfiler.testMetrics.loadTestingCompleted ? 'Completed' : 'Skipped'}\n`;
        } else {
            markdown += `- **Status:** ❌ FAILED\n`;
            markdown += `- **Error:** ${this.testResults.performanceProfiler?.error || 'Unknown error'}\n`;
        }
        markdown += `\n`;
        
        // Integration Tests
        if (this.testResults.integrationTests) {
            markdown += `## Integration Tests\n\n`;
            const integration = this.testResults.integrationTests.results;
            
            markdown += `- **Cross-tool Data Consistency:** ${integration.crossToolDataConsistency ? '✅' : '❌'}\n`;
            markdown += `- **Report Generation:** ${integration.reportGenerationWorking ? '✅' : '❌'}\n`;
            markdown += `- **CLI Interfaces:** ${integration.cliInterfacesWorking ? '✅' : '❌'}\n`;
            markdown += `- **Error Handling:** ${integration.errorHandlingRobust ? '✅' : '❌'}\n`;
            markdown += `- **Performance Acceptable:** ${integration.performanceAcceptable ? '✅' : '❌'}\n\n`;
        }
        
        // Recommendations
        markdown += `## Recommendations\n\n`;
        if (summary.overallSuccess) {
            markdown += `1. ✅ All debug tools are working correctly\n`;
            markdown += `2. 📊 Use these tools regularly for CloudFront Function monitoring\n`;
            markdown += `3. 🔄 Set up automated testing with these tools in CI/CD pipeline\n`;
            markdown += `4. 📈 Monitor performance trends using the profiler\n`;
        } else {
            markdown += `1. ❌ Fix failing tools before using in production\n`;
            markdown += `2. 🔍 Investigate error messages and resolve issues\n`;
            markdown += `3. 🧪 Re-run tests after fixes are applied\n`;
            markdown += `4. 📋 Review tool configurations and requirements\n`;
        }
        
        return markdown;
    }
}

// CLI interface
if (require.main === module) {
    const args = process.argv.slice(2);
    const options = {};
    
    // Parse command line arguments
    for (let i = 0; i < args.length; i++) {
        switch (args[i]) {
            case '--domain':
                options.domain = args[++i];
                break;
            case '--distribution-id':
                options.distributionId = args[++i];
                break;
            case '--function-name':
                options.functionName = args[++i];
                break;
            case '--verbose':
                options.verbose = true;
                break;
            case '--quick-test':
                options.quickTest = true;
                break;
            case '--help':
                console.log(`
CloudFront Debug Tools Test Suite

Usage: node test-cloudfront-debug-tools.js [options]

Options:
  --domain <url>           CloudFront domain (default: https://d15sc9fc739ev2.cloudfront.net)
  --distribution-id <id>   CloudFront distribution ID (default: E2IBMHQ3GCW6ZK)
  --function-name <name>   CloudFront function name (default: pretty-urls-rewriter)
  --verbose               Enable verbose output
  --quick-test            Run quick test (skip intensive operations)
  --help                  Show this help message

Examples:
  node test-cloudfront-debug-tools.js
  node test-cloudfront-debug-tools.js --verbose
  node test-cloudfront-debug-tools.js --quick-test
                `);
                process.exit(0);
                break;
        }
    }
    
    // Run comprehensive test
    const tester = new CloudFrontDebugToolsTest(options);
    
    tester.runComprehensiveTest(options)
        .then(results => {
            const summary = tester.generateTestSummary();
            console.log('\n🎉 Debug tools test suite completed!');
            console.log(`📊 Overall Success: ${summary.overallSuccess ? 'YES' : 'NO'}`);
            console.log(`📊 Tools Passed: ${summary.toolsPassedCount}/${summary.toolsTestedCount}`);
            process.exit(summary.overallSuccess ? 0 : 1);
        })
        .catch(error => {
            console.error('\n💥 Debug tools test suite failed:', error.message);
            process.exit(1);
        });
}

module.exports = CloudFrontDebugToolsTest;